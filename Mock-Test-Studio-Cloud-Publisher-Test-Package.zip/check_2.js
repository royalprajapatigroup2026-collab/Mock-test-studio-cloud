
/* PWA service-worker registration. Requires HTTPS hosting (or localhost). */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js", { scope: "./" })
      .catch(err => console.warn("PWA service worker registration failed:", err));
  });
}
