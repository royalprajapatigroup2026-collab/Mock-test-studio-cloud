
(function(){
"use strict";
const $ = id => document.getElementById(id);
const DATA = JSON.parse($("quiz-data").textContent);
let CHAPTERS = DATA.chapters; // Active subject chapter list.
let activeSubjectBank = null;
const QB_BUILTIN_SUBJECT_NAME = String(DATA.subject || DATA.name || "Computer Awareness");
const QB_BUILTIN_CHAPTER_IDS = new Set((DATA.chapters || []).map(ch => String(ch.id)));

// Subject banks: current subject + any added subject question banks.
// Add future banks to DATA.additional_subjects[] or as an application/json
// script with class="subject-quiz-data".
const QUESTION_BANK_STORAGE_KEY = "mockStudio.questionBanks.v1";
function qbReadStoredRecords(){
 try{
  const value=JSON.parse(localStorage.getItem(QUESTION_BANK_STORAGE_KEY) || "[]");
  return Array.isArray(value) ? value.filter(x=>x && x.bank && Array.isArray(x.bank.chapters)) : [];
 }catch(_){ return []; }
}
function qbNorm(value){
 return String(value == null ? "" : value).normalize("NFKC").toLowerCase().replace(/\s+/g," ").replace(/[\u200B-\u200D\uFEFF]/g,"").trim();
}
const QUESTION_BANK_DELETIONS_KEY = "mockStudio.questionBankDeletions.v1";
function qbReadDeletionState(){
 try{
  const raw=JSON.parse(localStorage.getItem(QUESTION_BANK_DELETIONS_KEY)||"{}");
  return {subjects:Array.isArray(raw.subjects)?raw.subjects:[],chapters:Array.isArray(raw.chapters)?raw.chapters:[]};
 }catch(_){return {subjects:[],chapters:[]};}
}
const QB_DELETION_STATE = qbReadDeletionState();
function qbSubjectIsDeleted(name){return QB_DELETION_STATE.subjects.includes(qbNorm(name));}
function qbChapterIsDeleted(subject,ch){
 const subjectKey=qbNorm(subject),id=String(ch && ch.id || ""),title=qbNorm(ch && ch.title);
 return QB_DELETION_STATE.chapters.some(x=>{
  if(!x || qbNorm(x.subject)!==subjectKey)return false;
  if(x.id && id)return String(x.id)===id;
  return !!x.title && qbNorm(x.title)===title;
 });
}
function qbQuestionIdentity(q){
 const options=q && q.options && typeof q.options==="object"
  ? Object.keys(q.options).map(k=>[String(k).trim().toUpperCase(),qbNorm(q.options[k])]).sort((a,b)=>a[0].localeCompare(b[0])).map(pair=>pair[0]+"="+pair[1]).join("|") : "";
 return qbNorm(q && q.question)+"::"+options;
}
function qbQuestionFingerprint(q){
 return qbQuestionIdentity(q)+"::ANSWER="+qbNorm(q && q.answer);
}
function qbUniqueId(base,used,suffix="_import"){
 const root=String(base||"item").trim()||"item";
 if(!used.has(root))return root;
 let n=2,candidate=`${root}${suffix}${n}`;
 while(used.has(candidate)){n++;candidate=`${root}${suffix}${n}`;}
 return candidate;
}
function qbMergeRawBank(target, incoming){
 if(!target || !incoming || !Array.isArray(incoming.chapters)) return;
 if(!Array.isArray(target.chapters)) target.chapters=[];
 const usedChapterIds=new Set(target.chapters.map(ch=>String(ch.id||"")).filter(Boolean));
 const usedQuestionIds=new Set();
 target.chapters.forEach(ch=>(ch.questions||[]).forEach(q=>{if(q && q.id)usedQuestionIds.add(String(q.id));}));
 incoming.chapters.forEach((inc,ci)=>{
  const title=qbNorm(inc.title);
  let dest=target.chapters.find(ch=>qbNorm(ch.title)===title && title);
  if(!dest){
   const wantedId=String(inc.id||`imported_ch_${ci+1}`);
   const newId=qbUniqueId(wantedId,usedChapterIds,"_import");
   const nextNo=target.chapters.reduce((m,ch)=>Math.max(m,Number(ch.chapter_no)||0),0)+1;
   dest={id:newId,chapter_no:nextNo,title:inc.title||`Imported Chapter ${ci+1}`,subheadings:Array.isArray(inc.subheadings)?inc.subheadings.slice():[],questions:[]};
   target.chapters.push(dest);usedChapterIds.add(newId);
  }
  if(!Array.isArray(dest.questions))dest.questions=[];
  const chapterFingerprints=new Set(dest.questions.map(qbQuestionFingerprint));
  (Array.isArray(inc.questions)?inc.questions:[]).forEach(raw=>{
   const q=JSON.parse(JSON.stringify(raw));
   const fp=qbQuestionFingerprint(q);
   if(fp && chapterFingerprints.has(fp))return;
   const originalId=String(q.id||`${dest.id}_q${dest.questions.length+1}`);
   q.id=qbUniqueId(originalId,usedQuestionIds,"_import");
   q.qno=dest.questions.length+1;
   dest.questions.push(q);usedQuestionIds.add(String(q.id));
   if(fp)chapterFingerprints.add(fp);
  });
  dest.question_count=dest.questions.length;
  if(Array.isArray(inc.subheadings)){
   const merged=[...(dest.subheadings||[])];
   const have=new Set(merged.map(qbNorm));
   inc.subheadings.forEach(x=>{const v=String(x||"").trim(),k=qbNorm(v);if(v&& !have.has(k)){merged.push(v);have.add(k);}});
   dest.subheadings=merged;
  }
 });
 target.total_questions=target.chapters.reduce((n,ch)=>n+(Array.isArray(ch.questions)?ch.questions.length:0),0);
 target.total_chapters=target.chapters.length;
}
const QUESTION_BANK_STORED_RECORDS = qbReadStoredRecords();

const EXTRA_SUBJECT_BANKS = [];
if(Array.isArray(DATA.additional_subjects)) EXTRA_SUBJECT_BANKS.push(...DATA.additional_subjects);
document.querySelectorAll('script.subject-quiz-data[type="application/json"]').forEach(node=>{
 try{
  const bank=JSON.parse(node.textContent || "{}");
  if(bank && Array.isArray(bank.chapters)) EXTRA_SUBJECT_BANKS.push(bank);
 }catch(_){}
});
// Re-apply locally imported question banks before the subject index is built.
const QB_RAW_BANK_LOOKUP = [DATA,...EXTRA_SUBJECT_BANKS];
QUESTION_BANK_STORED_RECORDS.forEach(record=>{
 const incoming=record.bank;
 if(record.mode==="merge"){
  const targetName=qbNorm(record.target_subject || incoming.subject || incoming.name);
  const target=QB_RAW_BANK_LOOKUP.find(bank=>qbNorm(bank.subject || bank.name)===targetName);
  if(target) qbMergeRawBank(target,incoming);
  else { EXTRA_SUBJECT_BANKS.push(incoming); QB_RAW_BANK_LOOKUP.push(incoming); }
 }else{
  EXTRA_SUBJECT_BANKS.push(incoming);
  QB_RAW_BANK_LOOKUP.push(incoming);
 }
});

const QB_RAW_SUBJECT_BANKS = [DATA,...EXTRA_SUBJECT_BANKS];
// Apply user-deleted chapters after all imports have been merged.
QB_RAW_SUBJECT_BANKS.forEach(bank=>{
 const subjectName=String(bank.subject || bank.name || "");
 if(Array.isArray(bank.chapters)){
  const kept=bank.chapters.filter(ch=>!qbChapterIsDeleted(subjectName,ch));
  bank.chapters.splice(0,bank.chapters.length,...kept);
 }
});
const SUBJECT_BANKS = QB_RAW_SUBJECT_BANKS
 .map((bank,rawIndex)=>({bank,rawIndex}))
 .filter(({bank})=>bank && Array.isArray(bank.chapters) && !qbSubjectIsDeleted(bank.subject || bank.name || ""))
 .map(({bank,rawIndex},visibleIndex)=>({
  // Use the stable position in the raw bank registry, not the filtered display index.
  // Deleted subjects therefore cannot renumber the storage IDs of later subjects.
  key:`subject_${rawIndex}`,
  legacyKey:`subject_${visibleIndex}`,
  name:String(bank.subject || bank.name || `Subject ${visibleIndex+1}`),
  chapters:bank.chapters,
  primary:bank===DATA
 }));
const PRIMARY_SUBJECT_KEY = SUBJECT_BANKS.length ? SUBJECT_BANKS[0].key : "subject_0";
const effectiveQuestionId = (bank,q) => bank.primary ? q.id : `${bank.key}::${q.id}`;
const subjectChapterStorageKey = (bank,ch) => bank.primary ? ch.id : `${bank.key}::${ch.id}`;

const Q_MAP = new Map();
SUBJECT_BANKS.forEach(bank=>{
 bank.chapters.forEach((ch,cIdx)=>{
  (ch.questions || []).forEach((q,qIdx)=>{
   const effectiveId=effectiveQuestionId(bank,q);
   Q_MAP.set(effectiveId,{
    ...q,id:effectiveId,original_id:q.id,
    chapter_no:ch.chapter_no,chapter_title:ch.title,
    chapter_idx:cIdx,orig_idx:qIdx,
    subject_name:bank.name,subject_key:bank.key,
    source_chapter_id:ch.id,
    source_storage_key:subjectChapterStorageKey(bank,ch)
   });
  });
 });
});

const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => (
 {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]
));

function formatInline(text){
 const safe = esc(text);
 return safe.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
}

function renderStemHTML(stem){
 const lines = String(stem || "").split("\n").filter(l => l.trim() !== "");
 return lines.map((line, idx) => {
  const isPoint = idx > 0 && (/^(?:\d+\.\s+|[a-d]\.\s+|\([A-D]\)\s+|\([ivx]+\)\s+)/i.test(line));
  const cls = isPoint ? "stem-line stem-point" : "stem-line";
  return `<div class="${cls}">${formatInline(line)}</div>`;
 }).join("");
}

function renderExplanationHTML(exp){
 const lines = String(exp || "").split("\n").filter(l => l.trim() !== "");
 return lines.map(line => {
  const isBullet = /^(?:•\s+|-\s+|\d+\.\s+)/.test(line);
  const cls = isBullet ? "exp-line exp-bullet" : "exp-line";
  return `<div class="${cls}">${formatInline(line)}</div>`;
 }).join("");
}
function renderVerificationNoteHTML(note){
 const value=String(note==null?"":note).trim();
 if(!value) return "";
 return `<div class="verification-note-block"><div class="verification-note-title">Verification Note</div><div class="verification-note-text">${renderExplanationHTML(value)}</div></div>`;
}

function migrateSubjectScopedId(value){
 const raw=String(value||"");
 for(const bank of SUBJECT_BANKS){
  if(bank.primary||!bank.legacyKey||bank.legacyKey===bank.key)continue;
  const prefix=bank.legacyKey+"::";
  if(raw.startsWith(prefix))return bank.key+"::"+raw.slice(prefix.length);
 }
 return raw;
}
function migrateSubjectScopedMap(map){
 const out={};
 Object.entries(map||{}).forEach(([key,value])=>{out[migrateSubjectScopedId(key)]=value;});
 return out;
}

const STORAGE_KEY = "mock_studio_600_v6";
const state = {
 subjectIdx: 0,
 chapterIdx: 0,
 answerMode: "final",
 timerMode: "chapter25",
 customPerSec: 30,
 customChapterMin: 25,
 autoNextOnTimeout: false,
 theme: "light",
 fontSize: 16,
 reviewFilter: "all",
 hideBarHint: false,
 explanationAutoHideSec: 8,
 bookmarks: {},
 customSession: null,
 exitedTestKey: null,
 chapters: {}
};

function createSessionState(count){
 return {
  currentIdx: 0,
  answers: {},
  marked: {},
  visited: {0: true},
  submitted: false,
  viewingScorecard: false,
  testStarted: false,
  qTimeLeft: {},
  qTimedOut: {},
  chapterTimeLeft: getChapterTotalSec(),
  elapsedSec: 0
 };
}

function getActiveSession(){
 if(state.customSession){
  const qs = state.customSession.questionIds.map(id => Q_MAP.get(id)).filter(Boolean);
  return {
   key: "custom_session",
   isCustom: true,
   chapter_no: 0,
   title: state.customSession.title,
   questions: qs
  };
 }
 const bank = SUBJECT_BANKS[state.subjectIdx] || SUBJECT_BANKS[0];
 const ch = CHAPTERS[state.chapterIdx];
 if(!bank || !ch) return {key:"empty_subject",isCustom:false,chapter_no:0,title:"No chapter selected",questions:[]};
 return {
  key: subjectChapterStorageKey(bank,ch),
  isCustom: false,
  chapter_no: ch.chapter_no,
  title: ch.title,
  questions: ch.questions.map(q => {
   const effectiveId = effectiveQuestionId(bank,q);
   const mapped = Q_MAP.get(effectiveId) || q;
   return { ...mapped, id:effectiveId, chapter_no:ch.chapter_no, chapter_title:ch.title };
  })
 };
}

function getSessionState(sess){
 const target = sess || getActiveSession();
 if(!state.chapters[target.key]){
  state.chapters[target.key] = createSessionState(target.questions.length);
 }
 const current=state.chapters[target.key];
 if(!current.answers || typeof current.answers!=="object") current.answers={};
 if(!current.marked || typeof current.marked!=="object") current.marked={};
 if(!current.visited || typeof current.visited!=="object") current.visited={};
 if(!current.qTimeLeft || typeof current.qTimeLeft!=="object") current.qTimeLeft={};
 if(!current.qTimedOut || typeof current.qTimedOut!=="object") current.qTimedOut={};
 if(typeof current.elapsedSec!=="number" || !Number.isFinite(current.elapsedSec)) current.elapsedSec=0;
 current.currentIdx=Math.max(0,Math.min(target.questions.length-1,Number(current.currentIdx)||0));
 return current;
}

function saveState(){
 try{
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
   subjectIdx: state.subjectIdx,
   chapterIdx: state.chapterIdx,
   answerMode: state.answerMode,
   timerMode: state.timerMode,
   customPerSec: state.customPerSec,
   customChapterMin: state.customChapterMin,
   autoNextOnTimeout: state.autoNextOnTimeout,
   theme: state.theme,
   fontSize: state.fontSize,
   hideBarHint: state.hideBarHint,
   explanationAutoHideSec: state.explanationAutoHideSec,
   bookmarks: state.bookmarks,
   customSession: state.customSession,
   exitedTestKey: state.exitedTestKey,
   chapters: state.chapters
  }));
  if(typeof homeStudySnapshotCache!=="undefined")homeStudySnapshotCache.at=0;
  return true;
 }catch(err){
  appShowStorageWarning("Your latest progress could not be saved in this browser. Download a Full Backup, then free browser storage before continuing.");
  return false;
 }
}

function loadState(){
 try{
  const raw = localStorage.getItem(STORAGE_KEY);
  if(!raw) return;
  const saved = JSON.parse(raw);
  if(Number.isInteger(saved.subjectIdx) && saved.subjectIdx >= 0 && saved.subjectIdx < SUBJECT_BANKS.length){
   state.subjectIdx = saved.subjectIdx;
  }
  activeSubjectBank = SUBJECT_BANKS[state.subjectIdx] || SUBJECT_BANKS[0] || null;
  CHAPTERS = activeSubjectBank ? activeSubjectBank.chapters : DATA.chapters;
  if(typeof saved.chapterIdx === "number" && saved.chapterIdx >= 0 && saved.chapterIdx < CHAPTERS.length){
   state.chapterIdx = saved.chapterIdx;
  } else {
   state.chapterIdx = 0;
  }
  if(saved.answerMode === "instant" || saved.answerMode === "final") state.answerMode = saved.answerMode;
  if(["off","per30","chapter25"].includes(saved.timerMode)) state.timerMode = saved.timerMode;
  if(typeof saved.customPerSec === "number") state.customPerSec = Math.max(5, Math.min(600, saved.customPerSec));
  if(typeof saved.customChapterMin === "number") state.customChapterMin = Math.max(1, Math.min(300, saved.customChapterMin));
  if(typeof saved.autoNextOnTimeout === "boolean") state.autoNextOnTimeout = saved.autoNextOnTimeout;
  if(saved.theme === "dark" || saved.theme === "light") state.theme = saved.theme;
  if(typeof saved.fontSize === "number") state.fontSize = Math.max(13, Math.min(26, saved.fontSize));
  if(typeof saved.hideBarHint === "boolean") state.hideBarHint = saved.hideBarHint;
  if(typeof saved.explanationAutoHideSec === "number" && [0,3,5,8,10,15,20].includes(saved.explanationAutoHideSec)) state.explanationAutoHideSec = saved.explanationAutoHideSec;
  if(saved.bookmarks && typeof saved.bookmarks === "object") state.bookmarks = migrateSubjectScopedMap(saved.bookmarks);
  if(saved.customSession && Array.isArray(saved.customSession.questionIds) && saved.customSession.questionIds.length){
   state.customSession = {...saved.customSession,questionIds:saved.customSession.questionIds.map(migrateSubjectScopedId)};
  }
  if(typeof saved.exitedTestKey==="string" && saved.exitedTestKey) state.exitedTestKey=migrateSubjectScopedId(saved.exitedTestKey);
  if(saved.chapters && typeof saved.chapters === "object"){
   const migrated={};
   Object.entries(saved.chapters).forEach(([key,value])=>{migrated[migrateSubjectScopedId(key)]=value;});
   state.chapters=migrated;
  }
  Object.values(state.chapters).forEach(session=>{
   if(session && typeof session==="object") session._submitting=false;
  });
 }catch(_){
  if(typeof appShowStorageWarning==="function"){
   appShowStorageWarning("Saved app settings or progress could not be read. The stored data has not been overwritten. Download a Full Backup before attempting recovery.");
  }
 }
}

/* Phase 2 — Test Engine hardening: configured chapter duration, session-state normalization
   and duplicate-submit protection. Smooth Sub-Second Timer Engine follows. */
let timerInterval = null;
let smoothRafId = null;
let warmupTimeoutId = null;
let warmupIntervalId = null;
let warmupRemainingSec = 0;
let timerPaused = false;
let timerRemainderMs = 0;
let lastTimerCallbackMs = 0;
let lastSecTickMs = 0;
let lastBarSyncMs = 0;
let lastDisplayedSec = -1;

function getPerQuestionSec(){
 return Math.max(5, parseInt(state.customPerSec, 10) || 30);
}
function getActiveTimerMode(sessArg){
 const sess=sessArg||getActiveSession();
 return sess&&sess.isCustom ? ((state.customSession&&state.customSession.timerMode)||"chapter25") : state.timerMode;
}

function getChapterTotalSec(sessArg){
 // Personalized Tests carry their own total time limit in minutes.
 // Regular chapter tests continue to use the user's configured chapter duration.
 // Per-question timing remains independently controlled by getPerQuestionSec().
 const customMinutes = sessArg&&sessArg.isCustom&&state.customSession ? Number(state.customSession.durationMinutes) : NaN;
 if(sessArg&&sessArg.isCustom&&Number.isFinite(customMinutes)&&customMinutes>=1){
  return Math.max(60, Math.min(1440, Math.floor(customMinutes)) * 60);
 }
 return Math.max(60, (Math.max(1, Number(state.customChapterMin) || 25)) * 60);
}

function refreshTimerLabels(){
 const perS = getPerQuestionSec();
 const chTotal = getChapterTotalSec();
 if($("perTimerLabel")) $("perTimerLabel").textContent = `${perS} sec / Question`;
 if($("chTimerLabel")) $("chTimerLabel").textContent = `Full Chapter Timer (${fmtTime(chTotal)} total)`;
 if($("customPerSecInput")) $("customPerSecInput").value = String(perS);
 if($("customChapMinInput")) $("customChapMinInput").value = String(Math.ceil(chTotal/60));
}

function fmtTime(sec){
 const s = Math.max(0, Math.ceil(sec));
 const m = Math.floor(s / 60);
 const r = s % 60;
 return String(m).padStart(2, "0") + ":" + String(r).padStart(2, "0");
}

function stopTimer(){
 if(timerInterval){ clearInterval(timerInterval); timerInterval = null; }
 if(smoothRafId){ cancelAnimationFrame(smoothRafId); smoothRafId = null; }
 if(warmupTimeoutId){ clearTimeout(warmupTimeoutId); warmupTimeoutId = null; }
 if(warmupIntervalId){ clearInterval(warmupIntervalId); warmupIntervalId = null; }
 warmupRemainingSec = 0;
 timerRemainderMs = 0;
 lastTimerCallbackMs = 0;
}

function getExactRemainingSec(sess, cs, nowMs){
 const perCap = getPerQuestionSec();
 if(getActiveTimerMode(sess) === "per30"){
  const qIdx = cs.currentIdx;
  if(typeof cs.qTimeLeft[qIdx] !== "number") cs.qTimeLeft[qIdx] = perCap;
  const base = cs.qTimeLeft[qIdx];
  const frozen = !cs.testStarted || warmupRemainingSec > 0 || (state.answerMode === "instant" && !!cs.answers[qIdx]) || timerPaused || base <= 0;
  if(frozen || !lastSecTickMs) return base;
  const frac = Math.min(1, Math.max(0, (nowMs - lastSecTickMs) / 1000));
  return Math.max(0, base - frac);
 } else {
  const base = cs.chapterTimeLeft;
  const frozen = !cs.testStarted || warmupRemainingSec > 0 || timerPaused || base <= 0;
  if(frozen || !lastSecTickMs) return base;
  const frac = Math.min(1, Math.max(0, (nowMs - lastSecTickMs) / 1000));
  return Math.max(0, base - frac);
 }
}

function renderWarmupBanner(cs){
 const banner = $("warmupBanner");
 if(!banner) return;
 if(warmupRemainingSec > 0 && cs && cs.testStarted && !cs.submitted){
  banner.style.display = "";
  banner.textContent = `Study Mode Ready — Timer starts in ${warmupRemainingSec}s...`;
 } else {
  banner.style.display = "none";
  banner.textContent = "";
 }
}

function syncTimerUI(nowMs){
 const tNow = typeof nowMs === "number" ? nowMs : performance.now();
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 const pill = $("liveTimerPill");
 const pauseBtn = $("pauseTimerBtn");
 const track = $("timerTrack");
 const fill = $("timerFill");

 renderWarmupBanner(cs);

 if(!cs.testStarted || cs.submitted || cs.viewingScorecard){
  pill.className = "q-timer-inline off";
  if(pauseBtn) pauseBtn.style.display = "none";
  track.classList.remove("visible");
  lastDisplayedSec = -1;
  return;
 }

 if(pauseBtn){
  pauseBtn.style.display = displayMode === "test" ? "inline-flex" : "none";
  pauseBtn.textContent = timerPaused ? "▶ Resume" : "⏸ Pause";
  pauseBtn.setAttribute("aria-pressed", String(timerPaused));
  pauseBtn.title = timerPaused ? "Resume test timer" : "Pause test timer";
 }
 if(getActiveTimerMode(sess) === "off"){
  pill.className = "q-timer-inline off";
  track.classList.remove("visible");
  lastDisplayedSec = -1;
  return;
 }
 track.classList.add("visible");

 if(getActiveTimerMode(sess) === "per30"){
  const perCap = getPerQuestionSec();
  if(typeof cs.qTimeLeft[cs.currentIdx] !== "number") cs.qTimeLeft[cs.currentIdx] = perCap;
  const exactRem = getExactRemainingSec(sess, cs, tNow);
  const ceilSec = Math.max(0, Math.ceil(exactRem));
  const danger = ceilSec <= Math.min(8, Math.ceil(perCap * 0.25));
  if(ceilSec !== lastDisplayedSec){
   lastDisplayedSec = ceilSec;
   pill.className = "q-timer-inline" + (danger ? " danger" : "");
   pill.textContent = "⏱ " + fmtTime(exactRem);
  }
  const pct = Math.max(0, Math.min(100, (exactRem / perCap) * 100));
  fill.style.width = pct.toFixed(3) + "%";
  fill.classList.toggle("danger", danger);
 } else {
  const exactRem = getExactRemainingSec(sess, cs, tNow);
  const ceilSec = Math.max(0, Math.ceil(exactRem));
  const danger = ceilSec <= 120;
  if(ceilSec !== lastDisplayedSec){
   lastDisplayedSec = ceilSec;
   pill.className = "q-timer-inline" + (danger ? " danger" : "");
   pill.textContent = "⏱ " + fmtTime(exactRem);
  }
  const totalSec = getChapterTotalSec(sess);
  const pct = Math.max(0, Math.min(100, (exactRem / totalSec) * 100));
  fill.style.width = pct.toFixed(3) + "%";
  fill.classList.toggle("danger", danger);
 }
}

function smoothLoop(nowMs){
 if(getActiveTimerMode() === "off"){ smoothRafId = null; return; }
 if(nowMs - lastBarSyncMs >= 45){
  lastBarSyncMs = nowMs;
  syncTimerUI(nowMs);
 }
 smoothRafId = requestAnimationFrame(smoothLoop);
}

function beginCountingInterval(){
 if(timerInterval){clearInterval(timerInterval);timerInterval=null;}
 lastSecTickMs=performance.now();
 lastTimerCallbackMs=lastSecTickMs;
 timerRemainderMs=0;
 timerInterval=setInterval(()=>{
  const nowTick=performance.now();
  if(timerPaused||warmupRemainingSec>0){
   lastSecTickMs=nowTick;lastTimerCallbackMs=nowTick;timerRemainderMs=0;return;
  }
  const elapsedMs=Math.max(0,nowTick-lastTimerCallbackMs);
  lastTimerCallbackMs=nowTick;
  const accumulated=timerRemainderMs+elapsedMs;
  const elapsedWhole=Math.floor(accumulated/1000);
  timerRemainderMs=accumulated-(elapsedWhole*1000);
  lastSecTickMs=nowTick-timerRemainderMs;
  if(!elapsedWhole){syncTimerUI(nowTick);return;}
  const sess=getActiveSession(),cs=getSessionState(sess);
  if(!cs.testStarted||cs.submitted||cs.viewingScorecard){stopTimer();syncTimerUI(nowTick);return;}
  const previousElapsed=Number(cs.elapsedSec)||0;
  cs.elapsedSec=previousElapsed+elapsedWhole;
  if(getActiveTimerMode(sess)==="chapter25"){
   cs.chapterTimeLeft=Math.max(0,(Number(cs.chapterTimeLeft)||0)-elapsedWhole);
   if(cs.chapterTimeLeft===0){saveState();finalizeSubmit();return;}
  }else if(getActiveTimerMode(sess)==="per30"){
   let secondsLeft=elapsedWhole;
   while(secondsLeft>0){
    const qIdx=cs.currentIdx;
    if(state.answerMode==="instant"&&cs.answers[qIdx]){
     timerRemainderMs=0;lastSecTickMs=nowTick;lastTimerCallbackMs=nowTick;break;
    }
    if(typeof cs.qTimeLeft[qIdx]!=="number")cs.qTimeLeft[qIdx]=getPerQuestionSec();
    const available=Math.max(0,cs.qTimeLeft[qIdx]);
    if(available===0){
     cs.qTimedOut[qIdx]=true;
     if(state.autoNextOnTimeout&&qIdx<sess.questions.length-1){goToQuestion(qIdx+1,"next");continue;}
     renderQuestion("");break;
    }
    const consumed=Math.min(secondsLeft,available);
    cs.qTimeLeft[qIdx]=available-consumed;
    secondsLeft-=consumed;
    if(cs.qTimeLeft[qIdx]===0){
     cs.qTimedOut[qIdx]=true;
     if(state.autoNextOnTimeout&&qIdx<sess.questions.length-1)goToQuestion(qIdx+1,"next");
     else{renderQuestion("");break;}
    }
   }
  }
  syncTimerUI(nowTick);
  if(Math.floor(cs.elapsedSec/5)>Math.floor(previousElapsed/5))saveState();
 },250);
}
function startTimer(warmupSeconds){
 stopTimer();
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 lastSecTickMs = performance.now();
 lastBarSyncMs = 0;
 lastDisplayedSec = -1;
 syncTimerUI(lastSecTickMs);
 if(!cs.testStarted || cs.submitted || cs.viewingScorecard || timerPaused) return;

 if(getActiveTimerMode(sess) !== "off") smoothRafId = requestAnimationFrame(smoothLoop);

 if(typeof warmupSeconds === "number" && warmupSeconds > 0){
  warmupRemainingSec = warmupSeconds;
  renderWarmupBanner(cs);
  warmupIntervalId = setInterval(() => {
   warmupRemainingSec = Math.max(0, warmupRemainingSec - 1);
   renderWarmupBanner(cs);
   if(warmupRemainingSec <= 0 && warmupIntervalId){
    clearInterval(warmupIntervalId);
    warmupIntervalId = null;
   }
  }, 1000);
  warmupTimeoutId = setTimeout(() => {
   warmupRemainingSec = 0;
   renderWarmupBanner(cs);
   beginCountingInterval();
  }, warmupSeconds * 1000);
 } else {
  beginCountingInterval();
 }
}

/* Theme-aware custom selectors; hidden native selects remain the source of truth. */
function refreshAppSelect(nativeId){
 const native=$(nativeId);
 const prefix=nativeId==="partSelect"?"partSelect":"chapterSelect";
 const trigger=$(prefix+"Trigger"), value=$(prefix+"Value"), menu=$(prefix+"Menu");
 if(!native||!trigger||!value||!menu)return;
 const selected=native.options[native.selectedIndex];
 value.textContent=selected?selected.textContent:"Select";
 menu.innerHTML=Array.from(native.options).map(opt=>
  `<button type="button" class="app-select-option ${opt.selected?'selected':''}" role="option" aria-selected="${opt.selected?'true':'false'}" data-value="${esc(opt.value)}">${esc(opt.textContent)}</button>`
 ).join("");
}
function initAppSelect(nativeId){
 const native=$(nativeId);
 const prefix=nativeId==="partSelect"?"partSelect":"chapterSelect";
 const trigger=$(prefix+"Trigger"), menu=$(prefix+"Menu");
 if(!native||!trigger||!menu)return;
 refreshAppSelect(nativeId);
 trigger.addEventListener("click",()=>{
  const open=menu.hidden;
  $("partSelectMenu").hidden=true;
  $("chapterSelectMenu").hidden=true;
  $("partSelectTrigger").setAttribute("aria-expanded","false");
  $("chapterSelectTrigger").setAttribute("aria-expanded","false");
  menu.hidden=!open;
  trigger.setAttribute("aria-expanded",String(open));
 });
 menu.addEventListener("click",e=>{
  const opt=e.target.closest("[data-value]");
  if(!opt)return;
  native.value=opt.dataset.value;
  native.dispatchEvent(new Event("change",{bubbles:true}));
  refreshAppSelect(nativeId);
  menu.hidden=true;
  trigger.setAttribute("aria-expanded","false");
 });
 native.addEventListener("change",()=>refreshAppSelect(nativeId));
}
function refreshAllAppSelects(){
 refreshAppSelect("partSelect");
 refreshAppSelect("chapterSelect");
}
let appSelectOutsideClickBound = false;
if(!appSelectOutsideClickBound){
 document.addEventListener("click",e=>{
  if(!e.target.closest(".app-select")){
   ["partSelect","chapterSelect"].forEach(prefix=>{
    const menu=$(prefix+"Menu"), trigger=$(prefix+"Trigger");
    if(menu)menu.hidden=true;
    if(trigger)trigger.setAttribute("aria-expanded","false");
   });
  }
 });
 appSelectOutsideClickBound = true;
}
/* Populate Chapter Selector & subject-aware Personalized Topics */
function renderPersonalizedChapterChoices(){
 const topicsList=$("persTopicsList");
 const previous=new Map();
 topicsList.querySelectorAll(".pers-ch-cb").forEach(cb=>previous.set(cb.value,cb.checked));
 const selectedBankIndexes=Array.from(document.querySelectorAll(".pers-subject-cb:checked"))
  .map(cb=>parseInt(cb.value,10)).filter(Number.isInteger);
 const rows=[];
 selectedBankIndexes.forEach(bankIdx=>{
  const bank=SUBJECT_BANKS[bankIdx];
  if(!bank) return;
  bank.chapters.forEach((ch,chIdx)=>{
   const value=`${bankIdx}:${chIdx}`;
   const checked=previous.has(value) ? previous.get(value) : true;
   rows.push(`<label class="pers-check">
    <input type="checkbox" class="pers-ch-cb" data-bank-idx="${bankIdx}" data-chapter-idx="${chIdx}" value="${value}" ${checked?"checked":""}>
    <span>${SUBJECT_BANKS.length>1?`<strong>${esc(bank.name)}</strong> · `:""}Chapter ${esc(ch.chapter_no)}: ${esc(ch.title)}</span>
   </label>`);
  });
 });
 topicsList.innerHTML=rows.length ? rows.join("") : '<div class="home-recent-empty">Select at least one subject to view its chapters.</div>';
}

/* Phase 1 — App-wide Data Integrity, Storage Failure Feedback and Full Backup/Restore. */
const APP_BACKUP_SCHEMA="mock-test-studio-full-backup";
const APP_BACKUP_VERSION=1;
const APP_BACKUP_KEYS=[
 "mock_studio_600_v6",
 "mockStudio.questionBanks.v1",
 "mockStudio.questionBankDeletions.v1",
 "mockStudio.questionBankLocks.v1",
 "mockTestStudio.resultHistory.v1",
 "mockTestStudio.resultHistoryArchive.v1",
 "mockStudio.reviewReattemptMode.v1",
 "mockStudio.bookmarkReviewAnswers.v1",
 "mockStudio.savedReviewRetakeAnswers.v1",
 "mockStudio.bookmarkReviewRetakeAnswers.v1",
 "mockStudio.exitPosition.study",
 "mockStudio.exitPosition.test"
];
function appSetBackupStatus(message,kind){
 const el=$("appBackupStatus");if(!el)return;
 el.hidden=false;
 el.textContent=message;el.dataset.kind=kind||"";
}
function appShowStorageWarning(message){
 let el=$("appStorageWarning");
 if(!el){el=document.createElement("div");el.id="appStorageWarning";el.setAttribute("role","alert");el.setAttribute("aria-live","assertive");document.body.appendChild(el);}
 el.textContent=message;el.classList.add("show");
}
function appHideStorageWarning(){const el=$("appStorageWarning");if(el)el.classList.remove("show");}
function appCollectBackup(){
 const data={};
 APP_BACKUP_KEYS.forEach(key=>{const value=localStorage.getItem(key);if(value!==null)data[key]=value;});
 return {schema:APP_BACKUP_SCHEMA,version:APP_BACKUP_VERSION,createdAt:new Date().toISOString(),app:"Mock Test Studio",keys:data,summary:{storedKeys:Object.keys(data).length,questionBankRecords:(()=>{try{return JSON.parse(data["mockStudio.questionBanks.v1"]||"[]").length}catch(_){return 0}})(),savedResults:(()=>{try{return JSON.parse(data["mockTestStudio.resultHistory.v1"]||"[]").length}catch(_){return 0}})()}};
}
function appDownloadBackup(){
 try{
  const backup=appCollectBackup();
  const blob=new Blob([JSON.stringify(backup,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob),a=document.createElement("a");
  const stamp=new Date().toISOString().replace(/[:.]/g,"-");
  a.href=url;a.download="Mock_Test_Studio_Full_Backup_"+stamp+".json";
  document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
  appSetBackupStatus("Full backup downloaded. It contains "+backup.summary.storedKeys+" app data sections, including bookmarks, settings, question-bank changes, saved results and review answers.","success");
  appHideStorageWarning();
 }catch(err){
  appSetBackupStatus("Backup could not be created: "+(err&&err.message?err.message:"browser error"),"error");
  appShowStorageWarning("Full Backup could not be created. Check available device storage and try again.");
 }
}
function appValidateBackup(raw){
 if(!raw||typeof raw!=="object"||raw.schema!==APP_BACKUP_SCHEMA||raw.version!==APP_BACKUP_VERSION||!raw.keys||typeof raw.keys!=="object"||Array.isArray(raw.keys))throw new Error("This is not a supported Mock Test Studio Full Backup file.");
 const allowed=new Set(APP_BACKUP_KEYS),clean={};
 Object.keys(raw.keys).forEach(key=>{
  if(!allowed.has(key)&&!/^mockStudio\.exitPosition\.[a-zA-Z0-9_-]+$/.test(key))throw new Error("Backup contains an unrecognised data section: "+key);
  if(typeof raw.keys[key]!=="string")throw new Error("Backup data section is invalid: "+key);
  // Validate each serialized value before touching existing app data.
  const parsed=JSON.parse(raw.keys[key]);
  if((key==="mockTestStudio.resultHistory.v1"||key==="mockTestStudio.resultHistoryArchive.v1")&&!Array.isArray(parsed))throw new Error("Saved Test Results section is invalid.");
  if(key==="mockStudio.questionBanks.v1"&&!Array.isArray(parsed))throw new Error("Question Bank section is invalid.");
  if(key==="mockStudio.questionBankDeletions.v1"&&(!parsed||typeof parsed!=="object"))throw new Error("Question Bank deletion data is invalid.");
  if(key==="mockStudio.questionBankLocks.v1"&&(!parsed||typeof parsed!=="object"))throw new Error("Question Bank lock data is invalid.");
  clean[key]=raw.keys[key];
 });
 if(!Object.keys(clean).length)throw new Error("The backup does not contain any app data.");
 return clean;
}
function appRestoreBackupData(clean){
 const dynamicPositionKeys=Object.keys(localStorage).filter(k=>/^mockStudio\.exitPosition\.[a-zA-Z0-9_-]+$/.test(k));
 const restoreKeys=Array.from(new Set([...APP_BACKUP_KEYS,...dynamicPositionKeys,...Object.keys(clean).filter(k=>/^mockStudio\.exitPosition\.[a-zA-Z0-9_-]+$/.test(k))]));
 const before={};restoreKeys.forEach(k=>before[k]=localStorage.getItem(k));
 try{
  // Preflight quota with a temporary value before replacing any user data.
  const probe="__mts_backup_preflight__";
  localStorage.setItem(probe,"1");localStorage.removeItem(probe);
  restoreKeys.forEach(k=>{if(Object.prototype.hasOwnProperty.call(clean,k))localStorage.setItem(k,clean[k]);else localStorage.removeItem(k);});
  return true;
 }catch(err){
  // Best-effort rollback: never leave a partially restored set if one key fails.
  restoreKeys.forEach(k=>{try{if(before[k]===null)localStorage.removeItem(k);else localStorage.setItem(k,before[k]);}catch(_){}});
  throw new Error("Restore failed because browser storage is full or unavailable. Existing data was rolled back where the browser allowed it. Free storage and retry.");
 }
}
async function appHandleBackupFile(file){
 if(!file)return;
 try{
  const raw=JSON.parse(await file.text());
  const clean=appValidateBackup(raw);
  const summary=raw.summary||{};
  const confirmText="Restore this Full Backup?\n\nBackup date: "+(raw.createdAt||"Unknown")+
   "\nData sections: "+Object.keys(clean).length+
   "\nSaved results: "+(Number(summary.savedResults)||0)+
   "\n\nThis replaces the current Mock Test Studio data on this browser. Download a backup of the current data first if you may need it.";
  if(!window.confirm(confirmText)){appSetBackupStatus("Restore cancelled. Current data was not changed.","");return;}
  appRestoreBackupData(clean);
  appSetBackupStatus("Backup restored successfully. The app will reload to activate the restored data.","success");
  setTimeout(()=>window.location.reload(),900);
 }catch(err){
  appSetBackupStatus(err&&err.message?err.message:"Backup file could not be restored.","error");
 }
}
$("appCreateBackupBtn").addEventListener("click",appDownloadBackup);
$("appRestoreBackupBtn").addEventListener("click",()=>{$("appBackupFileInput").value="";$("appBackupFileInput").click();});
$("appBackupFileInput").addEventListener("change",e=>appHandleBackupFile(e.target.files&&e.target.files[0]));

function populateChapters(){
 const subjectSel=$("partSelect");
 if(subjectSel){
  subjectSel.innerHTML=SUBJECT_BANKS.map((bank,idx)=>`<option value="${idx}">${esc(bank.name)}</option>`).join("");
  if(state.subjectIdx<0||state.subjectIdx>=SUBJECT_BANKS.length)state.subjectIdx=0;
  subjectSel.value=String(state.subjectIdx);
 }
 activeSubjectBank=SUBJECT_BANKS[state.subjectIdx]||SUBJECT_BANKS[0]||null;
 CHAPTERS=activeSubjectBank?activeSubjectBank.chapters:DATA.chapters;
 if(state.chapterIdx<0||state.chapterIdx>=CHAPTERS.length)state.chapterIdx=0;
 const sel=$("chapterSelect");
 sel.innerHTML=CHAPTERS.map((ch,idx)=>
  `<option value="${idx}">Chapter ${ch.chapter_no}: ${esc(ch.title)}</option>`
 ).join("");
 sel.value=String(state.chapterIdx);
 refreshAppSelect("partSelect");
 refreshAppSelect("chapterSelect");

 $("persSubjectsList").innerHTML=SUBJECT_BANKS.map((bank,idx)=>{
  const count=bank.chapters.reduce((sum,ch)=>sum+(Array.isArray(ch.questions)?ch.questions.length:0),0);
  return `<label class="pers-check">
   <input type="checkbox" class="pers-subject-cb" value="${idx}" checked>
   <span>${esc(bank.name)} <small>(${count} Q)</small></span>
  </label>`;
 }).join("");
 renderPersonalizedChapterChoices();
 updatePersonalizedMatchCount();
 updateHomeChapterLabel();
}
function handleMainSubjectChange(value){
 const nextIndex=Number(value);
 if(!Number.isInteger(nextIndex)||!SUBJECT_BANKS[nextIndex])return;
 // Protect an active test/review session from being switched underneath the user.
 if(!isHomeDashboard){
  const current=Number.isInteger(state.subjectIdx)?state.subjectIdx:0;
  $("partSelect").value=String(current);
  refreshAppSelect("partSelect");
  return;
 }
 state.subjectIdx=nextIndex;
 activeSubjectBank=SUBJECT_BANKS[nextIndex];
 CHAPTERS=activeSubjectBank.chapters;
 state.chapterIdx=0;
 state.customSession=null;
 state.reviewFilter="all";
 const chapterSel=$("chapterSelect");
 chapterSel.innerHTML=CHAPTERS.map((ch,idx)=>`<option value="${idx}">Chapter ${ch.chapter_no}: ${esc(ch.title)}</option>`).join("");
 chapterSel.value=CHAPTERS.length?"0":"";
 refreshAllAppSelects();
 saveState();
 updateHomeChapterLabel();
 renderExitedTestHomeState();
}

let pendingTimerPrefs = null;
let pendingAnswerMode = null;
function beginTimerSettingsDraft(){
 pendingTimerPrefs = {
  timerMode: state.timerMode,
  autoNextOnTimeout: state.autoNextOnTimeout,
  customPerSec: state.customPerSec,
  customChapterMin: state.customChapterMin
 };
 refreshTimerLabels();
 syncPopoverControls();
}
function beginAnswerSettingsDraft(){
 pendingAnswerMode = state.answerMode;
 syncPopoverControls();
}
function cancelTimerSettingsDraft(){
 pendingTimerPrefs = null;
 refreshTimerLabels();
 syncPopoverControls();
}
function cancelAnswerSettingsDraft(){
 pendingAnswerMode = null;
 syncPopoverControls();
}
function syncPopoverControls(){
 const timerMode = pendingTimerPrefs ? pendingTimerPrefs.timerMode : state.timerMode;
 const answerMode = pendingAnswerMode || state.answerMode;
 document.querySelectorAll("[data-timer-mode]").forEach(btn => {
  btn.classList.toggle("active", btn.dataset.timerMode === timerMode);
 });
 document.querySelectorAll("[data-answer-mode]").forEach(btn => {
  btn.classList.toggle("active", btn.dataset.answerMode === answerMode);
 });
 $("autoNextCheck").checked = pendingTimerPrefs ? pendingTimerPrefs.autoNextOnTimeout : state.autoNextOnTimeout;
 if(pendingTimerPrefs){
  $("customPerSecInput").value = String(pendingTimerPrefs.customPerSec);
  $("customChapMinInput").value = String(pendingTimerPrefs.customChapterMin);
 }
}

function syncBookmarkBadge(){
 const ids = Object.keys(state.bookmarks).filter(k => state.bookmarks[k] && Q_MAP.has(k));
 const badge = $("bmkCountBadge");
 badge.textContent = String(ids.length);
 badge.classList.toggle("visible", ids.length > 0);
}

function closePopovers(){
 $("timerPopover").classList.remove("open");
 $("modePopover").classList.remove("open");
 $("timerMenuBtn").setAttribute("aria-expanded", "false");
 $("modeMenuBtn").setAttribute("aria-expanded", "false");
 if(pendingTimerPrefs) cancelTimerSettingsDraft();
 if(pendingAnswerMode) cancelAnswerSettingsDraft();
}

const RESULT_HISTORY_KEY = "mockTestStudio.resultHistory.v1";
let pendingResetAction = null;
function loadResultHistory(){
 const hk=RESULT_HISTORY_KEY,ak="mockTestStudio.resultHistoryArchive.v1";
 try{
  const mainRaw=localStorage.getItem(hk),archiveRaw=localStorage.getItem(ak);
  const main=mainRaw?JSON.parse(mainRaw):[],archive=archiveRaw?JSON.parse(archiveRaw):[];
  if(!Array.isArray(main)||!Array.isArray(archive))throw new Error("Invalid history");
  const seen=new Set();
  return [...main,...archive].filter(x=>{
   if(!x||typeof x!=="object")return false;
   const id=String(x.id||"");if(id&&seen.has(id))return false;if(id)seen.add(id);return true;
  }).map(item=>{
   if(Array.isArray(item.details))item.details=item.details.map(d=>({...d,questionId:migrateSubjectScopedId(d.questionId)}));
   if(Array.isArray(item.customQuestionIds))item.customQuestionIds=item.customQuestionIds.map(migrateSubjectScopedId);
   return item;
  }).sort((a,b)=>String(b.submittedAt||"").localeCompare(String(a.submittedAt||"")));
 }catch(_){
  appShowStorageWarning("Saved Test Results or its archive could not be read. Existing data has been preserved. Download a Full Backup before attempting recovery.");
  return [];
 }
}
function saveResultHistory(items){
 const hk=RESULT_HISTORY_KEY,ak="mockTestStudio.resultHistoryArchive.v1";
 const oldH=localStorage.getItem(hk),oldA=localStorage.getItem(ak);
 try{
  if(oldH!==null&&!Array.isArray(JSON.parse(oldH)))throw new Error("Invalid history");
  if(oldA!==null&&!Array.isArray(JSON.parse(oldA)))throw new Error("Invalid archive");
  const seen=new Set();
  const all=(Array.isArray(items)?items:[]).filter(x=>{
   if(!x||typeof x!=="object")return false;
   const id=String(x.id||"");if(id&&seen.has(id))return false;if(id)seen.add(id);return true;
  }).sort((a,b)=>String(b.submittedAt||"").localeCompare(String(a.submittedAt||"")));
  localStorage.setItem(ak,JSON.stringify(all.slice(100)));
  localStorage.setItem(hk,JSON.stringify(all.slice(0,100)));
  if(typeof homeStudySnapshotCache!=="undefined")homeStudySnapshotCache.at=0;
  return true;
 }catch(_){
  try{if(oldH===null)localStorage.removeItem(hk);else localStorage.setItem(hk,oldH);}catch(_){}
  try{if(oldA===null)localStorage.removeItem(ak);else localStorage.setItem(ak,oldA);}catch(_){}
  appShowStorageWarning("Saved Test Results could not be safely updated. Existing records were restored; download a Full Backup before continuing.");
  return false;
 }
}

function makeAttemptRecord(sess, cs, st){
 const now = new Date();
 const detailRows = sess.questions.map((q, idx) => {
  const chosen = cs.answers[idx] || null;
  return {
   number: idx + 1,
   questionId: q.id,
   subjectName: q.subject_name || "",
   chapterTitle: q.chapter_title || sess.title || "",
   subheading: q.subheading || "",
   difficulty: q.difficulty || "",
   questionType: q.question_type || "single_correct",
   question: q.question,
   options: q.options,
   selected: chosen,
   visited: !!(cs.visited && cs.visited[idx]),
   correctAnswer: q.answer,
   verification_note: String(q.verification_note||""),
   explanation: q.explanation,
   status: !chosen ? "skipped" : (chosen === q.answer ? "correct" : "wrong"),
   marked: !!cs.marked[idx],
   bookmarked: !!state.bookmarks[q.id]
  };
 });
 const answered = st.answered || 0;
 return {
  id: "attempt-" + now.getTime() + "-" + Math.random().toString(36).slice(2,8),
  submittedAt: now.toISOString(),
  displayDate: now.toLocaleString(),
  chapterKey: sess.key,
  chapterNo: sess.chapter_no || null,
  chapterTitle: sess.title || "Custom Test",
  isCustom: !!sess.isCustom,
  customQuestionIds: sess.isCustom&&state.customSession?state.customSession.questionIds.slice():undefined,
  customDurationMinutes: sess.isCustom&&state.customSession?state.customSession.durationMinutes:undefined,
  markingScheme: sess.isCustom&&state.customSession?state.customSession.markingScheme:"upsc",
  total: st.total,
  answered: st.answered,
  correct: st.correct,
  wrong: st.wrong,
  skipped: st.skipped,
  marked: st.marked,
  accuracy: answered ? Math.round((st.correct / answered) * 100) : 0,
  scorePercent: st.total ? Math.round((st.correct / st.total) * 100) : 0,
  elapsedSec: Number(cs.elapsedSec || 0),
  timerMode: getActiveTimerMode(sess),
  answerMode: state.answerMode,
  details: detailRows
 };
}
function formatDuration(sec){
 const n = Math.max(0, Number(sec)||0);
 const h = Math.floor(n/3600), m = Math.floor((n%3600)/60), s = n%60;
 return h ? `${h}h ${m}m ${s}s` : `${m}m ${s}s`;
}
let activeHistoryAttemptId = null;

let homeStudySnapshotCache={at:0,html:"",weakHTML:"",trendHTML:""};
function renderHomeStudySnapshot(force){
 const now=Date.now();
 if(!force&&now-homeStudySnapshotCache.at<12000&&homeStudySnapshotCache.html){
  $("homeStudyKpis").innerHTML=homeStudySnapshotCache.html;
  $("homeWeakTopics").innerHTML=homeStudySnapshotCache.weakHTML;
  $("homeScoreTrend").innerHTML=homeStudySnapshotCache.trendHTML;
  return;
 }
 const qs=Array.from(Q_MAP.values());
 let answered=0,correct=0,wrong=0,visited=0;
 const topicMap=new Map();
 const customSession=state.chapters.custom_session;
 const customIndex=new Map();
 if(customSession&&state.customSession&&Array.isArray(state.customSession.questionIds)){
  state.customSession.questionIds.forEach((id,index)=>customIndex.set(id,index));
 }
 qs.forEach(q=>{
  const session=state.chapters[q.source_storage_key];
  let visitedThis=!!(session&&session.visited&&session.visited[q.orig_idx]);
  let selected=session&&session.answers&&session.answers[q.orig_idx];
  if(!selected&&customSession&&customIndex.has(q.id)){
   const customIdx=customIndex.get(q.id);
   selected=customSession.answers&&customSession.answers[customIdx];
   visitedThis=visitedThis||!!(customSession.visited&&customSession.visited[customIdx]);
  }
  if(visitedThis)visited++;
  if(!selected)return;
  answered++;
  if(selected===q.answer)correct++;
  else{
   wrong++;
   const topic=String(q.subheading||q.chapter_title||"Other topics");
   const row=topicMap.get(topic)||{topic,wrong:0};
   row.wrong++;topicMap.set(topic,row);
  }
 });
 const accuracy=answered?Math.round(correct/answered*100):0;
 const progress=qs.length?Math.round(answered/qs.length*100):0;
 const bookmarked=Object.keys(state.bookmarks||{}).filter(id=>state.bookmarks[id]&&Q_MAP.has(id)).length;
 const history=loadResultHistory();
 const average=history.length?Math.round(history.reduce((n,r)=>n+(Number(r.scorePercent)||0),0)/history.length):0;
 const kpis=[
  ["Questions answered",`${answered} / ${qs.length}`,"Saved practice answers"],
  ["Current accuracy",`${accuracy}%`,`${correct} correct · ${wrong} incorrect`],
  ["Bank coverage",`${progress}%`,`${answered} answered · ${visited} visited`],
  ["Bookmarked",String(bookmarked),"Questions saved for revision"]
 ];
 homeStudySnapshotCache.html=kpis.map(([label,value,note])=>`<article class="home-study-kpi"><span>${label}</span><strong>${value}</strong><small>${note}</small></article>`).join("");
 const weak=[...topicMap.values()].sort((a,b)=>b.wrong-a.wrong||a.topic.localeCompare(b.topic)).slice(0,3);
 homeStudySnapshotCache.weakHTML=weak.length
  ?weak.map((row,i)=>`<div class="home-weak-row"><span class="home-weak-rank">${i+1}</span><span class="home-weak-name">${esc(row.topic)}</span><strong>${row.wrong} wrong</strong></div>`).join("")
  :'<p class="home-study-muted">No weak topics detected from saved answers yet.</p>';
 const trend=history.slice(0,5).reverse();
 homeStudySnapshotCache.trendHTML=trend.length
  ?`<div class="home-trend-bars">${trend.map((r,i)=>{const val=Math.max(0,Math.min(100,Number(r.scorePercent)||0));return `<div class="home-trend-col" title="${esc(r.chapterTitle||"Test")}: ${val}%"><span class="home-trend-value">${val}%</span><i style="height:${Math.max(4,val)}%"></i><small>${i+1}</small></div>`;}).join("")}</div><p class="home-study-muted">${history.length} saved test(s) · ${average}% average score</p>`
  :'<p class="home-study-muted">Complete a test to build your score trend.</p>';
 homeStudySnapshotCache.at=now;
 $("homeStudyKpis").innerHTML=homeStudySnapshotCache.html;
 $("homeWeakTopics").innerHTML=homeStudySnapshotCache.weakHTML;
 $("homeScoreTrend").innerHTML=homeStudySnapshotCache.trendHTML;
}
function renderHomeRecentResults(){
 renderHomeBookmarkedPreview();
 renderHomeStudySnapshot(false);
 const host=$("homeRecentResultsList");
 if(!host) return;
 const latest=loadResultHistory().slice(0,3);
 if(!latest.length){
  host.innerHTML='<div class="home-recent-empty">No saved test results yet.</div>';
  return;
 }
 host.innerHTML=latest.map(item=>`
  <article class="home-recent-item">
   <div class="home-recent-item-main">
    <strong class="home-recent-item-title">${esc(item.chapterTitle || "Test")}</strong>
    <small class="home-recent-item-date">${esc(item.displayDate || "")}</small>
    <div class="home-recent-item-kpis">
     <span class="correct">✓ ${Number(item.correct)||0} Correct</span>
     <span class="wrong">✕ ${Number(item.wrong)||0} Wrong</span>
     <span>— ${Number(item.skipped)||0} Skipped</span>
     <span>${Number(item.total)||0} Questions</span>
    </div>
   </div>
   <div class="home-recent-score">
    <strong>${Number(item.scorePercent)||0}%</strong>
    <button type="button" class="home-recent-open" data-home-attempt-id="${esc(item.id)}">View Result</button>
   </div>
  </article>`).join("");
}

function renderResultHistory(){
 const items = loadResultHistory();
 const summary = $("historySummary");
 const list = $("resultHistoryList");
 $("historyReviewPage").hidden = true;
 // The "Tests Saved" and "Average Score" statistic cards are intentionally removed.
 summary.hidden = true;
 summary.innerHTML = "";
 list.hidden = false;
 if(!items.length){
  list.innerHTML = `<div class="history-empty-state">No Results Yet</div>`;
  return;
 }
 list.innerHTML = items.map((item,idx)=>`
  <article class="history-attempt" data-history-id="${esc(item.id)}">
   <div class="history-attempt-head">
    <div><strong>${esc(item.chapterTitle || "Test")}</strong><small>${esc(item.displayDate || "")}</small></div>
    <span class="history-score">${Number(item.scorePercent)||0}%</span>
   </div>
   <div class="history-kpis">
    <span class="hk-correct">✓ ${Number(item.correct)||0} Correct</span>
    <span class="hk-wrong">✕ ${Number(item.wrong)||0} Wrong</span>
    <span>— ${Number(item.skipped)||0} Skipped</span>
    <span>${Number(item.total)||0} Total</span>
   </div>
   <div class="history-meta">Accuracy: ${Number(item.accuracy)||0}% · Time: ${formatDuration(item.elapsedSec)} · Answered: ${Number(item.answered)||0}</div>
   <div class="history-actions">
    <button type="button" class="act-btn history-details-btn" data-history-action="review" data-history-index="${idx}">View Test Results</button>
    ${item.isCustom&&Array.isArray(item.customQuestionIds)&&item.customQuestionIds.length?`<button type="button" class="act-btn" data-history-action="reattempt" data-history-index="${idx}">Reattempt Same Test</button>`:""}
    <button type="button" class="act-btn history-delete-btn" data-history-action="delete" data-history-index="${idx}">Delete</button>
   </div>
  </article>`).join("");
}
let activeHistoryFilter = "all";
let activeHistoryReviewPosition=0;
function renderSavedAttemptReview(item){
 const questions=Array.isArray(item.details)?item.details:[];
 const isBookmarked=d=>!!d.bookmarked||(!Object.prototype.hasOwnProperty.call(d,"bookmarked")&&!!state.bookmarks[d.questionId]);
 $("historySummary").hidden=true;
 $("resultHistoryList").hidden=true;
 $("historyReviewPage").hidden=false;
 $("historyReviewPage").setAttribute("aria-hidden","false");
 $("historyReviewSummary").hidden=false;
 $("historyReviewFilters").hidden=false;
 // The attempt title/date line was removed from the visible review layout.
 // Avoid referencing the removed historyReviewAttemptTitle element.

 $("historyReviewSummary").innerHTML=`
  <div class="history-review-stat"><strong>${Number(item.correct)||0}</strong><span>Correct</span></div>
  <div class="history-review-stat"><strong>${Number(item.wrong)||0}</strong><span>Incorrect</span></div>
  <div class="history-review-stat"><strong>${Number(item.skipped)||0}</strong><span>Skipped</span></div>
  <div class="history-review-stat"><strong>${Number(item.scorePercent)||0}%</strong><span>Score</span></div>`;
 const isAttempted=q=>!!q.selected;
 const isUnattempted=q=>!q.selected&&q.visited===false;
 const isSkipped=q=>!q.selected&&q.visited===true;
 const isUnclassified=q=>!q.selected&&typeof q.visited!=="boolean";
 const filters=[
  ["all","All",questions.length],
  ["attempted","Attempted",questions.filter(isAttempted).length],
  ["unattempted","Unattempted",questions.filter(isUnattempted).length],
  ["skipped","Skipped",questions.filter(isSkipped).length],
  ["unclassified","Unclassified",questions.filter(isUnclassified).length],
  ["marked","Mark for Review",questions.filter(q=>!!q.marked).length],
  ["correct","Correct",questions.filter(q=>q.status==="correct").length],
  ["wrong","Incorrect",questions.filter(q=>q.status==="wrong").length],
  ["bookmarked","Bookmarked",questions.filter(isBookmarked).length]
 ];
 $("historyReviewFilters").innerHTML=
  filters.map(([key,label,count])=>`<button type="button" class="history-filter-chip ${activeHistoryFilter===key?"active":""}" data-history-filter="${key}" aria-pressed="${activeHistoryFilter===key}">${label}<span>${count}</span></button>`).join("");
 let filtered=questions.map((d,idx)=>({d,idx})).filter(({d})=>{
  if(activeHistoryFilter==="attempted")return isAttempted(d);
  if(activeHistoryFilter==="unattempted")return isUnattempted(d);
  if(activeHistoryFilter==="skipped")return isSkipped(d);
  if(activeHistoryFilter==="unclassified")return isUnclassified(d);
  if(activeHistoryFilter==="correct")return d.status==="correct";
  if(activeHistoryFilter==="wrong")return d.status==="wrong";
  if(activeHistoryFilter==="bookmarked")return isBookmarked(d);
  if(activeHistoryFilter==="marked")return !!d.marked;
  return true;
 });
 const host=$("historyReviewQuestions");
 host.innerHTML="";
 if(!filtered.length){
  host.innerHTML='<div class="history-empty-state">No Questions Available in this saved test.</div>';
  return;
 }
 activeHistoryReviewPosition=Math.max(0,Math.min(activeHistoryReviewPosition,filtered.length-1));
 const {d,idx}=filtered[activeHistoryReviewPosition];
 const retakeKey=String(item.id)+"::"+String(d.questionId||idx);
 const retakeSelected=Object.prototype.hasOwnProperty.call(savedReviewRetakeAnswers,retakeKey)?savedReviewRetakeAnswers[retakeKey]:"";
 // Reattempt ON starts blank; original saved answer appears only in read-only OFF mode.
 const effectiveSelected=reviewReattemptMode?retakeSelected:(d.selected||"");
 const revealSavedAnswer=!reviewReattemptMode || !!effectiveSelected;
 const correctKeys=Array.isArray(d.correctAnswer)?d.correctAnswer.map(String):[String(d.correctAnswer||"")];
 const opts=Object.keys(d.options||{}).filter(k=>String(d.options[k]||"").trim()).map(letter=>{
  const isSelected=effectiveSelected===letter,isCorrect=correctKeys.includes(letter);
  let cls="opt-card history-static-option"+(reviewReattemptMode?" retake-choice":"");
  let tag="";
  if(revealSavedAnswer && isCorrect){cls+=" correct";tag='<span class="opt-tag">Correct Answer</span>';}
  if(revealSavedAnswer && isSelected&&!isCorrect){cls+=" wrong";tag='<span class="opt-tag">Your Choice</span>';}
  if(revealSavedAnswer && isSelected&&isCorrect)tag='<span class="opt-tag">Your Correct Answer</span>';
  const tagName=reviewReattemptMode?'button':'div';
  const buttonType=reviewReattemptMode?'type="button"':"";
  return `<${tagName} ${buttonType} class="${cls}" ${reviewReattemptMode?`data-saved-retake-answer="${esc(letter)}"`:""}><span class="opt-letter">${esc(letter)}</span><span class="opt-text">${formatInline((d.options||{})[letter]||"")}</span>${tag}</${tagName}>`;
 }).join("");
 const effectiveStatus=effectiveSelected?(correctKeys.includes(effectiveSelected)?"correct":"wrong"):(reviewReattemptMode?"unattempted":"skipped");
 const verdict=effectiveStatus==="correct"?'<span class="sol-verdict ok">Correct</span>':effectiveStatus==="wrong"?'<span class="sol-verdict bad">Incorrect</span>':effectiveStatus==="unattempted"?'<span class="sol-verdict neutral">Not Attempted</span>':'<span class="sol-verdict neutral">Skipped</span>';
 const answerText=correctKeys.filter(Boolean).map(k=>`(${esc(k)}) ${formatInline((d.options||{})[k]||"")}`).join(", ")||"Not available";
 const selectedText=effectiveSelected?`(${esc(effectiveSelected)}) ${formatInline((d.options||{})[effectiveSelected]||"")}`:"Not attempted";
 const questionId=d.questionId||"";const bookmarked=questionId?!!state.bookmarks[questionId]:isBookmarked(d);
 host.innerHTML=`<article class="history-review-question history-review-single-question ${savedReviewExpanded?"review-panel-expanded":""}" id="savedQuestion${idx+1}">
   <div class="saved-review-question-head">
    <div class="saved-review-topic-status">
     <span class="ch-chip">${esc(d.subjectName ? d.subjectName+" · " : "")}${esc(d.chapterTitle||item.chapterTitle||"Saved Test")}</span>
     ${d.subheading?`<span class="review-topic-chip">${esc(d.subheading)}</span>`:""}
     ${verdict}
    </div>
    <button type="button" class="review-reattempt-toggle ${reviewReattemptMode?"is-on":""}" data-review-reattempt aria-label="Reattempt mode ${reviewReattemptMode?"on":"off"}" aria-pressed="${reviewReattemptMode}" title="Reattempt ${reviewReattemptMode?"On":"Off"}">
     <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.4-3"/></svg>
    </button>
    ${questionId?`<button type="button" class="history-review-bookmark-icon ${bookmarked?"is-bookmarked":""}" data-history-bookmark="${esc(questionId)}" aria-label="${bookmarked?"Remove bookmark":"Add bookmark"}" aria-pressed="${bookmarked}" title="${bookmarked?"Remove bookmark":"Add bookmark"}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg></button>`:""}
    <button type="button" class="review-expand-btn" data-review-expand="saved" aria-label="${savedReviewExpanded?"Collapse question panel":"Expand question panel"}" title="${savedReviewExpanded?"Collapse":"Expand"}">
     ${savedReviewExpanded
       ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3v5H3M16 3v5h5M3 16h5v5M21 16h-5v5"/></svg>'
       : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/></svg>'}
    </button>
   </div>
   <div class="saved-review-scroll" tabindex="0" aria-label="Scrollable saved test question, options, answer and explanation. Scroll down for the explanation.">
    <div class="q-stem">${renderStemHTML(d.question||"")}</div>
    <div class="options-list history-review-options" role="group">${opts}</div>
    <div class="solution-box history-review-solution ${effectiveStatus==="wrong"?"is-wrong":""}" ${reviewReattemptMode&&!effectiveSelected?"hidden":""}>
    <div class="sol-head"><span>Answer &amp; Explanation</span>${verdict}</div>
    <div class="sol-body">
     <div class="history-review-answer"><strong>Your Answer:</strong> ${selectedText}</div>
     <div class="sol-ans-line"><strong>Correct Answer:</strong> ${answerText}</div>
     ${renderVerificationNoteHTML(d.verification_note)}
     <div class="sol-exp-title">Explanation</div>
     <div class="sol-exp-text">${renderExplanationHTML(d.explanation||"Explanation unavailable.")}</div>
    </div>
    </div>
   </div>
   <div class="history-review-single-nav saved-review-question-nav action-bar review-action-bar">
    <button type="button" class="act-btn" data-history-review-nav="prev" aria-label="Previous question" ${activeHistoryReviewPosition===0?"disabled":""}>← Previous</button>
    <span class="review-progress" aria-live="polite">Question ${activeHistoryReviewPosition+1} of ${filtered.length}</span>
    <button type="button" class="act-btn next-btn" data-history-review-nav="next" aria-label="Next question" ${activeHistoryReviewPosition===filtered.length-1?"disabled":""}>Next →</button>
   </div>
  </article>`;
}

function openSavedAttemptReview(index){
 savedReviewExpanded=false;
 const items = loadResultHistory();
 const item = items[index];
 if(!item) return;
 activeHistoryAttemptId = item.id;
 activeHistoryFilter = "all";
 activeHistoryReviewPosition=0;
 renderSavedAttemptReview(item);
 $("historyReviewPage").scrollTop = 0;
 $("resultHistoryModal").querySelector(".history-modal-card").scrollTop = 0;
}
function backToResultHistory(){
 activeHistoryAttemptId = null;
 $("historyReviewPage").hidden = true;
 $("historySummary").hidden = true;
 $("resultHistoryList").hidden = false;
 $("historyReviewQuestions").innerHTML = "";
}
function openResultHistory(){
 renderResultHistory();
 $("resultHistoryModal").classList.add("open");
}
function closeResultHistory(){ savedReviewExpanded=false; $("resultHistoryModal").classList.remove("open"); }

function computeStats(sess, cs){
 let answered = 0, notAnswered = 0, marked = 0, notVisited = 0;
 let correct = 0, wrong = 0, skipped = 0;
 sess.questions.forEach((q, idx) => {
  const ans = cs.answers[idx];
  const isM = !!cs.marked[idx];
  const isV = !!cs.visited[idx];
  if(ans){
   answered++;
   if(ans === q.answer) correct++; else wrong++;
  } else {
   skipped++;
   if(isV) notAnswered++; else notVisited++;
  }
  if(isM) marked++;
 });
 return { answered, notAnswered, marked, notVisited, correct, wrong, skipped, total: sess.questions.length };
}

let solutionPanelOpen = false;
let solutionHideTimer = null;
function clearSolutionHideTimer(){ if(solutionHideTimer){ clearTimeout(solutionHideTimer); solutionHideTimer=null; } }
function scheduleSolutionAutoHide(){
 clearSolutionHideTimer();
 const seconds = Number(state.explanationAutoHideSec);
 if(seconds > 0 && document.getElementById("instantSolutionOverlay")){
  solutionHideTimer = setTimeout(() => {
   solutionPanelOpen = false;
   const panel = document.getElementById("instantSolutionOverlay");
   if(panel) panel.remove();
   solutionHideTimer = null;
  }, seconds * 1000);
 }
}
function solutionPanelMarkup(q, boxCls, verdictHTML){
 return `<div class="solution-overlay" id="instantSolutionOverlay"><div class="solution-box ${boxCls}">
  <div class="sol-head">
   <button type="button" class="sol-pencil" data-solution-action="settings" aria-label="Auto-close time settings" title="Auto-close time">✎</button>
   <span>Answer &amp; Explanation</span>${verdictHTML}
   <button type="button" class="sol-close" data-solution-action="close" aria-label="Close answer and explanation" title="Close">×</button>
  </div><div class="sol-body"><div class="sol-ans-line">Correct Answer: (${q.answer}) ${formatInline(q.options[q.answer])}</div>
   ${renderVerificationNoteHTML(q.verification_note)}
   <div class="sol-exp-title">Explanation</div><div class="sol-exp-text">${renderExplanationHTML(q.explanation)}</div>
  </div></div></div>`;
}


function questionPaletteStatus(cs, idx){
 if(cs.marked && cs.marked[idx]) return "review";
 if(cs.answers && cs.answers[idx]) return "answered";
 if(!cs.visited || !cs.visited[idx]) return "not-visited";
 return "visited";
}
function renderQuestionPalette(){
 const grid=$("questionPaletteGrid");
 if(!grid) return;
 const sess=getActiveSession(), cs=getSessionState(sess);
 const counts = {"answered":0,"review":0,"not-visited":0,"visited":0};
 grid.innerHTML=sess.questions.map((q,i)=>{
  const status=questionPaletteStatus(cs,i);
  counts[status] = (counts[status] || 0) + 1;
  return `<button type="button" class="palette-question ${status}${i===cs.currentIdx?" current":""}" data-palette-index="${i}" aria-label="Question ${i+1}: ${status.replace("-"," ")}" title="Question ${i+1}">${i+1}</button>`;
 }).join("");
 $("questionPaletteStats").innerHTML = [
  ["answered","Answered",counts.answered],
  ["review","Marked for Review",counts.review],
  ["not-visited","Not Visited",counts["not-visited"]],
  ["visited","Visited",counts.visited]
 ].map(([key,label,count])=>`<div class="palette-stat ${key}"><strong>${count}</strong><span>${label}</span></div>`).join("");
}
function positionQuestionPalette(){
 const trigger=$("questionPaletteBtn"), sheet=$("questionPaletteSheet");
 if(!trigger || !sheet) return;
 const r=trigger.getBoundingClientRect();
 const margin=10;
 const w=sheet.getBoundingClientRect().width || Math.min(326,window.innerWidth-20);
 const h=sheet.getBoundingClientRect().height || Math.min(420,window.innerHeight-20);
 const left=Math.max(margin,Math.min(window.innerWidth-w-margin,r.right-w));
 let top=r.bottom+8;
 if(top+h>window.innerHeight-margin) top=Math.max(margin,r.top-h-8);
 sheet.style.left=Math.round(left)+"px";
 sheet.style.top=Math.round(top)+"px";
}
function openQuestionPalette(){
 renderQuestionPalette();
 const overlay=$("questionPaletteOverlay");
 overlay.classList.add("open");
 overlay.setAttribute("aria-hidden","false");
 document.body.classList.add("palette-open");
 requestAnimationFrame(positionQuestionPalette);
}
function closeQuestionPalette(){
 const overlay=$("questionPaletteOverlay");
 if(!overlay) return;
 overlay.classList.remove("open");
 overlay.setAttribute("aria-hidden","true");
 document.body.classList.remove("palette-open");
}
$("questionPaletteBtn").addEventListener("click",e=>{
 e.stopPropagation();
 if($("questionPaletteOverlay").classList.contains("open")) closeQuestionPalette();
 else openQuestionPalette();
});
$("closeQuestionPalette").addEventListener("click",closeQuestionPalette);
$("questionPaletteOverlay").addEventListener("click",e=>{
 if(e.target===$("questionPaletteOverlay")) closeQuestionPalette();
});
window.addEventListener("resize",()=>{
 if($("questionPaletteOverlay").classList.contains("open")) positionQuestionPalette();
});
window.addEventListener("scroll",()=>{
 if($("questionPaletteOverlay").classList.contains("open")) positionQuestionPalette();
},true);

$("questionPaletteGrid").addEventListener("click",e=>{
 const tile=e.target.closest("[data-palette-index]");
 if(!tile) return;
 const idx=Number(tile.dataset.paletteIndex);
 const sess=getActiveSession(), cs=getSessionState(sess);
 goToQuestion(idx, idx>cs.currentIdx?"next":"prev");
 closeQuestionPalette();
});
document.addEventListener("keydown",e=>{
 if(e.key==="Escape") closeQuestionPalette();
});

/* Render Question Card */
function renderQuestion(slideDir){
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 const qIdx = cs.currentIdx;
 const q = sess.questions[qIdx];
 cs.visited[qIdx] = true;

 const total = sess.questions.length;
 $("qCounterBadge").textContent = `${qIdx + 1} out of ${total} Questions`;
 if($("questionPaletteOverlay")?.classList.contains("open")) renderQuestionPalette();
 $("qChapterBadge").textContent = `Chapter ${q.chapter_no}: ${q.chapter_title}`;
 $("qSubheadBadge").textContent = q.subheading || q.chapter_title;

 const isBmk = !!state.bookmarks[q.id];
 const bmkBtn = $("topBookmarkBtn");
 const bmkSvg = $("topBookmarkSvg");
 bmkBtn.classList.toggle("is-bookmarked", isBmk);
 bmkBtn.title = isBmk ? "Remove Bookmark" : "Bookmark this question";
 bmkSvg.setAttribute("fill", isBmk ? "currentColor" : "none");

 const selected = cs.answers[qIdx] || null;
 const isReview = cs.submitted;
 const showInstant = (state.answerMode === "instant" && !!selected);
 const isInstantWrong = showInstant && selected !== q.answer;
 const revealSolution = isReview || isInstantWrong;

 const card = $("questionCard");
 card.classList.remove("anim-next", "anim-prev");
 if(slideDir === "next"){ void card.offsetWidth; card.classList.add("anim-next"); }
 else if(slideDir === "prev"){ void card.offsetWidth; card.classList.add("anim-prev"); }

 const optsHTML = ["A","B","C","D"].map(letter => {
  let cls = "opt-card";
  let tag = "";
  const isSel = selected === letter;
  const isRight = q.answer === letter;
  if(revealSolution){
   if(isRight){
    cls += " correct";
    tag = '<span class="opt-tag">✓ Correct</span>';
   } else if(isSel && !isRight){
    cls += " wrong";
    tag = '<span class="opt-tag">✗ Your Choice</span>';
   }
  } else if(isSel){
   cls += " selected";
   tag = '<span class="opt-tag" style="background:var(--primary);color:#fff">Selected</span>';
  }
  const timedOut = getActiveTimerMode(sess) === "per30" && !!cs.qTimedOut[qIdx] && !selected;
  const disabledAttr = (isReview || timedOut || (state.answerMode === "instant" && !!selected)) ? " disabled" : "";
  return `<button type="button" class="${cls}" data-opt="${letter}"${disabledAttr}>
   <span class="opt-letter">${letter}</span>
   <span class="opt-text">${formatInline(q.options[letter])}</span>
   ${tag}
  </button>`;
 }).join("");

 // Retry is available only for an unanswered question whose per-question timer expired.
 const timedOutNow=getActiveTimerMode(sess)==="per30"&&!!cs.qTimedOut[qIdx]&&!selected;
 let timeoutHTML=timedOutNow
  ? `<div class="timer-timeout-recovery" role="status"><strong>Time is up for this question.</strong><button type="button" class="act-btn" data-retry-question-timer>Retry this question (${getPerQuestionSec()} sec)</button></div>`
  : "";

 let solHTML = "";
 let belowExpHTML = "";
 let boxCls = "solution-box";
 let verdictHTML = "";
 const expBoxEl = $("belowActionExpBox");
 if(revealSolution){
  boxCls = "solution-box";
  verdictHTML = "";
  if(!selected){
   boxCls += " is-unattempted";
   verdictHTML = '<span class="sol-verdict neutral">Unattempted</span>';
  } else if(selected === q.answer){
   verdictHTML = '<span class="sol-verdict ok">✓ Correct</span>';
  } else {
   boxCls += " is-wrong";
   verdictHTML = `<span class="sol-verdict bad">✗ Incorrect (${selected})</span>`;
  }

  if(state.answerMode === "instant" && !isReview){
   /* Keep the question card full-size. Incorrect answers open an overlay; correct answers require a manual tap. */
   solHTML = "";
   belowExpHTML = "";
  } else {
   solHTML = `<div class="${boxCls}">
    <div class="sol-head">
     <span>Solution &amp; Explanation</span>
     ${verdictHTML}
    </div>
    <div class="sol-body">
     <div class="sol-ans-line">Correct Answer: (${q.answer}) ${formatInline(q.options[q.answer])}</div>
     ${renderVerificationNoteHTML(q.verification_note)}
     <div class="sol-exp-title">Explanation</div>
     <div class="sol-exp-text">${renderExplanationHTML(q.explanation)}</div>
    </div>
   </div>`;
  }
 }

 if(expBoxEl){
  if(belowExpHTML){
   expBoxEl.style.display = "block";
   expBoxEl.innerHTML = belowExpHTML;
  } else {
   expBoxEl.style.display = "none";
   expBoxEl.innerHTML = "";
  }
 }

 if(expBoxEl){ expBoxEl.style.display = "none"; expBoxEl.innerHTML = ""; }
 const instantMode = state.answerMode === "instant" && !isReview;
 const answerIconDisabled = instantMode && !selected;
 const showOverlay = instantMode && !!selected && (solutionPanelOpen || isInstantWrong);
 const settingsOptions = [0,3,5,8,10,15,20].map(v=>`<option value="${v}" ${state.explanationAutoHideSec===v?'selected':''}>${v===0?'Never hide':v+' seconds'}</option>`).join("");
 // Calculate solved progress before building HTML that displays it.
 const solvedCount=Object.values(cs.answers).filter(answer=>["A","B","C","D"].includes(answer)).length;
 const progressPct=Math.round((solvedCount/Math.max(1,total))*100);
 const toolsHTML = `<div class="solution-tools">
  <span class="question-solved-badge" aria-label="${progressPct}% of questions solved">${progressPct}% solved</span>
  ${instantMode ? `<button type="button" class="solution-tool-btn" data-solution-action="toggle" ${answerIconDisabled?'disabled':''} title="Show answer and explanation" aria-label="Show answer and explanation">ⓘ</button>` : ""}
 </div>`;
 const panelBoxCls = selected && selected !== q.answer ? "solution-box is-wrong" : "solution-box";
 const panelVerdictHTML = selected ? (selected === q.answer ? '<span class="sol-verdict ok">✓ Correct</span>' : `<span class="sol-verdict bad">✗ Incorrect (${selected})</span>`) : "";
 const overlayHTML = showOverlay ? solutionPanelMarkup(q, panelBoxCls, panelVerdictHTML) : "";
 const questionProgressHTML=`<div class="question-progress-strip" aria-label="Question progress">
  <div class="question-progress-label"><span>Question ${qIdx+1} of ${total}</span></div>
  <div class="question-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${total}" aria-valuenow="${solvedCount}" aria-valuetext="${solvedCount} of ${total} questions solved"><span style="width:${progressPct}%"></span></div>
 </div>`;
 card.innerHTML = `${questionProgressHTML}${toolsHTML}<div class="q-stem">${renderStemHTML(q.question)}</div>
  <div class="options-list" role="group" aria-label="Answer Options">${optsHTML}</div>${timeoutHTML}${solHTML}${overlayHTML}`;
 if(showOverlay && instantMode) scheduleSolutionAutoHide(); else clearSolutionHideTimer();
 card.scrollTop = 0;

 $("prevBtn").disabled = (qIdx === 0);
 $("nextBtn").disabled = (qIdx === total - 1);

 const markBtn = $("markBtn");
 const isMarked = !!cs.marked[qIdx];
 markBtn.classList.toggle("is-marked", isMarked);
 markBtn.textContent = isMarked ? "★ Marked" : "★ Mark for Review";
 markBtn.disabled = isReview;

 $("clearBtn").disabled = (isReview || !selected);
 $("submitBtn").textContent = isReview ? "Scorecard" : "Final Submit";

 renderPaletteTable();
 syncTimerUI();
}

/* Render Collapsible Question Palette Table */
function renderPaletteTable(){
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 const stats = computeStats(sess, cs);

 $("stAnsCount").textContent = stats.answered;
 $("stNotAnsCount").textContent = stats.notAnswered;
 $("stMarkCount").textContent = stats.marked;
 $("stUnvisCount").textContent = stats.notVisited;
 $("palSummaryInline").textContent = `${stats.answered}/${stats.total}`;

 const filterBar = $("palFilterBar");
 filterBar.style.display = cs.submitted ? "flex" : "none";
 if(cs.submitted){
  filterBar.querySelectorAll(".pal-filter").forEach(b => {
   b.classList.toggle("active", b.dataset.filter === state.reviewFilter);
  });
 }

 const tbody = $("paletteTableBody");
 tbody.innerHTML = sess.questions.map((q, idx) => {
  const ans = cs.answers[idx];
  const isM = !!cs.marked[idx];
  const isV = !!cs.visited[idx];
  let badgeCls = "tbl-qnum";
  let statusLabel = "Not Visited";

  if(cs.submitted){
   if(ans === q.answer){ badgeCls += " st-correct"; statusLabel = "Correct"; }
   else if(ans){ badgeCls += " st-wrong"; statusLabel = "Wrong"; }
   else { badgeCls += " st-not-answered"; statusLabel = "Skipped"; }
  } else if(state.answerMode === "instant" && ans){
   if(ans === q.answer){ badgeCls += " st-correct"; statusLabel = "Correct"; }
   else { badgeCls += " st-wrong"; statusLabel = "Wrong"; }
  } else {
   if(ans && isM){ badgeCls += " st-ans-marked"; statusLabel = "Answered & Marked"; }
   else if(isM){ badgeCls += " st-marked"; statusLabel = "Marked"; }
   else if(ans){ badgeCls += " st-answered"; statusLabel = "Answered"; }
   else if(isV){ badgeCls += " st-not-answered"; statusLabel = "Not Answered"; }
  }

  let rowCls = (idx === cs.currentIdx) ? "is-current-row" : "";
  if(cs.submitted){
   const hide =
    (state.reviewFilter === "correct" && ans !== q.answer) ||
    (state.reviewFilter === "wrong" && (!ans || ans === q.answer)) ||
    (state.reviewFilter === "skipped" && !!ans);
   if(hide) rowCls += " is-hidden";
  }

  const preview = esc(q.question.split("\n")[0]).slice(0, 95) + (q.question.length > 95 ? "…" : "");
  return `<tr class="${rowCls}" data-qidx="${idx}">
   <td><span class="${badgeCls}">${idx + 1}</span></td>
   <td>${preview}</td>
   <td><span class="status-pill-mini">${statusLabel}</span></td>
   <td><strong>${ans ? "(" + ans + ")" : "—"}</strong></td>
  </tr>`;
 }).join("");
}

/* Render Scorecard */
function renderScorecard(){
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 const st = computeStats(sess, cs);
 const accuracy = st.answered > 0 ? Math.round((st.correct / st.answered) * 100) : 0;
 const scorePct = st.total > 0 ? Math.round((st.correct / st.total) * 100) : 0;
 const markingScheme=sess.isCustom&&state.customSession?state.customSession.markingScheme:"upsc";
 const positiveMarks=markingScheme==="no-negative"?1:2;
 const negativeMarks=markingScheme==="no-negative"?0:(2/3);
 const netScore=(st.correct*positiveMarks-st.wrong*negativeMarks).toFixed(2);
 const maxUpsc=st.total*positiveMarks;
 const markingLabel=markingScheme==="no-negative"?"No Negative Marking (+1 / 0)":"UPSC Pattern (+2 / −0.66)";

 const r = 60, circ = 2 * Math.PI * r;
 const dashOffset = circ * (1 - scorePct / 100);

 const topicMap = new Map();
 sess.questions.forEach((q, idx) => {
  const key = q.subheading || q.chapter_title;
  if(!topicMap.has(key)) topicMap.set(key, { total:0, correct:0 });
  const item = topicMap.get(key);
  item.total++;
  if(cs.answers[idx] && cs.answers[idx] === q.answer) item.correct++;
 });

 let breakdownHTML = "";
 topicMap.forEach((val, name) => {
  const pct = val.total ? Math.round((val.correct / val.total) * 100) : 0;
  breakdownHTML += `<div class="tb-row">
   <div class="tb-top"><span>${esc(name)}</span><span>${val.correct}/${val.total} (${pct}%)</span></div>
   <div class="tb-bar"><div class="tb-fill" style="width:${pct}%"></div></div>
  </div>`;
 });

 const hasNextChapter = !sess.isCustom && state.chapterIdx < CHAPTERS.length - 1;
 $("scorecardView").innerHTML = `
  <div class="scorecard-topline">
   <strong>Test Result</strong>
   <button type="button" class="scorecard-home-close" id="scorecardHomeBtn" aria-label="Close result and return home" title="Back to Home">×</button>
  </div>
  <div class="score-hero">
   <div class="score-ring-wrap">
    <svg class="score-ring" viewBox="0 0 150 150" role="img" aria-label="Score ${scorePct} percent">
     <circle cx="75" cy="75" r="${r}" fill="none" stroke="var(--border)" stroke-width="13"/>
     <circle cx="75" cy="75" r="${r}" fill="none" stroke="var(--primary)" stroke-width="13" stroke-linecap="round"
      stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${dashOffset.toFixed(1)}" transform="rotate(-90 75 75)"/>
     <text x="75" y="72" text-anchor="middle" fill="var(--text)" font-size="28" font-weight="900">${st.correct}/${st.total}</text>
     <text x="75" y="94" text-anchor="middle" fill="var(--muted)" font-size="12" font-weight="700">${scorePct}% SCORE</text>
    </svg>
   </div>
   <div>
    <div class="score-kpi-grid">
     <div class="kpi-card k-ok"><strong>${st.correct}</strong><span>Correct</span></div>
     <div class="kpi-card k-bad"><strong>${st.wrong}</strong><span>Incorrect</span></div>
     <div class="kpi-card"><strong>${st.skipped}</strong><span>Skipped</span></div>
     <div class="kpi-card k-acc"><strong>${accuracy}%</strong><span>Accuracy</span></div>
    </div>
    <div class="upsc-mark-note">
     <span>${markingLabel}: <b>${netScore} / ${maxUpsc}</b></span>
     <span>Time Spent: <b>${fmtTime(cs.elapsedSec || 0)}</b></span>
    </div>
   </div>
  </div>

  <div class="topic-breakdown">
   <h3>Topic-Wise Analysis</h3>
   ${breakdownHTML}
  </div>

  <div class="score-actions">
   <button type="button" class="act-btn next-btn" id="reviewSolutionsBtn">Review Solutions</button>
   <button type="button" class="act-btn" id="reattemptBtn">↺ Reattempt</button>
   ${hasNextChapter ? '<button type="button" class="act-btn submit-btn" id="goNextChapterBtn">Next Chapter →</button>' : ''}
  </div>
 `;

 $("scorecardHomeBtn").onclick = () => goHomeDashboard();
 $("reviewSolutionsBtn").onclick = () => {
  cs.viewingScorecard = false;
  state.reviewFilter = "all";
  saveState();
  renderChapterView();
 };
 $("reattemptBtn").onclick = () => resetCurrentSession();
 if(hasNextChapter){
  $("goNextChapterBtn").onclick = () => {
   state.chapterIdx += 1;
   $("chapterSelect").value = String(state.chapterIdx);
   saveState();
   renderChapterView();
   window.scrollTo({top:0,behavior:"smooth"});
  };
 }
}

function renderExitedTestHomeState(){
 const panel=$("homeExitedTestPanel"),content=$("homeDashboardContent");
 const exitedKey=state.exitedTestKey;
 const activeBank=SUBJECT_BANKS[state.subjectIdx]||SUBJECT_BANKS[0];
 const activeChapter=CHAPTERS[state.chapterIdx];
 const activeKey=state.customSession?"custom_session":(activeBank&&activeChapter?subjectChapterStorageKey(activeBank,activeChapter):null);
 const show=!!exitedKey && exitedKey===activeKey;
 if(panel) panel.hidden=!show;
 if(content) content.hidden=show;
 if(show){
  const sess=getActiveSession();

 }
 return show;
}
function updateHomeChapterLabel(){
 const ch = CHAPTERS[state.chapterIdx];
 const target = $("homeSelectedChapter");
 if(target) target.textContent = ch ? `Selected: Chapter ${ch.chapter_no} — ${ch.title}` : "Choose a chapter or build a personalized question set.";
 const startBtn=$("homeStartChapterBtn"),session=ch&&state.chapters[ch.id];
 if(startBtn){
  const canResume=!!(session&&session.testStarted&&!session.submitted);
  startBtn.textContent=canResume?"Continue Selected Chapter":"Start Selected Chapter";
  startBtn.setAttribute("aria-label",canResume?"Continue the saved test for the selected chapter":"Start selected chapter");
 }
}
function goHomeDashboard(){
 document.body.classList.remove("qb-manager-open");
 stopTimer();
 timerPaused = false;
 solutionPanelOpen = false;
 clearSolutionHideTimer();
 state.customSession = null;
 isHomeDashboard = true;
 closeSubmitModal();
 closePopovers();
 setDisplayMode("normal");
 const managerPage=$("questionBankManagerPage");
 if(managerPage) managerPage.hidden=true;
 const home = $("homeDashboard");
 const workspace = $("mockWorkspace");
 const score = $("scorecardView");
 if(home) home.hidden = false;
 if(workspace) workspace.style.display = "none";
 if(score){ score.style.display = "none"; score.classList.remove("active"); }
 document.body.classList.remove("submitted-scorecard-only");
 document.documentElement.classList.remove("scorecard-scroll-unlocked","primary-lock");
 document.body.classList.remove("scorecard-scroll-unlocked");
 updateHomeChapterLabel();
 renderExitedTestHomeState();
 renderHomeRecentResults();
 saveState();
 window.scrollTo({top:0,behavior:"smooth"});
}
function enterSelectedSession(mode){
 isHomeDashboard = false;
 const sess = getActiveSession();
 if(state.exitedTestKey===sess.key) state.exitedTestKey=null;
 let cs = getSessionState(sess);
 if(cs.submitted){
  state.chapters[sess.key] = createSessionState(sess.questions.length);
  cs = getSessionState(sess);
 }
 const resumingInProgressTest = !!cs.testStarted && !cs.submitted && !!cs.pausedByAppHide;
 cs.viewingScorecard = false;
 cs.pausedByAppHide = false;
 if(mode === "test"){
  if(!cs.testStarted || cs.submitted) cs.chapterTimeLeft = getChapterTotalSec(sess);
  cs.testStarted = true;
 }
 timerPaused = false;
 if(getActiveTimerMode(sess) === "per30" && typeof cs.qTimeLeft[cs.currentIdx] !== "number"){
  cs.qTimeLeft[cs.currentIdx] = getPerQuestionSec();
 }
 const home = $("homeDashboard");
 if(home) home.hidden = true;
 $("mockWorkspace").style.display = "";
 $("scorecardView").style.display = "none";
 $("scorecardView").classList.remove("active");
 requestAppFullscreen();
 setDisplayMode(mode);
 saveState();
 renderChapterView();
 if(mode === "test") startTimer(0);
 syncTimerUI(performance.now());
}
function renderChapterView(){
 if(isHomeDashboard){
  stopTimer();
  $("homeDashboard").hidden = false;
  $("mockWorkspace").style.display = "none";
  $("scorecardView").style.display = "none";
  $("scorecardView").classList.remove("active");
  document.body.classList.remove("submitted-scorecard-only");
  document.documentElement.classList.remove("scorecard-scroll-unlocked","primary-lock");
  document.body.classList.remove("scorecard-scroll-unlocked");
  updateHomeChapterLabel();
  renderExitedTestHomeState();
  renderHomeRecentResults();
  return;
 }
 $("homeDashboard").hidden = true;
 const sess = getActiveSession();
 const cs = getSessionState(sess);

 if(sess.isCustom){
  if((document.getElementById("chapterTitle") || {textContent:""})) (document.getElementById("chapterTitle") || {textContent:""}).textContent = sess.title;
  $("exitCustomBtn").style.display = "none";
 } else {
  if((document.getElementById("chapterTitle") || {textContent:""})) (document.getElementById("chapterTitle") || {textContent:""}).textContent = `Chapter ${sess.chapter_no}: ${sess.title}`;
  $("chapterSelect").value = String(state.chapterIdx);
  refreshAppSelect("chapterSelect");
  $("exitCustomBtn").style.display = "none";
 }

 const isScView = !!(cs.submitted && cs.viewingScorecard);
 document.documentElement.classList.toggle("scorecard-scroll-unlocked", isScView);
 document.body.classList.toggle("scorecard-scroll-unlocked", isScView);
 document.documentElement.classList.toggle("primary-lock", primary && !isScView);
 if(isScView){
  document.body.classList.add("submitted-scorecard-only");
  $("mockWorkspace").style.display = "none";
  $("scorecardView").style.display = "block";
  $("scorecardView").classList.add("active");
  renderScorecard();
  stopTimer();
  syncTimerUI();
 } else {
  document.body.classList.remove("submitted-scorecard-only");
  $("mockWorkspace").style.display = "";
  $("scorecardView").classList.remove("active");
  $("scorecardView").style.display = "";
  renderQuestion("");
  startTimer();
 }
}

function goToQuestion(newIdx, dir){
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 if(newIdx < 0 || newIdx >= sess.questions.length) return;
 solutionPanelOpen = false; clearSolutionHideTimer();
 cs.currentIdx = newIdx;
 cs.visited[newIdx] = true;
 if(getActiveTimerMode(sess) === "per30" && typeof cs.qTimeLeft[newIdx] !== "number"){
  cs.qTimeLeft[newIdx] = getPerQuestionSec();
 }
 saveState();
 renderQuestion(dir || "");
 syncTimerUI();
}

function openSubmitModal(){
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 if(cs.submitted){
  cs.viewingScorecard = true;
  saveState();
  renderChapterView();
  return;
 }
 const st = computeStats(sess, cs);
 $("mAns").textContent = st.answered;
 $("mMark").textContent = st.marked;
 $("mUnans").textContent = st.skipped;
 $("submitModal").classList.add("open");
}

function closeSubmitModal(){ $("submitModal").classList.remove("open"); }

function finalizeSubmit(){
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 // A rapid double tap or timer/UI race must never create duplicate history records.
 if(cs.submitted || cs._submitting) return;
 cs._submitting = true;
 closeSubmitModal();
 {
  const statsForHistory = computeStats(sess, cs);
  const history = loadResultHistory();
  history.unshift(makeAttemptRecord(sess, cs, statsForHistory));
  const historySaved=saveResultHistory(history);
  if(!historySaved)appSetBackupStatus("The test was submitted, but its result was not saved to history. Free browser storage and export a backup before continuing.","error");
  renderHomeRecentResults();
  renderHomeBookmarkedPreview();
 }
 cs.submitted = true;
 cs._submitting = false;
 cs.viewingScorecard = true;
 stopTimer();
 // A confirmed final submission exits Test Mode and displays the result dashboard.
 if(displayMode === "test") setDisplayMode("normal");
 saveState();
 renderChapterView();
 if($("scorecardView")) $("scorecardView").scrollTop = 0;
 if(!primary) window.scrollTo({top:0,behavior:"smooth"});
}

function resetCurrentSession(){
 const sess = getActiveSession();
 const csNow = getSessionState(sess);
 const hasProgress = Object.keys(csNow.answers || {}).length > 0 || Object.keys(csNow.marked || {}).length > 0 || !!csNow.testStarted;
 if(hasProgress){
  pendingResetAction = () => {
   state.chapters[sess.key] = createSessionState(sess.questions.length);
   state.reviewFilter = "all";
   timerPaused = false;
   goHomeDashboard();
  };
  $("resetConfirmModal").classList.add("open");
  return;
 }
 state.chapters[sess.key] = createSessionState(sess.questions.length);
 state.reviewFilter = "all";
 timerPaused = false;
 goHomeDashboard();
}

/* Bookmark Toggle & Modal */


document.addEventListener("click",e=>{
 if(!e.target.closest(".more-menu-wrap")){
  const panel=$("moreMenuPanel");
  if(panel)panel.hidden=true;
  const trigger=$("moreMenuBtn");
  if(trigger)trigger.setAttribute("aria-expanded","false");
  closePopovers();
 }
});

$("resultHistoryBtn").addEventListener("click", () => {
 closePopovers();
 openResultHistory();
});
$("closeResultHistoryBtn").addEventListener("click", closeResultHistory);
$("resultHistoryModal").addEventListener("click", e => {
 if(e.target === $("resultHistoryModal")){closeResultHistory();return;}
 const retake=e.target.closest("[data-review-reattempt]");
 if(retake){
  const nextMode=!reviewReattemptMode;
  setReviewReattemptMode(nextMode);
  const item=loadResultHistory().find(x=>x.id===activeHistoryAttemptId);
  if(item)renderSavedAttemptReview(item);
  return;
 }
 const retakeAnswer=e.target.closest("[data-saved-retake-answer]");
 if(retakeAnswer && reviewReattemptMode){
  const item=loadResultHistory().find(x=>x.id===activeHistoryAttemptId);
  if(item){
   const questions=Array.isArray(item.details)?item.details:[];
   const filtered=questions.map((d,idx)=>({d,idx})).filter(({d})=>{
    if(activeHistoryFilter==="attempted")return !!d.selected;
    if(activeHistoryFilter==="unattempted")return !d.selected&&d.visited===false;
    if(activeHistoryFilter==="skipped")return !d.selected&&d.visited===true;
    if(activeHistoryFilter==="unclassified")return !d.selected&&typeof d.visited!=="boolean";
    if(activeHistoryFilter==="correct")return d.status==="correct";
    if(activeHistoryFilter==="wrong")return d.status==="wrong";
    if(activeHistoryFilter==="bookmarked")return !!d.bookmarked||(!Object.prototype.hasOwnProperty.call(d,"bookmarked")&&!!state.bookmarks[d.questionId]);
    if(activeHistoryFilter==="marked")return !!d.marked;
    return true;
   });
   const d=filtered[activeHistoryReviewPosition]?.d;
   const idx=filtered[activeHistoryReviewPosition]?.idx;
   if(d){
    const key=String(item.id)+"::"+String(d.questionId||idx);
    savedReviewRetakeAnswers[key]=retakeAnswer.dataset.savedRetakeAnswer;
    saveReviewAnswerMap(REVIEW_RETAKE_ANSWERS_KEY,savedReviewRetakeAnswers);
    renderSavedAttemptReview(item);
   }
  }
  return;
 }
 const expand=e.target.closest("[data-review-expand='saved']");
 if(expand){
  const card=expand.closest(".history-review-single-question");
  if(card){
   const expanded=card.classList.toggle("review-panel-expanded");
   savedReviewExpanded=expanded;
   expand.setAttribute("aria-label",expanded?"Collapse question panel":"Expand question panel");
   expand.title=expanded?"Collapse":"Expand";
   expand.innerHTML=expanded
    ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3v5H3M16 3v5h5M3 16h5v5M21 16h-5v5"/></svg>'
    : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/></svg>';
  }
 }
});
$("resultHistoryList").addEventListener("click", e => {
 const btn = e.target.closest("[data-history-action]");
 if(!btn) return;
 const idx = Number(btn.dataset.historyIndex);
 const items = loadResultHistory();
 if(!Number.isInteger(idx) || !items[idx]) return;
 if(btn.dataset.historyAction === "review"){
  openSavedAttemptReview(idx);
 } else if(btn.dataset.historyAction === "reattempt"){
  const item=items[idx];
  const ids=Array.isArray(item.customQuestionIds)?item.customQuestionIds:[];
  if(!ids.length||ids.some(id=>!Q_MAP.has(id))){
   appShowStorageWarning("This saved Personalized Test cannot be rebuilt because one or more original questions are no longer in the Question Bank.");
   return;
  }
  state.customSession={
   title:item.chapterTitle||"Personalized Test",
   questionIds:ids.slice(),
   durationMinutes:Math.max(1,Math.min(1440,Number(item.customDurationMinutes)||25)),
   timerMode:"chapter25",
   markingScheme:item.markingScheme==="no-negative"?"no-negative":"upsc"
  };
  const fresh=createSessionState(ids.length);
  fresh.testStarted=true;
  fresh.chapterTimeLeft=getChapterTotalSec({isCustom:true});
  state.chapters.custom_session=fresh;
  state.exitedTestKey=null;
  state.reviewFilter="all";
  timerPaused=false;
  isHomeDashboard=false;
  $("homeDashboard").hidden=true;
  $("exitCustomBtn").style.display="none";
  saveState();
  requestAppFullscreen();
  setDisplayMode("test");
  renderChapterView();
  startTimer(0);
 } else if(btn.dataset.historyAction === "delete"){
  const target=items[idx];
  if(!window.confirm(`Delete the saved result "${target.chapterTitle||"Test"}"? This cannot be undone.`))return;
  items.splice(idx,1);
  saveResultHistory(items);
  const prefix=String(target.id)+"::";
  Object.keys(savedReviewRetakeAnswers||{}).forEach(key=>{if(key.startsWith(prefix))delete savedReviewRetakeAnswers[key];});
  saveReviewAnswerMap(REVIEW_RETAKE_ANSWERS_KEY,savedReviewRetakeAnswers);
  renderResultHistory();
 }
});
$("historyReviewBackBtn").addEventListener("click", backToResultHistory);
$("historyReviewFilters").addEventListener("click", e => {
 const chip = e.target.closest("[data-history-filter]");
 if(!chip) return;
 activeHistoryFilter = chip.dataset.historyFilter || "all";
 activeHistoryReviewPosition=0;
 const current = loadResultHistory().find(x => x.id === activeHistoryAttemptId);
 if(current) renderSavedAttemptReview(current);
});
$("historyReviewQuestions").addEventListener("click",e=>{
 const nav=e.target.closest("[data-history-review-nav]");
 const current=loadResultHistory().find(x=>x.id===activeHistoryAttemptId);
 if(nav&&current){
  const questions=Array.isArray(current.details)?current.details:[];
  const filtered=questions.map((d,idx)=>({d,idx})).filter(({d})=>{
   if(activeHistoryFilter==="correct")return d.status==="correct";
   if(activeHistoryFilter==="wrong")return d.status==="wrong";
   if(activeHistoryFilter==="skipped")return d.status==="skipped"||!d.selected;
   if(activeHistoryFilter==="bookmarked")return !!d.bookmarked||(!Object.prototype.hasOwnProperty.call(d,"bookmarked")&&!!state.bookmarks[d.questionId]);
   if(activeHistoryFilter==="marked")return !!d.marked;
   return true;
  });
  activeHistoryReviewPosition=Math.max(0,Math.min(filtered.length-1,activeHistoryReviewPosition+(nav.dataset.historyReviewNav==="next"?1:-1)));
  renderSavedAttemptReview(current);
  const scroller=$("historyReviewQuestions").querySelector(".saved-review-scroll");
  if(scroller)scroller.scrollTop=0;
  return;
 }
 const toggle=e.target.closest("[data-history-bookmark]");
 if(toggle){const id=toggle.dataset.historyBookmark;if(state.bookmarks[id])delete state.bookmarks[id];else state.bookmarks[id]=true;homeStudySnapshotCache.at=0;saveState();syncBookmarkBadge();if(current)renderSavedAttemptReview(current);renderHomeBookmarkedPreview();}
});
$("cancelResetBtn").addEventListener("click", () => {
 $("resetConfirmModal").classList.remove("open");
 pendingResetAction = null;
});
$("confirmResetBtn").addEventListener("click", () => {
 $("resetConfirmModal").classList.remove("open");
 const action = pendingResetAction;
 pendingResetAction = null;
 if(action) action();
});

$("topBookmarkBtn").addEventListener("click", () => {
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 const q = sess.questions[cs.currentIdx];
 if(state.bookmarks[q.id]){
  delete state.bookmarks[q.id];
 } else {
  state.bookmarks[q.id] = true;
 }
 syncBookmarkBadge();
 updatePersonalizedMatchCount();
 saveState();
 renderHomeBookmarkedPreview();
 renderQuestion("");
});

function renderBookmarkModal(){
 const ids = Object.keys(state.bookmarks).filter(k => state.bookmarks[k] && Q_MAP.has(k));
 $("bmkModalCount").textContent = String(ids.length);
 const box = $("bmkListContainer");
 if(ids.length === 0){
  box.innerHTML = '<div class="bookmark-empty-state">No Bookmarked Questions</div>';
  return;
 }
 box.innerHTML = ids.map(qid => {
  const item = Q_MAP.get(qid);
  return `<div class="bmk-item">
   <div class="bmk-item-main" data-jump-qid="${esc(qid)}">
    <div class="bmk-item-meta">${SUBJECT_BANKS.length>1?`${esc(item.subject_name)} · `:""}Chapter ${item.chapter_no}: ${esc(item.chapter_title)} · Q${item.qno}</div>
    <div class="bmk-item-q">${esc(item.question.split("\n")[0])}</div>
   </div>
   <button type="button" class="btn" data-remove-qid="${esc(qid)}" style="padding:5px 9px;color:var(--bad);border-color:var(--bad-border)">Remove</button>
  </div>`;
 }).join("");
}

$("bookmarkListBtn").addEventListener("click", () => {
 closePopovers();closePersModal();stopTimer();timerPaused=false;
 openBookmarkPracticePage();
});
$("closeBmkModalBtn").addEventListener("click", () => $("bookmarkModal").classList.remove("open"));
$("bookmarkModal").addEventListener("click", e => {
 if(e.target === $("bookmarkModal")) $("bookmarkModal").classList.remove("open");
  closePersModal();
});

$("bmkListContainer").addEventListener("click", e => {
 const remBtn = e.target.closest("[data-remove-qid]");
 if(remBtn){
  delete state.bookmarks[remBtn.dataset.removeQid];
  syncBookmarkBadge();
  updatePersonalizedMatchCount();
  saveState();
  renderBookmarkModal();
  renderQuestion("");
  return;
 }
 const jumpEl = e.target.closest("[data-jump-qid]");
 if(jumpEl){
  const item = Q_MAP.get(jumpEl.dataset.jumpQid);
  if(!item) return;
  $("bookmarkModal").classList.remove("open");
  closePersModal();
  state.customSession = null;
  state.chapterIdx = item.chapter_idx;
  const cs = getSessionState();
  cs.currentIdx = item.orig_idx;
  cs.visited[item.orig_idx] = true;
  cs.viewingScorecard = false;
  saveState();
  renderChapterView();
 }
});

/* Home bookmarked questions preview and full-page practice */
function getBookmarkedQuestionItems(){
 return Object.keys(state.bookmarks).filter(id=>state.bookmarks[id] && Q_MAP.has(id))
  .map(id=>Q_MAP.get(id)).reverse();
}
function renderHomeBookmarkedPreview(){
 const host=$("homeRecentBookmarksList"); if(!host)return;
 const count=getBookmarkedQuestionItems().length;
 host.innerHTML=count
  ? `<article class="home-recent-item"><div class="home-recent-item-main"><strong class="home-recent-item-title">${count} bookmarked question${count===1?"":"s"}</strong></div><div class="home-recent-score"><button type="button" class="home-recent-open" id="homeBookmarkPracticeOpenBtn">Practice</button></div></article>`
  : '<div class="home-recent-empty">No bookmarked questions yet.</div>';
}
let bookmarkPracticeQueue=[];
let bookmarkPracticeIndex=0;
let bookmarkReviewExpanded=false;
let savedReviewExpanded=false;
const REVIEW_REATTEMPT_STORAGE_KEY="mockStudio.reviewReattemptMode.v1";
function loadReviewReattemptMode(){
 try{
  const value=localStorage.getItem(REVIEW_REATTEMPT_STORAGE_KEY);
  return value===null ? true : value==="true";
 }catch(_){return true;}
}
function setReviewReattemptMode(value){
 const nextMode=!!value;
 const wasMode=reviewReattemptMode;
 reviewReattemptMode=nextMode;
 /* Switching Reattempt ON starts a genuinely fresh attempt in Bookmark Practice.
    Keep the original review answers untouched; clear only previous reattempt picks. */
 if(nextMode && !wasMode){
  bookmarkPracticeRetakeAnswers={};
  saveReviewAnswerMap(REVIEW_BOOKMARK_RETAKE_ANSWERS_KEY,bookmarkPracticeRetakeAnswers);
 }
 try{localStorage.setItem(REVIEW_REATTEMPT_STORAGE_KEY,reviewReattemptMode?"true":"false");}
 catch(_){if(typeof appShowStorageWarning==="function")appShowStorageWarning("The Reattempt Mode preference could not be saved. Check browser storage and download a Full Backup.");}
}
let reviewReattemptMode=loadReviewReattemptMode();
const REVIEW_BOOKMARK_ANSWERS_KEY="mockStudio.bookmarkReviewAnswers.v1";
const REVIEW_RETAKE_ANSWERS_KEY="mockStudio.savedReviewRetakeAnswers.v1";
function loadReviewAnswerMap(key){try{const v=JSON.parse(localStorage.getItem(key)||"{}");return v&&typeof v==="object"&&!Array.isArray(v)?v:{}}catch(_){return {}}}
function saveReviewAnswerMap(key,map){
 try{localStorage.setItem(key,JSON.stringify(map||{}));return true;}
 catch(_){
  if(typeof appShowStorageWarning==="function")appShowStorageWarning("A review answer could not be saved in browser storage. Download a Full Backup and free browser storage before continuing.");
  return false;
 }
}
function migrateQuestionAnswerMap(map){
 const out={};
 Object.entries(map||{}).forEach(([key,value])=>{out[migrateSubjectScopedId(key)]=value;});
 return out;
}
function migrateSavedReviewAnswerMap(map){
 const out={};
 Object.entries(map||{}).forEach(([key,value])=>{
  const sep=key.indexOf("::");
  if(sep<0){out[key]=value;return;}
  out[key.slice(0,sep)+"::"+migrateSubjectScopedId(key.slice(sep+2))]=value;
 });
 return out;
}
let savedReviewRetakeAnswers=migrateSavedReviewAnswerMap(loadReviewAnswerMap(REVIEW_RETAKE_ANSWERS_KEY));
let bookmarkPracticeAnswers=migrateQuestionAnswerMap(loadReviewAnswerMap(REVIEW_BOOKMARK_ANSWERS_KEY));
const REVIEW_BOOKMARK_RETAKE_ANSWERS_KEY="mockStudio.bookmarkReviewRetakeAnswers.v1";
let bookmarkPracticeRetakeAnswers=migrateQuestionAnswerMap(loadReviewAnswerMap(REVIEW_BOOKMARK_RETAKE_ANSWERS_KEY));
function renderBookmarkPracticePage(){
 const host=$("bookmarkPracticeList");
 const items=bookmarkPracticeQueue;
 $("bookmarkPracticeCount").textContent=String(getBookmarkedQuestionItems().length);
 if(!items.length){host.innerHTML='<div class="bookmark-practice-empty">No bookmarked questions.</div>';return;}
 bookmarkPracticeIndex=Math.max(0,Math.min(bookmarkPracticeIndex,items.length-1));
 const q=items[bookmarkPracticeIndex];
 const selected=reviewReattemptMode
  ? (bookmarkPracticeRetakeAnswers[q.id] || "")
  : (bookmarkPracticeAnswers[q.id] || "");
 const isBookmarked=!!state.bookmarks[q.id];
 const letters=Object.keys(q.options||{}).filter(k=>String(q.options[k]||"").trim());
 const hasAnswer=Array.isArray(q.answer)?q.answer.length>0:!!q.answer;
 const correctKeys=Array.isArray(q.answer)?q.answer.map(String):[String(q.answer||"")];
 const revealBookmarkAnswer=!!selected;
 const options=letters.map(letter=>{
  const correct=correctKeys.includes(letter),chosen=selected===letter;
  const cls="bookmark-practice-option opt-card"+
   (revealBookmarkAnswer&&hasAnswer&&correct?" correct":"")+
   (revealBookmarkAnswer&&chosen&&hasAnswer&&!correct?" wrong":"")+
   (chosen?" selected":"");
  const answerTag=revealBookmarkAnswer&&hasAnswer&&correct?'<span class="opt-tag">Correct Answer</span>':"";
  return `<button type="button" class="${cls}" data-practice-answer="${esc(letter)}" ${!reviewReattemptMode?"disabled":""}><span class="opt-letter">${esc(letter)}</span><span class="opt-text">${formatInline(q.options[letter])}</span>${answerTag}</button>`;
 }).join("");
 let feedback="";
 if(selected){
  const right=correctKeys.includes(selected);
  feedback=hasAnswer
   ? `<strong>${right?"Correct Answer":"Incorrect Answer"} · Correct option: ${correctKeys.map(k=>`(${esc(k)}) ${formatInline(q.options[k]||"")}`).join(", ")}</strong>`
   : '<strong>Answer key is not available for this question.</strong>';
  feedback+=renderVerificationNoteHTML(q.verification_note);
  feedback+=`<div class="sol-exp-title">Explanation</div><div class="sol-exp-text">${renderExplanationHTML(q.explanation||"Explanation unavailable.")}</div>`;
 }
 host.innerHTML=`<article class="bookmark-practice-card ${bookmarkReviewExpanded?"review-panel-expanded":""}" data-bookmark-card="${esc(q.id)}">
  <div class="bookmark-practice-card-head">
   <div class="bookmark-practice-meta"><span>${esc(q.subject_name||"")}${q.subject_name?" · ":""}Chapter ${esc(q.chapter_no||"")}: ${esc(q.chapter_title||"")}</span>${q.subheading?`<span class="bookmark-topic-chip">${esc(q.subheading)}</span>`:""}</div>
   <button type="button" class="review-reattempt-toggle ${reviewReattemptMode?"is-on":""}" data-review-reattempt aria-label="Reattempt mode ${reviewReattemptMode?"on":"off"}" aria-pressed="${reviewReattemptMode}" title="Reattempt ${reviewReattemptMode?"On":"Off"}">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.4-3"/></svg>
   </button>
   <button type="button" class="bookmark-card-toggle ${isBookmarked?"is-bookmarked":""}" data-bookmark-toggle="${esc(q.id)}" aria-label="${isBookmarked?"Remove bookmark":"Add bookmark"}" aria-pressed="${isBookmarked}" title="${isBookmarked?"Remove bookmark":"Add bookmark"}">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
   </button>
   <button type="button" class="review-expand-btn" data-review-expand="bookmark" aria-label="${bookmarkReviewExpanded?"Collapse question panel":"Expand question panel"}" title="${bookmarkReviewExpanded?"Collapse":"Expand"}">
    ${bookmarkReviewExpanded
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3v5H3M16 3v5h5M3 16h5v5M21 16h-5v5"/></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/></svg>'}
   </button>
  </div>
  <div class="bookmark-practice-scroll" tabindex="0" aria-label="Scrollable question, options, answer and explanation. Scroll down to view the answer and explanation.">
   <div class="bookmark-practice-question q-stem">${renderStemHTML(q.question||"")}</div>
   <div class="bookmark-practice-options options-list">${options}</div>
   <div class="bookmark-practice-feedback solution-box" ${selected?"":"hidden"}>${feedback}</div>
  </div>
  <div class="bookmark-practice-actions bookmark-practice-controls action-bar review-action-bar">
   <button type="button" class="act-btn" data-bookmark-nav="prev" aria-label="Previous question" ${bookmarkPracticeIndex===0?"disabled":""}>← Previous</button>
   <span class="review-progress" aria-live="polite">Question ${bookmarkPracticeIndex+1} of ${items.length}</span>
   <button type="button" class="act-btn next-btn" data-bookmark-nav="next" aria-label="Next question" ${bookmarkPracticeIndex===items.length-1?"disabled":""}>Next →</button>
  </div>
 </article>`;
}
function openBookmarkPracticePage(){
 bookmarkReviewExpanded=false;
 document.body.classList.add("page-workspace-open");
 bookmarkPracticeQueue=getBookmarkedQuestionItems().slice();
 bookmarkPracticeIndex=0;
 $("homeDashboard").hidden=true;
 $("questionBankManagerPage").hidden=true;
 $("bookmarkPracticePage").hidden=false;
 renderBookmarkPracticePage();
 window.scrollTo({top:0,behavior:"smooth"});
}
$("homeViewAllBookmarksBtn").addEventListener("click",openBookmarkPracticePage);
function closeBookmarkPracticePage(){
 bookmarkReviewExpanded=false;
 document.body.classList.remove("page-workspace-open");
 $("bookmarkPracticePage").hidden=true;$("homeDashboard").hidden=false;
 renderHomeBookmarkedPreview();window.scrollTo({top:0,behavior:"smooth"});
}
$("bookmarkPracticeBackBtn")?.addEventListener("click",closeBookmarkPracticePage);
$("bookmarkPracticeCloseBtn")?.addEventListener("click",closeBookmarkPracticePage);
document.addEventListener("keydown",e=>{
 if(e.key==="Escape"){
  const expanded=document.querySelector(".review-panel-expanded");
  if(expanded){
   if(expanded.matches(".bookmark-practice-card")) bookmarkReviewExpanded=false;
   if(expanded.matches(".history-review-single-question")) savedReviewExpanded=false;
   expanded.classList.remove("review-panel-expanded");
   const btn=expanded.querySelector("[data-review-expand]");
   if(btn){
    btn.setAttribute("aria-label","Expand question panel");btn.title="Expand";
    btn.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16h-5v-5"/></svg>';
   }
   return;
  }
  if($("bookmarkPracticePage") && !$("bookmarkPracticePage").hidden) closeBookmarkPracticePage();
 }
});
$("bookmarkPracticeList").addEventListener("click",e=>{
 const retake=e.target.closest("[data-review-reattempt]");
 if(retake){
  const nextMode=!reviewReattemptMode;
  setReviewReattemptMode(nextMode);
  renderBookmarkPracticePage();
  return;
 }
 const expand=e.target.closest("[data-review-expand]");
 if(expand){
  const card=expand.closest(".bookmark-practice-card");
  if(card){
   const expanded=card.classList.toggle("review-panel-expanded");
   bookmarkReviewExpanded=expanded;
   expand.setAttribute("aria-label",expanded?"Collapse question panel":"Expand question panel");
   expand.title=expanded?"Collapse":"Expand";
   expand.innerHTML=expanded
    ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3v5H3M16 3v5h5M3 16h5v5M21 16h-5v5"/></svg>'
    : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5"/></svg>';
  }
  return;
 }
 const choice=e.target.closest("[data-practice-answer]");
 if(choice){
  const q=bookmarkPracticeQueue[bookmarkPracticeIndex];if(!q)return;
  if(reviewReattemptMode){
   bookmarkPracticeRetakeAnswers[q.id]=choice.dataset.practiceAnswer;
   saveReviewAnswerMap(REVIEW_BOOKMARK_RETAKE_ANSWERS_KEY,bookmarkPracticeRetakeAnswers);
  }else{
   if(bookmarkPracticeAnswers[q.id])return;
   bookmarkPracticeAnswers[q.id]=choice.dataset.practiceAnswer;
   saveReviewAnswerMap(REVIEW_BOOKMARK_ANSWERS_KEY,bookmarkPracticeAnswers);
  }
  renderBookmarkPracticePage();return;
 }
 const nav=e.target.closest("[data-bookmark-nav]");
 if(nav){
  bookmarkPracticeIndex=Math.max(0,Math.min(bookmarkPracticeQueue.length-1,bookmarkPracticeIndex+(nav.dataset.bookmarkNav==="next"?1:-1)));
  renderBookmarkPracticePage();
  const scroller=$("bookmarkPracticeList").querySelector(".bookmark-practice-scroll");
  if(scroller)scroller.scrollTop=0;
  return;
 }
 const toggle=e.target.closest("[data-bookmark-toggle]");
 if(toggle){
  const id=toggle.dataset.bookmarkToggle;
  const wasBookmarked=!!state.bookmarks[id];
  if(wasBookmarked){
   delete state.bookmarks[id];
   // Removing a bookmark also clears its bookmark-only practice attempts,
   // so re-adding it later starts as a genuinely fresh bookmark exercise.
   delete bookmarkPracticeAnswers[id];
   delete bookmarkPracticeRetakeAnswers[id];
   saveReviewAnswerMap(REVIEW_BOOKMARK_ANSWERS_KEY,bookmarkPracticeAnswers);
   saveReviewAnswerMap(REVIEW_BOOKMARK_RETAKE_ANSWERS_KEY,bookmarkPracticeRetakeAnswers);
  }else state.bookmarks[id]=true;
  const previousIndex=bookmarkPracticeIndex;
  bookmarkPracticeQueue=getBookmarkedQuestionItems().slice();
  if(wasBookmarked&&previousIndex>=bookmarkPracticeQueue.length)bookmarkPracticeIndex=Math.max(0,bookmarkPracticeQueue.length-1);
  saveState();syncBookmarkBadge();renderBookmarkPracticePage();renderHomeBookmarkedPreview();updatePersonalizedMatchCount();
 }
});
$("homeRecentBookmarksList").addEventListener("click",e=>{
 if(e.target.closest("#homeBookmarkPracticeOpenBtn"))openBookmarkPracticePage();
});

/* Personalized Questions Builder Logic */
function getPersonalizedPool(){
 const selectedChapters=Array.from(document.querySelectorAll(".pers-ch-cb:checked"));
 const filterType=$("persFilterSelect").value;
 const pool=[];
 // Read saved history once per pool calculation, not once per selected chapter.
 // This avoids repeated localStorage parsing when many chapters are selected.
 const historyForFilters=loadResultHistory();
 selectedChapters.forEach(cb=>{
  const bankIdx=parseInt(cb.dataset.bankIdx,10);
  const chIdx=parseInt(cb.dataset.chapterIdx,10);
  const bank=SUBJECT_BANKS[bankIdx];
  const ch=bank && bank.chapters[chIdx];
  if(!ch || !Array.isArray(ch.questions)) return;
  const storageKey=subjectChapterStorageKey(bank,ch);
  const chSaved=state.chapters[storageKey] || {answers:{},marked:{}};
  ch.questions.forEach((q,qIdx)=>{
   const qid=effectiveQuestionId(bank,q);
   let ans=chSaved.answers&&chSaved.answers[qIdx]||"";
   let marked=!!(chSaved.marked&&chSaved.marked[qIdx]),attempted=!!ans;
   const customIdx=state.customSession&&Array.isArray(state.customSession.questionIds)?state.customSession.questionIds.indexOf(qid):-1;
   const customState=state.chapters.custom_session;
   if(customIdx>=0&&customState){
    const customAnswer=customState.answers&&customState.answers[customIdx];
    if(customAnswer){ans=customAnswer;attempted=true;}
    if(customState.marked&&customState.marked[customIdx])marked=true;
   }
   for(const attempt of historyForFilters){
    const detail=(attempt.details||[]).find(d=>String(d.questionId)===String(qid));
    if(detail){
     if(detail.marked)marked=true;
     if(!attempted&&detail.selected){ans=detail.selected;attempted=true;break;}
    }
   }
   if(filterType==="bookmarked"&&!state.bookmarks[qid])return;
   if(filterType==="marked"&&!marked)return;
   if(filterType==="unattempted"&&attempted)return;
   if(filterType==="wrong"&&(!attempted||ans===q.answer))return;
   pool.push(qid);
  });
 });
 return pool;
}
function updatePersonalizedMatchCount(){
 const pool=getPersonalizedPool();
 $("persMatchInfo").textContent=`Matching pool: ${pool.length} questions`;
 $("persCountInput").max=String(Math.max(1,pool.length));
 const names=Array.from(document.querySelectorAll(".pers-subject-cb:checked"))
  .map(cb=>SUBJECT_BANKS[parseInt(cb.value,10)]?.name).filter(Boolean);
 $("persSubjectInfo").textContent=names.length
  ? `Selected: ${names.join(" + ")} · Choose chapters from the selected subjects below.`
  : "Select at least one subject to load its chapters.";
}
$("persSubjectsList").addEventListener("change",()=>{
 renderPersonalizedChapterChoices();
 updatePersonalizedMatchCount();
});
$("persTopicsList").addEventListener("change",updatePersonalizedMatchCount);
$("persFilterSelect").addEventListener("change",updatePersonalizedMatchCount);
$("persSelectAllBtn").addEventListener("click",()=>{
 document.querySelectorAll(".pers-ch-cb").forEach(cb=>cb.checked=true);
 updatePersonalizedMatchCount();
});
$("persClearAllBtn").addEventListener("click",()=>{
 document.querySelectorAll(".pers-ch-cb").forEach(cb=>cb.checked=false);
 updatePersonalizedMatchCount();
});

function openPersModal(){
 closePopovers();
 updatePersonalizedMatchCount();
 $("persFloatingModal").classList.add("open");
}
function closePersModal(){
 $("persFloatingModal").classList.remove("open");
}

$("homeStartChapterBtn").addEventListener("click", () => enterSelectedSession("test"));
$("homeContinueExitedTestBtn").addEventListener("click",()=>{
 const sess=getActiveSession();
 if(state.exitedTestKey!==sess.key) return;
 state.exitedTestKey=null;
 const cs=getSessionState(sess);
 cs.pausedByAppHide=false;
 timerPaused=false;
 saveState();
 enterSelectedSession("test");
});
/* Restart only after two deliberate taps within 500 ms. */
(()=>{
 const restartBtn=$("homeRestartExitedTestBtn");
 let firstTapAt=0,resetHandle=null;
 if(!restartBtn) return;
 restartBtn.addEventListener("click",()=>{
  const now=performance.now();
  if(firstTapAt && now-firstTapAt<=500){
   if(resetHandle) clearTimeout(resetHandle);
   firstTapAt=0;
   restartBtn.classList.remove("tap-armed");
   restartBtn.textContent="Restart Test";
   const sess=getActiveSession();
   if(state.exitedTestKey!==sess.key) return;
   state.chapters[sess.key]=createSessionState(sess.questions.length);
   state.exitedTestKey=null;
   timerPaused=false;
   saveState();
   enterSelectedSession("test");
   return;
  }
  firstTapAt=now;
  restartBtn.classList.add("tap-armed");
  restartBtn.textContent="Tap again to restart";
  if(resetHandle) clearTimeout(resetHandle);
  resetHandle=setTimeout(()=>{
   firstTapAt=0;
   restartBtn.classList.remove("tap-armed");
   restartBtn.textContent="Restart Test";
  },500);
 });
})();
/* Reset the current test only after a deliberate double tap within 500 ms. */
(()=>{
 const resetBtn=$("homeResetExitedTestBtn");
 let firstTapAt=0,resetHandle=null;
 if(!resetBtn) return;
 resetBtn.addEventListener("click",()=>{
  const now=performance.now();
  if(firstTapAt && now-firstTapAt<=500){
   if(resetHandle) clearTimeout(resetHandle);
   firstTapAt=0;
   resetBtn.classList.remove("tap-armed");
   resetBtn.textContent="Reset Test";
   const sess=getActiveSession();
   if(state.exitedTestKey!==sess.key) return;
   state.chapters[sess.key]=createSessionState(sess.questions.length);
   if(sess.isCustom){state.customSession=null;delete state.chapters.custom_session;}
   state.exitedTestKey=null;
   timerPaused=false;
   stopTimer();
   saveState();
   isHomeDashboard=true;
   setDisplayMode("normal");
   $("homeDashboard").hidden=false;
   $("mockWorkspace").style.display="none";
   $("scorecardView").style.display="none";
   $("scorecardView").classList.remove("active");
   document.body.classList.remove("submitted-scorecard-only");
   document.documentElement.classList.remove("scorecard-scroll-unlocked","primary-lock");
   document.body.classList.remove("scorecard-scroll-unlocked");
   updateHomeChapterLabel();
   renderExitedTestHomeState();
   saveState();
   window.scrollTo({top:0,behavior:"smooth"});
   return;
  }
  firstTapAt=now;
  resetBtn.classList.add("tap-armed");
  resetBtn.textContent="Tap again to reset";
  if(resetHandle) clearTimeout(resetHandle);
  resetHandle=setTimeout(()=>{
   firstTapAt=0;
   resetBtn.classList.remove("tap-armed");
   resetBtn.textContent="Reset Test";
  },500);
 });
})();
$("homePersonalizedBtn").addEventListener("click", openPersModal);
$("homeViewAllResultsBtn").addEventListener("click", openResultHistory);
$("homeRecentResultsList").addEventListener("click", e => {
 const btn=e.target.closest("[data-home-attempt-id]");
 if(!btn) return;
 const items=loadResultHistory();
 const idx=items.findIndex(item=>String(item.id)===btn.dataset.homeAttemptId);
 if(idx<0) return;
 openResultHistory();
 openSavedAttemptReview(idx);
});
$("persIconModalBtn").addEventListener("click", openPersModal);
$("closePersModalBtn").addEventListener("click", closePersModal);
$("cancelPersModalBtn").addEventListener("click", closePersModal);
$("persFloatingModal").addEventListener("click", e => {
 if(e.target === $("persFloatingModal")) closePersModal();
});

/* OK inside Personalized Test modal: selects & prepares the personalized set;
   then clicking Start Test starts the test */
$("okPersBtn").addEventListener("click", () => {
 let pool = getPersonalizedPool();
 if(pool.length === 0){
  $("persMatchInfo").textContent = "⚠ Please select at least 1 topic with matching questions.";
  return;
 }
 if($("persShuffleCheck").checked){
  for(let i = pool.length - 1; i > 0; i--){
   const j = Math.floor(Math.random() * (i + 1));
   [pool[i], pool[j]] = [pool[j], pool[i]];
  }
 }
 const requestedCount=Number.parseInt($("persCountInput").value,10);
 if(!Number.isFinite(requestedCount)||requestedCount<1){
  $("persMatchInfo").textContent="⚠ Enter a valid question count of at least 1.";
  $("persCountInput").focus();return;
 }
 if(requestedCount>pool.length){
  $("persMatchInfo").textContent=`⚠ You requested ${requestedCount} questions, but only ${pool.length} match the selected filters.`;
  $("persCountInput").focus();return;
 }
 const desired=requestedCount;
 const durationRaw = Number.parseInt($("persDurationMinutesInput").value, 10);
 if(!Number.isFinite(durationRaw) || durationRaw < 1 || durationRaw > 1440){
  $("persMatchInfo").textContent = "⚠ Enter a total test time between 1 and 1440 minutes.";
  $("persDurationMinutesInput").focus();
  return;
 }
 const durationMinutes = durationRaw;
 const chosenIds = pool.slice(0, desired);
 const subjectNames=[...new Set(chosenIds.map(id=>Q_MAP.get(id)?.subject_name).filter(Boolean))];
 const subjectTitle=subjectNames.length ? `${subjectNames.join(" + ")} · ` : "";

 state.customSession = {
  title: `${subjectTitle}Personalized Test (${chosenIds.length} Questions)`,
  questionIds: chosenIds,
  durationMinutes,
  timerMode: "chapter25",
  markingScheme: $("persMarkingScheme").value==="no-negative"?"no-negative":"upsc"
 };
 // Personalized Test owns its total-test countdown; global timer preference is preserved.
 const fresh = createSessionState(chosenIds.length);
 fresh.testStarted = true;
 fresh.chapterTimeLeft = getChapterTotalSec({isCustom:true});
 state.chapters["custom_session"] = fresh;
 state.reviewFilter = "all";
 timerPaused = false;
 closePersModal();
 isHomeDashboard = false;
 $("homeDashboard").hidden = true;
 $("exitCustomBtn").style.display = "none";
 saveState();
 requestAppFullscreen();
 setDisplayMode("test");
 renderChapterView();
 startTimer(0);
});

$("exitCustomBtn").addEventListener("click", () => {
 state.customSession = null;
 state.exitedTestKey = null;
 state.reviewFilter = "all";
 timerPaused = false;
 goHomeDashboard();
});

/* Below-Action-Bar Collapsible Palette Drawer */
function toggleBelowDrawer(panelId, btnId, arrowId){
 const panel = $(panelId);
 const btn = $(btnId);
 const willOpen = !panel.classList.contains("open");
 panel.classList.toggle("open", willOpen);
 btn.classList.toggle("active", willOpen);
 btn.setAttribute("aria-expanded", String(willOpen));
 $(arrowId).textContent = willOpen ? "▲" : "▼";
}
$("togglePaletteDrawerBtn").addEventListener("click", () => {
 toggleBelowDrawer("paletteDrawerPanel", "togglePaletteDrawerBtn", "palArrowIcon");
});

/* Palette Table Row Click */
$("paletteTableBody").addEventListener("click", e => {
 const tr = e.target.closest("tr[data-qidx]");
 if(!tr) return;
 const idx = parseInt(tr.dataset.qidx, 10);
 const cs = getSessionState();
 goToQuestion(idx, idx > cs.currentIdx ? "next" : "prev");
});

$("palFilterBar").addEventListener("click", e => {
 const btn = e.target.closest("button.pal-filter[data-filter]");
 if(!btn) return;
 state.reviewFilter = btn.dataset.filter;
 renderPaletteTable();
});

/* OPTION SELECTION RULES:
   Instant Answer Mode: one tap selects and locks the answer immediately.
   Final Submit Mode: one tap selects an option; tapping the same option again
   clears it until the test is submitted. */
let lastOptKey = "";
let lastOptTime = 0;

$("questionCard").addEventListener("click", e => {
 const retryTimer=e.target.closest("[data-retry-question-timer]");
 if(retryTimer){
  const active=getActiveSession(),sessionState=getSessionState(active),idx=sessionState.currentIdx;
  sessionState.qTimedOut[idx]=false;sessionState.qTimeLeft[idx]=getPerQuestionSec();
  timerPaused=false;saveState();renderQuestion("");startTimer(0);return;
 }
 const solutionAction = e.target.closest("[data-solution-action]");
 if(solutionAction){
  const action = solutionAction.dataset.solutionAction;
  const sess = getActiveSession(); const cs = getSessionState(sess);
  if(!cs.answers[cs.currentIdx] || state.answerMode !== "instant") return;
  if(action === "toggle"){
   solutionPanelOpen = !solutionPanelOpen; renderQuestion(""); return;
  }
  if(action === "close"){
   solutionPanelOpen = false;
   clearSolutionHideTimer();
   const panel = document.getElementById("instantSolutionOverlay");
   if(panel) panel.remove();
   return;
  }
  if(action === "settings"){
   const pop = document.getElementById("explainSettingsPop");
   if(pop){
    pop.remove();
    scheduleSolutionAutoHide();
   } else {
    clearSolutionHideTimer();
    const panel = document.getElementById("instantSolutionOverlay");
    if(panel){
     panel.insertAdjacentHTML("beforeend", `<div class="explain-settings-pop" id="explainSettingsPop"><label for="explainAutoHideSelect">Auto-close after</label><select id="explainAutoHideSelect">${[0,3,5,8,10,15,20].map(v=>`<option value="${v}" ${state.explanationAutoHideSec===v?'selected':''}>${v===0?'Never':v+' seconds'}</option>`).join("")}</select><div style="font-size:.72rem;color:var(--muted);margin-top:6px">0 = close manually using ×</div><div class="explain-settings-actions"><button type="button" class="explain-ok-btn" data-solution-action="confirm-ok">OK</button></div></div>`);
    }
   }
   return;
  }
  if(action === "confirm-ok"){
   const select = document.getElementById("explainAutoHideSelect");
   if(select){
    const n = Number(select.value);
    if([0,3,5,8,10,15,20].includes(n)){ state.explanationAutoHideSec=n; saveState(); }
   }
   const pop = document.getElementById("explainSettingsPop");
   if(pop) pop.remove();
   scheduleSolutionAutoHide();
   return;
  }
 }
 const resetT = e.target.closest('[data-action="reset-q-timer"]');
 if(resetT){
  const cs = getSessionState();
  cs.qTimeLeft[cs.currentIdx] = getPerQuestionSec();
  delete cs.qTimedOut[cs.currentIdx];
  timerPaused = false;
  saveState();
  renderQuestion("");
  startTimer();
  return;
 }

 const optBtn = e.target.closest("button.opt-card[data-opt]");
 if(!optBtn || optBtn.disabled) return;

 const sess = getActiveSession();
 const cs = getSessionState(sess);
 if(cs.submitted) return;

 const letter = optBtn.dataset.opt;
 lastOptKey = "";
 lastOptTime = 0;

 if(state.answerMode === "instant"){
  if(cs.answers[cs.currentIdx]) return;
  cs.answers[cs.currentIdx] = letter;
  homeStudySnapshotCache.at=0;
  const currentQ = sess.questions[cs.currentIdx];
  solutionPanelOpen = letter !== currentQ.answer;
  saveState();
  renderQuestion("");
 } else {
  /* Final Submit Mode: single click selects option (or toggles off if same option clicked again) */
  if(cs.answers[cs.currentIdx] === letter){
   delete cs.answers[cs.currentIdx];
  } else {
   cs.answers[cs.currentIdx] = letter;
  }
  homeStudySnapshotCache.at=0;
  saveState();
  renderQuestion("");
 }
});



/* Bottom Navigation Action Bar */
$("prevBtn").addEventListener("click", () => {
 solutionPanelOpen = false; clearSolutionHideTimer();
 const cs = getSessionState();
 if(cs.currentIdx > 0) goToQuestion(cs.currentIdx - 1, "prev");
});
$("nextBtn").addEventListener("click", () => {
 solutionPanelOpen = false; clearSolutionHideTimer();
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 if(cs.currentIdx < sess.questions.length - 1) goToQuestion(cs.currentIdx + 1, "next");
});
$("clearBtn").addEventListener("click", () => {
 solutionPanelOpen = false; clearSolutionHideTimer();
 const cs = getSessionState();
 if(cs.submitted) return;
 delete cs.answers[cs.currentIdx];
 lastOptKey = "";
 saveState();
 renderQuestion("");
});
$("markBtn").addEventListener("click", () => {
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 if(cs.submitted) return;
 if(cs.marked[cs.currentIdx]){
  delete cs.marked[cs.currentIdx];
 } else {
  cs.marked[cs.currentIdx] = true;
  if(cs.currentIdx < sess.questions.length - 1){
   goToQuestion(cs.currentIdx + 1, "next");
   return;
  }
 }
 saveState();
 renderQuestion("");
});
$("submitBtn").addEventListener("click", openSubmitModal);
/* Exit only after two deliberate taps within 500 ms. A single tap is harmless. */
(()=>{
 const exitBtn=$("exitTestFromSubmitBtn");
 let firstTapAt=0, resetHandle=null;
 if(!exitBtn) return;
 exitBtn.addEventListener("click",()=>{
  const now=performance.now();
  if(firstTapAt && now-firstTapAt<=500){
   if(resetHandle) clearTimeout(resetHandle);
   firstTapAt=0;
   exitBtn.classList.remove("tap-armed");
   exitBtn.textContent="Exit from Test";
   closeSubmitModal();
   const sess=getActiveSession();
   const cs=getSessionState(sess);
   cs.pausedByAppHide=true;
   state.exitedTestKey=sess.key;
   timerPaused=true;
   stopTimer();
   setDisplayMode("normal");
   isHomeDashboard=true;
   $("homeDashboard").hidden=false;
   $("mockWorkspace").style.display="none";
   $("scorecardView").style.display="none";
   $("scorecardView").classList.remove("active");
   document.body.classList.remove("submitted-scorecard-only");
   document.documentElement.classList.remove("scorecard-scroll-unlocked","primary-lock");
   document.body.classList.remove("scorecard-scroll-unlocked");
   updateHomeChapterLabel();
   renderExitedTestHomeState();
   saveState();
   window.scrollTo({top:0,behavior:"smooth"});
   return;
  }
  firstTapAt=now;
  exitBtn.classList.add("tap-armed");
  exitBtn.textContent="Tap again to exit";
  if(resetHandle) clearTimeout(resetHandle);
  resetHandle=setTimeout(()=>{
   firstTapAt=0;
   exitBtn.classList.remove("tap-armed");
   exitBtn.textContent="Exit from Test";
  },500);
 });
})();
$("cancelSubmitBtn").addEventListener("click", closeSubmitModal);
$("confirmSubmitBtn").addEventListener("click", finalizeSubmit);
$("submitModal").addEventListener("click", e => { if(e.target === $("submitModal")) closeSubmitModal(); });
$("resetChapterBtn").addEventListener("click", resetCurrentSession);

$("pauseTimerBtn").addEventListener("click", () => {
 const sess = getActiveSession();
 const cs = getSessionState(sess);
 timerPaused = !timerPaused;
 cs.pausedByAppHide = timerPaused;
 lastSecTickMs = performance.now();
 if(timerPaused){
  stopTimer();
  syncTimerUI(lastSecTickMs);
 }else{
  startTimer(0);
  syncTimerUI(lastSecTickMs);
 }
 saveState();
});

function pauseActiveTestForBackground(){
 const sess=getActiveSession(), cs=getSessionState(sess);
 if(displayMode !== "test" || !cs.testStarted || cs.submitted || cs.viewingScorecard) return;
 timerPaused=true;
 cs.pausedByAppHide=true;
 lastSecTickMs=performance.now();
 stopTimer();
 syncTimerUI(lastSecTickMs);
 saveState();
}
document.addEventListener("visibilitychange",()=>{
 if(document.hidden) pauseActiveTestForBackground();
});
window.addEventListener("pagehide",pauseActiveTestForBackground);
document.addEventListener("fullscreenchange",()=>{
 if(displayMode==="test" && !document.fullscreenElement) pauseActiveTestForBackground();
});

/* Selector Change */
$("partSelect").addEventListener("change", e => {
 handleMainSubjectChange(e.target.value);
});
$("chapterSelect").addEventListener("change", e => {
 state.customSession = null;
 state.chapterIdx = parseInt(e.target.value, 10) || 0;
 state.reviewFilter = "all";
 timerPaused = false;
 saveState();
 renderChapterView();
});

/* Popovers */
function togglePopover(popId, btnId){
 const pop = $(popId);
 const btn = $(btnId);
 const willOpen = !pop.classList.contains("open");
 closePopovers();
 if(willOpen){
  pop.classList.add("open");
  btn.setAttribute("aria-expanded", "true");
 }
}
$("timerMenuBtn").addEventListener("click", e => {
 e.stopPropagation();
 const willOpen = !$("timerPopover").classList.contains("open");
 togglePopover("timerPopover","timerMenuBtn");
 if(willOpen) beginTimerSettingsDraft();
});
$("modeMenuBtn").addEventListener("click", e => {
 e.stopPropagation();
 const willOpen = !$("modePopover").classList.contains("open");
 togglePopover("modePopover","modeMenuBtn");
 if(willOpen) beginAnswerSettingsDraft();
});

$("timerPopover").addEventListener("click", e => {
 e.stopPropagation();
 const opt = e.target.closest("[data-timer-mode]");
 if(opt && pendingTimerPrefs){
  pendingTimerPrefs.timerMode = opt.dataset.timerMode;
  syncPopoverControls();
 }
});
$("autoNextCheck").addEventListener("change", e => {
 if(pendingTimerPrefs) pendingTimerPrefs.autoNextOnTimeout = !!e.target.checked;
});
$("applyCustomTimerBtn").addEventListener("click", e => {
 e.stopPropagation();
 if(!pendingTimerPrefs) beginTimerSettingsDraft();
 pendingTimerPrefs.customPerSec = Math.max(5, Math.min(600, parseInt($("customPerSecInput").value,10)||30));
 pendingTimerPrefs.customChapterMin = Math.max(1, Math.min(300, parseInt($("customChapMinInput").value,10)||25));
 if(pendingTimerPrefs.timerMode === "off") pendingTimerPrefs.timerMode = "per30";
 $("customTimerBox").classList.remove("open");
 $("timerPencilBtn").classList.remove("open");
 $("timerPencilBtn").setAttribute("aria-expanded","false");
 syncPopoverControls();
});
$("timerOkBtn").addEventListener("click", e => {
 e.stopPropagation();
 if(!pendingTimerPrefs) beginTimerSettingsDraft();
 const draft = pendingTimerPrefs;
 state.timerMode = draft.timerMode;
 state.autoNextOnTimeout = draft.autoNextOnTimeout;
 state.customPerSec = draft.customPerSec;
 state.customChapterMin = draft.customChapterMin;
 const activeSessionForTimer = getActiveSession();
 const activeStateForTimer = getSessionState(activeSessionForTimer);
 if(activeStateForTimer&&!activeStateForTimer.submitted&&!activeStateForTimer.testStarted&&!activeSessionForTimer.isCustom){
  if(state.timerMode==="per30") activeStateForTimer.qTimeLeft={};
  if(state.timerMode==="chapter25") activeStateForTimer.chapterTimeLeft=getChapterTotalSec(activeSessionForTimer);
 }
 pendingTimerPrefs = null;
 refreshTimerLabels();
 syncPopoverControls();
 saveState();
 closePopovers();
 if(!isHomeDashboard) {
  startTimer();
  renderQuestion("");
 }
});
$("timerCancelBtn").addEventListener("click", e => {
 e.stopPropagation();
 cancelTimerSettingsDraft();
 closePopovers();
});
$("modePopover").addEventListener("click", e => {
 e.stopPropagation();
 const opt = e.target.closest("[data-answer-mode]");
 if(opt){
  pendingAnswerMode = opt.dataset.answerMode;
  syncPopoverControls();
 }
});
$("answerOkBtn").addEventListener("click", e => {
 e.stopPropagation();
 if(pendingAnswerMode) state.answerMode = pendingAnswerMode;
 pendingAnswerMode = null;
 solutionPanelOpen = false;
 clearSolutionHideTimer();
 lastOptKey = "";
 syncPopoverControls();
 saveState();
 closePopovers();
 if(!isHomeDashboard) renderQuestion("");
});
$("answerCancelBtn").addEventListener("click", e => {
 e.stopPropagation();
 cancelAnswerSettingsDraft();
 closePopovers();
});

document.addEventListener("click", e => {
 if(!e.target.closest(".icon-wrap")){
  closePopovers();
 }
});

/* Font Size */
function applyFontSize(){
 document.documentElement.style.setProperty("--font-size", state.fontSize + "px");
}
$("smaller").addEventListener("click", () => {
 state.fontSize = Math.max(13, state.fontSize - 1);
 applyFontSize();
 saveState();
});
$("larger").addEventListener("click", () => {
 state.fontSize = Math.min(26, state.fontSize + 1);
 applyFontSize();
 saveState();
});

/* Double-Click 1-Second Helper */
function bindDoubleClick1s(el, callback){
 let last = 0;
 el.addEventListener("click", e => {
  e.preventDefault();
  const now = Date.now();
  if(now - last <= 1000){
   last = 0;
   callback(e);
  } else {
   last = now;
  }
 });
}

/* Theme Toggle — Requires Double-Click within 1 Second */
function applyTheme(){
 document.documentElement.dataset.theme = state.theme;
 const meta = $("metaThemeColor");
 if(meta) meta.setAttribute("content", state.theme === "dark" ? "#090d16" : "#f0f4ff");
}
$("theme").addEventListener("click", () => {
 state.theme = state.theme === "dark" ? "light" : "dark";
 applyTheme();
 saveState();
});

/* Two display modes: Study preserves app panels; Test hides surrounding app UI. */
let primary = false; // true only while in focused Test Mode
let displayMode = "normal";
let isHomeDashboard = true;
function isModeActive(){ return displayMode === "study" || displayMode === "test"; }
function syncBarHint(){
 const note = $("browserBarNote");
 if(note) note.classList.remove("show"); // never show the in-app browser hint popup
}
$("dismissBarNoteBtn").addEventListener("click", () => {
 state.hideBarHint = true; saveState(); syncBarHint();
});
function requestAppFullscreen(){
 const root = document.documentElement;
 if(document.fullscreenElement || !root.requestFullscreen) return;
 try{ const p = root.requestFullscreen({navigationUI:"hide"}); if(p && typeof p.catch === "function") p.catch(() => {}); }catch(_){}
}

/* Back handling for Test Mode and Study Mode.
   Test Mode: Back is trapped.
   Study Mode: first Back is ignored; second Back within 2 seconds exits Study Mode.
   The Android Home gesture is deliberately untouched. */
const TEST_BACK_GUARD_DEPTH = 4;
const STUDY_BACK_EXIT_WINDOW_MS = 2000;
let testBackGuardActive = false;
let testBackGuardSequence = 0;
let studyBackGuardActive = false;
let lastStudyBackAt = 0;
let studyBackHintTimer = null;

function pushTestBackSentinel(){
 if(!testBackGuardActive || displayMode !== "test") return false;
 try{
  history.pushState(
   {mockTestStudioTestGuard:true, sequence:++testBackGuardSequence},
   "",
   location.href
  );
  return true;
 }catch(_){
  return false;
 }
}
function armTestBackGuard(){
 if(testBackGuardActive){
  for(let i=0;i<2;i++) pushTestBackSentinel();
  return;
 }
 testBackGuardActive = true;
 for(let i=0;i<TEST_BACK_GUARD_DEPTH;i++) pushTestBackSentinel();
}
function releaseTestBackGuard(){
 testBackGuardActive = false;
}
function showStudyBackHint(){
 let hint=document.getElementById("studyBackHint");
 if(!hint){
  hint=document.createElement("div");
  hint.id="studyBackHint";
  hint.className="study-back-hint";
  hint.setAttribute("role","status");
  hint.setAttribute("aria-live","polite");
  hint.textContent="Press Back again within 2 seconds to exit Study Mode";
  document.body.appendChild(hint);
 }
 hint.classList.add("visible");
 if(studyBackHintTimer) clearTimeout(studyBackHintTimer);
 studyBackHintTimer=setTimeout(()=>{
  hint.classList.remove("visible");
 },2100);
}
function hideStudyBackHint(){
 const hint=document.getElementById("studyBackHint");
 if(hint) hint.classList.remove("visible");
 if(studyBackHintTimer){
  clearTimeout(studyBackHintTimer);
  studyBackHintTimer=null;
 }
}
function armStudyBackGuard(){
 studyBackGuardActive=true;
 lastStudyBackAt=0;
 hideStudyBackHint();
 // One sentinel is enough: the first Back consumes it and popstate adds it again.
 try{
  history.pushState({mockTestStudioStudyGuard:true},"",location.href);
 }catch(_){}
}
function releaseStudyBackGuard(){
 studyBackGuardActive=false;
 lastStudyBackAt=0;
 hideStudyBackHint();
}
function handleStudyModeBack(){
 if(!studyBackGuardActive || displayMode!=="study") return;
 const now=Date.now();
 if(lastStudyBackAt && now-lastStudyBackAt<=STUDY_BACK_EXIT_WINDOW_MS){
  // Second Back within 2 seconds: leave Study Mode, but remain inside the app.
  releaseStudyBackGuard();
  setDisplayMode("normal");
  return;
 }
 lastStudyBackAt=now;
 showStudyBackHint();
 // Replace the popped state so the first Back cannot navigate away.
 try{
  history.pushState({mockTestStudioStudyGuard:true},"",location.href);
 }catch(_){}
}
window.addEventListener("popstate",()=>{
 if(testBackGuardActive && displayMode==="test"){
  // Test Mode never exits through device/browser Back.
  pushTestBackSentinel();
  return;
 }
 if(studyBackGuardActive && displayMode==="study"){
  handleStudyModeBack();
 }
},true);

// Suppress keyboard/browser Back shortcuts and apply the same two-press rule in Study Mode.
window.addEventListener("keydown",e=>{
 const backKeys=["BrowserBack","GoBack","Backspace"];
 const isBackKey=backKeys.includes(e.key) || (e.altKey && (e.key==="ArrowLeft" || e.key==="Left"));
 if(!isBackKey) return;
 if(testBackGuardActive && displayMode==="test"){
  e.preventDefault();e.stopPropagation();
  if(e.stopImmediatePropagation)e.stopImmediatePropagation();
  return;
 }
 if(studyBackGuardActive && displayMode==="study"){
  e.preventDefault();e.stopPropagation();
  if(e.stopImmediatePropagation)e.stopImmediatePropagation();
  handleStudyModeBack();
 }
},true);

// Restore guards if the browser revives the page from its back-forward cache.
window.addEventListener("pageshow",()=>{
 if(testBackGuardActive && displayMode==="test"){
  for(let i=0;i<2;i++) pushTestBackSentinel();
 }else if(studyBackGuardActive && displayMode==="study"){
  try{history.pushState({mockTestStudioStudyGuard:true},"",location.href);}catch(_){}
 }
});

function setDisplayMode(mode){
 displayMode = mode;
 if(mode === "test"){
  releaseStudyBackGuard();
  armTestBackGuard();
 }else if(mode === "study"){
  releaseTestBackGuard();
  if(!studyBackGuardActive) armStudyBackGuard();
 }else{
  releaseTestBackGuard();
  releaseStudyBackGuard();
 }
 primary = mode === "test";
 document.documentElement.classList.toggle("primary-lock", primary);
 document.documentElement.classList.toggle("study-lock", mode === "study");
 document.body.classList.toggle("primary-active", primary);
 document.body.classList.toggle("test-active", primary);
 document.body.classList.toggle("study-active", mode === "study");
 const backupDashboardCard = $("appDataSafetyCard");
 if(backupDashboardCard) backupDashboardCard.style.display = mode === "test" || mode === "study" ? "none" : "";
 const studyExit = $("exitStudy");
 if(studyExit) studyExit.style.display = mode === "study" ? "inline-flex" : "none";
 const studyBtn = $("studyModeBtn");
 if(studyBtn) studyBtn.style.display = (mode === "study" || mode === "test") ? "none" : "inline-flex";
 if(studyExit) studyExit.style.display = mode === "study" ? "inline-flex" : "none";
 closePopovers();
 if(isModeActive()) window.scrollTo(0,0);
 else if(document.fullscreenElement && document.exitFullscreen){ try{ const p=document.exitFullscreen(); if(p&&p.catch)p.catch(()=>{}); }catch(_){} }
 syncBarHint();
}
function setPrimary(on){ setDisplayMode(on ? "test" : "normal"); }
$("studyModeBtn").addEventListener("click", () => {
 if(isHomeDashboard){
  enterSelectedSession("study");
  return;
 }
 requestAppFullscreen();
 setDisplayMode("study");
});

/* Each mode has an independently movable floating Exit control.
   Move the control by dragging it; double-click / double-tap exits the active mode. */
function initMovableModeExit(btn, modeName){
 if(!btn) return;
 let origin = null, dragging = false, dragged = false, suppressClick = false, lastTap = 0;
 const storageKey = "mockStudio.exitPosition." + modeName;
 function clampPos(left, top){
  return {
   left:Math.min(Math.max(8,window.innerWidth-btn.offsetWidth-8),Math.max(8,left)),
   top:Math.min(Math.max(8,window.innerHeight-btn.offsetHeight-8),Math.max(8,top))
  };
 }
 function setPos(left, top, save){
  const p=clampPos(left,top);
  btn.style.right="auto"; btn.style.bottom="auto";
  btn.style.left=p.left+"px"; btn.style.top=p.top+"px";
  if(save){try{localStorage.setItem(storageKey,JSON.stringify(p));}catch(_){}}
 }
 try{
  const saved=JSON.parse(localStorage.getItem(storageKey)||"null");
  if(saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) setPos(saved.left,saved.top,false);
  else {btn.style.left="auto";btn.style.right="14px";btn.style.top="14px";btn.style.bottom="auto";}
 }catch(_){btn.style.left="auto";btn.style.right="14px";btn.style.top="14px";btn.style.bottom="auto";}
 btn.style.touchAction="none";
 btn.addEventListener("pointerdown",e=>{
  if(!isModeActive() || btn.style.display==="none") return;
  const r=btn.getBoundingClientRect();
  origin={id:e.pointerId,x:e.clientX,y:e.clientY,left:r.left,top:r.top};
  dragging=false;dragged=false;
  try{btn.setPointerCapture(e.pointerId);}catch(_){}
 });
 btn.addEventListener("pointermove",e=>{
  if(!origin || e.pointerId!==origin.id)return;
  const dx=e.clientX-origin.x,dy=e.clientY-origin.y;
  if(!dragging && Math.hypot(dx,dy)>6){
   dragging=true;dragged=true;btn.classList.add("is-dragging");
  }
  if(dragging){
   setPos(origin.left+dx,origin.top+dy,false);
   if(e.cancelable)e.preventDefault();
  }
 });
 function endPointer(e){
  if(!origin)return;
  if(dragged){
   const r=btn.getBoundingClientRect();
   setPos(r.left,r.top,true);
   suppressClick=true;
  }
  btn.classList.remove("is-dragging");
  try{if(e&&e.pointerId!=null)btn.releasePointerCapture(e.pointerId);}catch(_){}
  origin=null;dragging=false;
 }
 btn.addEventListener("pointerup",endPointer);
 btn.addEventListener("pointercancel",endPointer);
 btn.addEventListener("click",e=>{
  e.preventDefault();
  if(suppressClick){suppressClick=false;lastTap=0;return;}
  const now=Date.now();
  if(lastTap && now-lastTap<=520){lastTap=0;setDisplayMode(modeName === "test" ? "study" : "normal");}
  else lastTap=now;
 });
 btn.addEventListener("dblclick",e=>{
  e.preventDefault();e.stopPropagation();lastTap=0;
  setDisplayMode(modeName === "test" ? "study" : "normal");
 });
 window.addEventListener("resize", () => {
  if(btn.style.left && btn.style.left !== "auto"){
   const rect = btn.getBoundingClientRect();
   setPos(rect.left, rect.top, true);
  }
  if(isModeActive() && ((modeName==="study" && displayMode==="study") || (modeName==="test" && displayMode==="test"))){
   btn.style.display="inline-flex";
  }
 });
}
$("exitStudy").addEventListener("click", () => setDisplayMode("normal"));


/* Keyboard Shortcuts */
document.addEventListener("keydown", e => {
 if(e.key === "Escape"){
  closePopovers();
  closeSubmitModal();
  $("bookmarkModal").classList.remove("open");
  closePersModal();
  return;
 }
 const tag = (document.activeElement && document.activeElement.tagName) || "";
 if(tag === "SELECT" || tag === "INPUT" || $("submitModal").classList.contains("open") || $("bookmarkModal").classList.contains("open")) return;
 const cs = getSessionState();
 if(cs.viewingScorecard) return;
 if(e.key === "ArrowRight"){
  const sess = getActiveSession();
  if(cs.currentIdx < sess.questions.length - 1) goToQuestion(cs.currentIdx + 1, "next");
 } else if(e.key === "ArrowLeft"){
  if(cs.currentIdx > 0) goToQuestion(cs.currentIdx - 1, "prev");
 }
});


$("timerPencilBtn").addEventListener("click", e => {
 e.stopPropagation();
 const box = $("customTimerBox");
 const btn = $("timerPencilBtn");
 const willOpen = !box.classList.contains("open");
 box.classList.toggle("open", willOpen);
 btn.classList.toggle("open", willOpen);
 btn.setAttribute("aria-expanded", String(willOpen));
});
$("customTimerBox").addEventListener("click", e => e.stopPropagation());


/* Start Test: one click starts the test in the clean full-window layout.
   Fullscreen is requested only from this user gesture; browsers may decline it. */
$("startTestBtn").addEventListener("click", e => {
 e.preventDefault();
 enterSelectedSession("test");
});

/* Boot */
loadState();
// Keep the user's saved answer mode, timer mode and timer duration across reloads.
// Defaults are already defined in the initial state and are used only for fresh profiles.
saveState();
applyTheme();
applyFontSize();
/* Question Bank Manager: JSON validation, preview, duplicate-safe merge and export. */
let qbSelectedParsedBank=null;
let qbPreviewIsValid=false;
function qbOptionMap(options){
 if(Array.isArray(options)){
  const out={}; const letters="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  options.forEach((value,index)=>{out[letters[index]||String(index+1)]=String(value==null?"":value);});
  return out;
 }
 if(options && typeof options==="object"){
  const out={}; Object.keys(options).forEach(key=>{out[String(key).trim().toUpperCase()]=String(options[key]==null?"":options[key]);}); return out;
 }
 return {};
}
function qbCanonicaliseImportedBank(raw){
 const errors=[],warnings=[];
 if(!raw || typeof raw!=="object" || Array.isArray(raw) || !Array.isArray(raw.chapters))return {errors:["JSON structure invalid: a top-level chapters array is required."],warnings:[],bank:null};
 const subject=String(raw.subject||raw.name||"").trim();
 if(!subject)errors.push("Subject name is missing.");
 if(!raw.chapters.length)errors.push("The file has no chapters.");
 const bank={
  format_version:String(raw.format_version||"1.0"),bank_id:String(raw.bank_id||("import_"+Date.now())),
  subject,exam_focus:String(raw.exam_focus||"UPSC EPFO EO/AO & APFC"),
  bank_title:String(raw.bank_title||(subject+" Question Bank")),language:String(raw.language||"English"),
  created_date:String(raw.created_date||new Date().toISOString().slice(0,10)),
  source_notes:String(raw.source_notes||""),chapters:[]
 };
 const seenQuestionIds=new Set(),seenChapterIds=new Set(),seenChapterNames=new Set();
 let total=0;
 raw.chapters.forEach((chapter,ci)=>{
  const chapterLabel=`Chapter ${ci+1}`;
  if(!chapter || typeof chapter!=="object" || Array.isArray(chapter)){errors.push(`${chapterLabel} is not a valid object.`);return;}
  const title=String(chapter.title||"").trim(),titleKey=qbNorm(title);
  if(!title){errors.push(`${chapterLabel} has no title.`);return;}
  if(seenChapterNames.has(titleKey)){errors.push(`The chapter title "${title}" is repeated in this file. Chapter titles must be unique within a subject bank.`);return;}
  seenChapterNames.add(titleKey);
  if(!Array.isArray(chapter.questions)){errors.push(`Chapter "${title}" has no questions array.`);return;}
  let chapterId=String(chapter.id||("ch_"+String(ci+1).padStart(2,"0"))).trim();
  if(!chapterId){errors.push(`${chapterLabel} has an empty ID.`);return;}
  if(seenChapterIds.has(chapterId)){errors.push(`${chapterLabel} repeats chapter ID "${chapterId}".`);return;}
  seenChapterIds.add(chapterId);
  const outChapter={id:chapterId,chapter_no:Number(chapter.chapter_no)||ci+1,title,subheadings:Array.isArray(chapter.subheadings)?chapter.subheadings.map(x=>String(x)):[],questions:[]};
  const answerByIdentity=new Map(),fingerprints=new Set();
  chapter.questions.forEach((q,qi)=>{
   const label=`Chapter ${ci+1}, question ${qi+1}`;
   if(!q || typeof q!=="object" || Array.isArray(q)){errors.push(`${label} is not a valid object.`);return;}
   const stem=String(q.question||"").trim(),options=qbOptionMap(q.options);
   const optionKeys=Object.keys(options).filter(k=>String(options[k]).trim());
   if(!stem){errors.push(`${label} has no question text.`);return;}
   const missingOptions=["A","B","C","D"].filter(k=>!String(options[k]||"").trim());
   if(missingOptions.length){errors.push(`${label} is missing non-empty option(s): ${missingOptions.join(", ")}. Four-option MCQ format requires A, B, C and D.`);return;}
   let answer=q.answer;
   if(typeof answer==="string")answer=answer.trim().toUpperCase();
   if(Array.isArray(answer))answer=answer.map(x=>String(x).trim().toUpperCase());
   if(answer===null||answer===undefined||answer===""){errors.push(`${label} is missing a correct answer key.`);return;}
   const answers=Array.isArray(answer)?answer:[answer];
   if(answers.some(a=>!optionKeys.includes(String(a)))){errors.push(`${label} has an answer key that does not exist in its options.`);return;}
   if(Array.isArray(answer)){
    if(!answer.length||new Set(answer).size!==answer.length){errors.push(`${label} has an empty or repeated multiple-correct answer key.`);return;}
    if(answer.length>1){errors.push(`${label} uses multiple correct options, but the current Live Test answer selector supports one selected option per question. Import single-correct questions in this version.`);return;}
    answer=answer[0];
   }
   const id=String(q.id||`${chapterId}_q${String(q.qno||qi+1).padStart(3,"0")}`).trim();
   if(!id){errors.push(`${label} has an empty question ID.`);return;}
   if(seenQuestionIds.has(id)){errors.push(`${label} has a repeated question ID (${id}) in this subject bank.`);return;}
   seenQuestionIds.add(id);
   const clean={...q,id,qno:Number(q.qno)||qi+1,orig_qno:q.orig_qno==null?(Number(q.qno)||qi+1):q.orig_qno,
    subheading:String(q.subheading||"").trim(),question:stem,options,answer,
    verification_note:String(q.verification_note==null?"":q.verification_note).trim(),
    explanation:String(q.explanation||""),source:String(q.source||raw.source_notes||""),
    question_type:String(q.question_type||(Array.isArray(answer)?"multiple_correct":"single_correct")),
    difficulty:String(q.difficulty||"unknown"),tags:Array.isArray(q.tags)?q.tags.map(x=>String(x)):[]};
   const identity=qbQuestionIdentity(clean),fp=qbQuestionFingerprint(clean),oldAnswer=answerByIdentity.get(identity);
   if(oldAnswer!==undefined && oldAnswer!==String(answer)){
    errors.push(`${label} repeats an earlier question in Chapter "${title}" but has a different correct answer. Resolve this answer conflict before importing.`);
    return;
   }
   if(fingerprints.has(fp)){
    warnings.push(`${label} is an exact duplicate of another question in Chapter "${title}" and will be skipped during import.`);
    return;
   }
   answerByIdentity.set(identity,String(answer));
   fingerprints.add(fp);
   outChapter.questions.push(clean);total++;
  });
  outChapter.question_count=outChapter.questions.length;
  bank.chapters.push(outChapter);
 });
 bank.total_questions=total;bank.total_chapters=bank.chapters.length;
 if(Number.isFinite(Number(raw.total_questions))&&Number(raw.total_questions)!==total)warnings.push(`total_questions says ${raw.total_questions}, but ${total} readable questions were found. The actual count will be used.`);
 if(Number.isFinite(Number(raw.total_chapters))&&Number(raw.total_chapters)!==bank.chapters.length)warnings.push(`total_chapters says ${raw.total_chapters}, but ${bank.chapters.length} valid chapters were found. The actual count will be used.`);
 return {errors,warnings,bank};
}
function qbAllQuestions(bank){
 const rows=[];(bank&&bank.chapters||[]).forEach(ch=>(ch.questions||[]).forEach(q=>rows.push(q)));return rows;
}
function qbDuplicateKeySets(bank){
 const ids=new Set(),fps=new Set(),identities=new Map();
 (bank&&bank.chapters||[]).forEach(ch=>(ch.questions||[]).forEach(q=>{
  if(q.id)ids.add(String(q.id));
  const fp=qbQuestionFingerprint(q),identity=qbQuestionIdentity(q);
  if(fp)fps.add(fp);
  if(identity){if(!identities.has(identity))identities.set(identity,new Set());identities.get(identity).add(String(q.answer||""));}
 }));
 return {ids,fps,identities};
}
function qbFindChapterByTitle(chapters,title){
 const key=qbNorm(title);return (chapters||[]).find(ch=>key&&qbNorm(ch.title)===key)||null;
}
function qbGetTargetBank(){
 const idx=Number($("qbTargetSubject").value);
 return SUBJECT_BANKS[idx] || SUBJECT_BANKS[0] || null;
}
function qbSetManagerMessage(message,type){
 const el=$("qbManagerMessage");
 if(el){el.className=message?`qb-message ${type||""}`:"";el.textContent=message||"";}
 const addMessage=$("qbAddMessage"),deleteMessage=$("qbDeleteMessage");
 const activeMessage=!$("qbAddModal").hidden?addMessage:(!$("qbDeleteModal").hidden?deleteMessage:null);
 if(activeMessage){
  activeMessage.hidden=!message;
  activeMessage.className=message?`qb-message ${type||""}`:"qb-message";
  activeMessage.textContent=message||"";
 }
}
function qbSubjectNameCounts(){
 const counts=new Map();SUBJECT_BANKS.forEach(b=>{const key=qbNorm(b.name);counts.set(key,(counts.get(key)||0)+1);});return counts;
}
function qbSubjectOptionLabels(){
 const counts=qbSubjectNameCounts(),seen=new Map();
 return SUBJECT_BANKS.map((bank,idx)=>{
  const key=qbNorm(bank.name),count=counts.get(key)||1,ordinal=(seen.get(key)||0)+1;seen.set(key,ordinal);
  return {idx,label:count>1?`${bank.name} — Duplicate bank ${ordinal} of ${count}`:bank.name,count};
 });
}
function qbRefreshTargetChoices(){
 const labels=qbSubjectOptionLabels();
 const sel=$("qbTargetSubject");
 if(sel){const selected=sel.value;sel.innerHTML=labels.map(x=>`<option value="${x.idx}">${esc(x.label)}</option>`).join("");if(selected&&Number(selected)<SUBJECT_BANKS.length)sel.value=selected;}
 const addSel=$("qbNewChapterSubject");
 if(addSel){const selected=addSel.value;addSel.innerHTML=labels.map(x=>`<option value="${x.idx}">${esc(x.label)}</option>`).join("");if(selected&&Number(selected)<SUBJECT_BANKS.length)addSel.value=selected;}
 const exportSel=$("qbExportSubjectSelect");
 if(exportSel){const selected=exportSel.value;exportSel.innerHTML=labels.map(x=>`<option value="${x.idx}">${esc(x.label)}</option>`).join("");if(selected&&Number(selected)<SUBJECT_BANKS.length)exportSel.value=selected;exportSel.disabled=!SUBJECT_BANKS.length;}
 const targetField=$("qbTargetField");if(targetField)targetField.hidden=$("qbImportMode").value==="new";
 qbUpdateExportSummary();
}
function qbUpdateExportSummary(){
 const sel=$("qbExportSubjectSelect"),summary=$("qbExportSummary"),btn=$("qbExportSubjectBtn"),chapterSel=$("qbExportChapterSelect"),chapterBtn=$("qbExportChapterBtn");
 if(!sel||!summary)return;
 const bank=SUBJECT_BANKS[Number(sel.value)];
 if(!bank){
  summary.textContent="No subject bank is available to export.";
  if(btn)btn.disabled=true;if(chapterSel){chapterSel.innerHTML='<option value="">No chapters available</option>';chapterSel.disabled=true;}if(chapterBtn)chapterBtn.disabled=true;
  return;
 }
 const chapters=bank.chapters||[];
 if(chapterSel){const previous=chapterSel.value;chapterSel.innerHTML=chapters.map((ch,i)=>`<option value="${i}">${esc(ch.title||`Chapter ${i+1}`)} · ${(ch.questions||[]).length} Q</option>`).join("");chapterSel.disabled=!chapters.length;if(previous&&Number(previous)<chapters.length)chapterSel.value=previous;}
 if(chapterBtn)chapterBtn.disabled=!chapters.length;
 const questionCount=chapters.reduce((n,ch)=>n+(ch.questions||[]).length,0);
 summary.textContent=`${bank.name} · ${chapters.length} chapter(s) · ${questionCount} question(s).`;
 if(btn)btn.disabled=false;
}
function qbRenderStatsAndBanks(){
 qbRefreshTargetChoices();
 const duplicates=[...qbSubjectNameCounts().entries()].filter(([,count])=>count>1).map(([key])=>SUBJECT_BANKS.find(b=>qbNorm(b.name)===key)?.name||key);
 if(duplicates.length)qbSetManagerMessage("Warning: duplicate Subject Bank names were found: "+duplicates.join(", ")+". Export a backup, then resolve the duplicate names before merging or adding chapters.","error");
 else qbSetManagerMessage("","");
}
function qbCalculatePreview(){
 if(!qbSelectedParsedBank||!qbSelectedParsedBank.bank)return null;
 const bank=qbSelectedParsedBank.bank,mode=$("qbImportMode").value;
 const target=mode==="merge"?qbGetTargetBank():null;
 const subjectConflict=mode==="new"&&SUBJECT_BANKS.some(b=>qbNorm(b.name)===qbNorm(bank.subject));
 const targetAmbiguous=mode==="merge"&&target&&SUBJECT_BANKS.filter(b=>qbNorm(b.name)===qbNorm(target.name)).length>1;
 let duplicates=0,newCount=0,conflicts=0,newChapters=0;
 const incomingByChapter=new Map();
 bank.chapters.forEach(ch=>{
  const dest=mode==="merge"&&target?qbFindChapterByTitle(target.chapters,ch.title):null;
  if(mode==="merge"&&!dest)newChapters++;
  const existing=dest?(dest.questions||[]):[];
  const existingFps=new Set(existing.map(qbQuestionFingerprint));
  const existingAnswers=new Map();
  existing.forEach(q=>{const id=qbQuestionIdentity(q);if(!existingAnswers.has(id))existingAnswers.set(id,new Set());existingAnswers.get(id).add(String(q.answer||""));});
  const seenFps=new Set(),seenAnswers=new Map();
  ch.questions.forEach(q=>{
   const fp=qbQuestionFingerprint(q),identity=qbQuestionIdentity(q),ans=String(q.answer||"");
   if(existingFps.has(fp)||seenFps.has(fp)){duplicates++;return;}
   const prior=existingAnswers.get(identity)||seenAnswers.get(identity);
   if(prior&&prior.size&&!prior.has(ans)){conflicts++;return;}
   newCount++;seenFps.add(fp);
   if(!seenAnswers.has(identity))seenAnswers.set(identity,new Set());seenAnswers.get(identity).add(ans);
  });
 });
 const chaptersToAdd=mode==="new"?bank.chapters.length:newChapters;
 const canImport=!subjectConflict&&!targetAmbiguous&&!conflicts&&(newCount>0||chaptersToAdd>0)&&!!(mode==="new"||target);
 return {incoming:bank.total_questions,newCount,duplicates,conflicts,chapters:chaptersToAdd,target,subjectConflict,targetAmbiguous,canImport};
}
function qbRenderPreview(){
 const panel=$("qbPreviewPanel"),msg=$("qbPreviewMessage");
 if(!qbSelectedParsedBank){panel.hidden=true;$("qbImportBtn").disabled=true;return;}
 const preview=qbCalculatePreview();
 $("qbPreviewTitle").textContent=`Preview: ${qbSelectedParsedBank.bank.subject}`;
 $("qbPreviewIncoming").textContent=preview.incoming;
 $("qbPreviewAdd").textContent=preview.newCount;
 $("qbPreviewDup").textContent=preview.duplicates;
 $("qbPreviewChapters").textContent=preview.chapters;
 const warnings=qbSelectedParsedBank.warnings||[];
 const mode=$("qbImportMode").value;
 const dest=mode==="new"?"a separate subject bank":`existing subject "${preview.target?preview.target.name:"(not selected)"}"`;
 msg.className="qb-message";
 if(preview.subjectConflict){
  msg.classList.add("error");msg.textContent=`A subject named "${qbSelectedParsedBank.bank.subject}" already exists. Choose Merge into an existing subject, or rename the subject in your JSON file.`;
 }else if(preview.targetAmbiguous){
  msg.classList.add("error");msg.textContent=`Merge blocked: more than one Subject Bank is named "${preview.target.name}". Rename/resolve the duplicate subject banks first; the importer will not guess which bank you intended.`;
 }else if(preview.conflicts){
  msg.classList.add("error");msg.textContent=`Import blocked: ${preview.conflicts} question(s) have the same question text and options as existing/incoming questions but a different correct answer. Resolve these answer conflicts in the JSON before importing.`;
 }else{
  msg.textContent=`Ready to import ${preview.newCount} new question(s) into ${dest}. ${preview.duplicates} exact duplicate(s) will be skipped; ${preview.chapters} new chapter(s) will be added.`+(warnings.length?" Notes: "+warnings.join(" "):"");
  if(!preview.canImport)msg.textContent="No new questions or chapters to import. The incoming content already exists in the selected subject.";
 }
 panel.hidden=false;qbPreviewIsValid=true;$("qbImportBtn").disabled=!preview.canImport;
}
function qbRenderValidationReport(result){
 const panel=$("qbValidationReport"),stats=$("qbValidationStats"),errors=$("qbValidationErrors"),warnings=$("qbValidationWarnings");
 if(!panel||!result)return;panel.hidden=false;
 const chapterCount=result.bank?result.bank.chapters.length:0,questionCount=result.bank?result.bank.total_questions:0;
 stats.innerHTML=[`<span>Chapters checked: ${chapterCount}</span>`,`<span>Valid questions: ${questionCount}</span>`,`<span>Errors: ${result.errors.length}</span>`,`<span>Warnings: ${result.warnings.length}</span>`].join("");
 errors.innerHTML=result.errors.length?result.errors.map(x=>`<li>${esc(x)}</li>`).join(""):"<li>No validation errors found.</li>";
 warnings.innerHTML=result.warnings.length?result.warnings.map(x=>`<li>${esc(x)}</li>`).join(""):"<li>No warnings.</li>";
}
let qbFileReadSequence=0;
async function qbReadFileText(file){
 let textError=null;
 // Prefer the modern Blob/File API, but fall back to FileReader for older Android
 // WebViews and file-provider implementations that do not expose File.text().
 if(file && typeof file.text==="function"){
  try{return await file.text();}catch(error){textError=error;}
 }
 if(typeof FileReader!=="undefined"){
  try{
   return await new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(String(reader.result==null?"":reader.result));
    reader.onerror=()=>reject(reader.error||new Error("The browser could not read the selected file."));
    reader.onabort=()=>reject(new Error("File reading was cancelled."));
    reader.readAsText(file,"UTF-8");
   });
  }catch(error){textError=error;}
 }
 throw textError||new Error("This browser could not read the selected file. Please save it on the device and choose it again.");
}
async function qbReadAndValidateFile(fileOverride=null){
 const input=$("qbJsonFile");
 const file=fileOverride||(input && input.files && input.files[0]);
 const readSequence=++qbFileReadSequence;
 qbSelectedParsedBank=null;qbPreviewIsValid=false;
 $("qbPreviewPanel").hidden=true;$("qbImportBtn").disabled=true;
 const validationPanel=$("qbValidationReport");if(validationPanel)validationPanel.hidden=true;
 if(!file){$("qbPreviewBtn").disabled=true;return;}
 const fileName=String(file.name||"Selected JSON file");
 const fileType=String(file.type||"not reported by browser");
 if($("qbFileName"))$("qbFileName").textContent=fileName;
 $("qbPreviewBtn").disabled=true;
 qbSetManagerMessage(`Reading ${fileName}…`,"");
 try{
  let sourceText=await qbReadFileText(file);
  if(readSequence!==qbFileReadSequence)return;
  sourceText=String(sourceText==null?"":sourceText).replace(/^\uFEFF/,"").trim();
  if(!sourceText)throw new Error("The selected file is empty.");
  let raw;
  try{raw=JSON.parse(sourceText);}catch(parseError){
   const detail=parseError&&parseError.message?parseError.message:"Unknown JSON syntax error";
   throw new Error(`The file was read, but its contents are not valid JSON. ${detail}`);
  }
  const result=qbCanonicaliseImportedBank(raw);
  if(readSequence!==qbFileReadSequence)return;
  qbRenderValidationReport(result);
  if(result.errors.length){
   qbSetManagerMessage(`JSON was read successfully, but validation found ${result.errors.length} issue(s). Review the Detailed Import Validation report below.`,"error");
   $("qbPreviewBtn").disabled=true;return;
  }
  qbSelectedParsedBank={bank:result.bank,warnings:result.warnings,fileName};
  qbSetManagerMessage(`File loaded successfully: ${fileName}. ${result.bank.total_questions} questions in ${result.bank.total_chapters} chapters. Select an import action and preview.`,"");
  $("qbPreviewBtn").disabled=false;
 }catch(err){
  if(readSequence!==qbFileReadSequence)return;
  const detail=err&&err.message?err.message:"Unknown file-reading error";
  qbRenderValidationReport({bank:null,errors:[detail],warnings:[]});
  qbSetManagerMessage(`Could not load the selected file (${fileName}; browser type: ${fileType}). ${detail}`,"error");
  $("qbPreviewBtn").disabled=true;
 }
}
function qbMergeIntoRuntime(target,incoming){
 const added={questions:0,duplicates:0,chapters:0};if(!target||!incoming)return added;
 const usedIds=new Set();target.chapters.forEach(ch=>(ch.questions||[]).forEach(q=>{if(q.id)usedIds.add(String(q.id));}));
 incoming.chapters.forEach((inc,ci)=>{
  let dest=qbFindChapterByTitle(target.chapters,inc.title);
  if(!dest){
   const id=qbUniqueId(inc.id||`imported_ch_${target.chapters.length+1}`,new Set(target.chapters.map(ch=>String(ch.id||""))));
   const nextNo=target.chapters.reduce((m,ch)=>Math.max(m,Number(ch.chapter_no)||0),0)+1;
   dest={id,chapter_no:nextNo,title:inc.title||`Imported Chapter ${ci+1}`,subheadings:[...(inc.subheadings||[])],questions:[]};target.chapters.push(dest);added.chapters++;
  }
  const fps=new Set((dest.questions||[]).map(qbQuestionFingerprint));
  (inc.questions||[]).forEach(raw=>{
   const q=JSON.parse(JSON.stringify(raw)),fp=qbQuestionFingerprint(q);
   if(fp&&fps.has(fp)){added.duplicates++;return;}
   q.id=qbUniqueId(q.id||`${dest.id}_q${dest.questions.length+1}`,usedIds,"_import");q.qno=dest.questions.length+1;
   dest.questions.push(q);usedIds.add(q.id);if(fp)fps.add(fp);added.questions++;
  });
  dest.question_count=dest.questions.length;
 });
 target.total_questions=target.chapters.reduce((n,ch)=>n+(ch.questions||[]).length,0);target.total_chapters=target.chapters.length;
 return added;
}
function qbCreateNewRuntimeBank(incoming){
 const copy=JSON.parse(JSON.stringify(incoming));
 const key="subject_user_"+Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,6);
 const descriptor={key,name:String(copy.subject||copy.name||"Imported Subject"),chapters:copy.chapters,primary:false};
 SUBJECT_BANKS.push(descriptor);
 return descriptor;
}
function qbExportBank(index,chapterIndex=null){
 const bank=SUBJECT_BANKS[index];if(!bank)return;
 const sourceChapters=chapterIndex===null?(bank.chapters||[]):[(bank.chapters||[])[chapterIndex]].filter(Boolean);
 if(chapterIndex!==null&&!sourceChapters.length){qbSetManagerMessage("Please select a valid chapter to export.","error");return;}
 const chapters=sourceChapters.map(ch=>({
  id:ch.id,chapter_no:ch.chapter_no,title:ch.title,
  subheadings:Array.isArray(ch.subheadings)?ch.subheadings:[],
  question_count:(ch.questions||[]).length,
  questions:(ch.questions||[]).map(q=>({...JSON.parse(JSON.stringify(q)),verification_note:String(q.verification_note||"")}))
 }));
 const payload={
  format_version:"2.0",
  bank_id:"export_"+qbSafeSlug(bank.name)+(chapterIndex===null?"":"_"+qbSafeSlug(chapters[0]?.title||"chapter"))+"_"+Date.now(),
  subject:bank.name,
  exam_focus:"UPSC EPFO EO/AO & APFC",
  bank_title:bank.name+(chapterIndex===null?"":" — "+(chapters[0]?.title||"Chapter"))+" Question Bank",
  language:"English",
  created_date:new Date().toISOString().slice(0,10),
  source_notes:"Exported from Mock Test Studio. Question wording, options, answers, explanations, IDs and source fields are preserved.",
  total_questions:chapters.reduce((n,ch)=>n+ch.question_count,0),
  total_chapters:chapters.length,
  chapters
 };
 const blob=new Blob([JSON.stringify(payload,null,2)],{type:"application/json;charset=utf-8"});
 const url=URL.createObjectURL(blob);
 const a=document.createElement("a");
 a.href=url;a.download=qbSafeSlug(bank.name)+"_QuestionBank.json";
 document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),1000);
 qbSetManagerMessage(`Exported ${payload.total_questions} question(s) from ${bank.name} across ${payload.total_chapters} chapter(s).`,"success");
}
function qbSafeSlug(value){
 return String(value||"").toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g,"_").replace(/^_+|_+$/g,"").slice(0,42)||"subject";
}
function qbReadStoredRecordsStrict(){
 const raw=localStorage.getItem(QUESTION_BANK_STORAGE_KEY);
 if(raw===null)return [];
 const parsed=JSON.parse(raw);
 if(!Array.isArray(parsed))throw new Error("Question Bank records are not a valid list.");
 return parsed;
}
function qbReadDeletionStateStrict(){
 const raw=localStorage.getItem(QUESTION_BANK_DELETIONS_KEY);
 if(raw===null)return {subjects:[],chapters:[]};
 const parsed=JSON.parse(raw);
 if(!parsed||typeof parsed!=="object"||Array.isArray(parsed)||
    (parsed.subjects!==undefined&&!Array.isArray(parsed.subjects))||
    (parsed.chapters!==undefined&&!Array.isArray(parsed.chapters)))throw new Error("Question Bank deletion settings are invalid.");
 return {subjects:Array.isArray(parsed.subjects)?parsed.subjects.slice():[],chapters:Array.isArray(parsed.chapters)?parsed.chapters.slice():[]};
}
function qbCommitStorageUpdates(updates,failureMessage){
 const before={};Object.keys(updates).forEach(key=>before[key]=localStorage.getItem(key));
 try{
  Object.entries(updates).forEach(([key,value])=>{if(value===null)localStorage.removeItem(key);else localStorage.setItem(key,value);});
  return true;
 }catch(err){
  let rollbackOk=true;
  Object.entries(before).forEach(([key,value])=>{try{if(value===null)localStorage.removeItem(key);else localStorage.setItem(key,value);}catch(_){rollbackOk=false;}});
  qbSetManagerMessage((failureMessage||"The operation could not be saved.")+" "+(rollbackOk?"Previous saved data was restored.":"Automatic rollback was incomplete; export a Full Backup and do not repeat the operation until storage is checked."),"error");
  return false;
 }
}
function qbImportSelectedBank(){
 if(!qbSelectedParsedBank||!qbPreviewIsValid)return;
 const preview=qbCalculatePreview();
 if(!preview||!preview.canImport){qbRenderPreview();return;}
 const mode=$("qbImportMode").value,bank=JSON.parse(JSON.stringify(qbSelectedParsedBank.bank));
 if(mode==="new"&&SUBJECT_BANKS.some(b=>qbNorm(b.name)===qbNorm(bank.subject))){qbSetManagerMessage(`Subject "${bank.subject}" already exists. Use Merge instead of creating a duplicate subject.`,"error");return;}
 if(mode==="merge"&&!preview.target){qbSetManagerMessage("Select an existing subject before merging.","error");return;}
 if(mode==="merge"&&SUBJECT_BANKS.filter(b=>qbNorm(b.name)===qbNorm(preview.target.name)).length>1){qbSetManagerMessage(`More than one Subject Bank is named "${preview.target.name}". Merge is stopped to prevent adding questions to the wrong bank.`,"error");return;}
 let records,deletionState;
 try{records=qbReadStoredRecordsStrict();deletionState=qbReadDeletionStateStrict();}
 catch(err){qbSetManagerMessage("Import stopped to protect existing data: "+err.message+" Download a Full Backup before attempting recovery.","error");return;}
 if(mode==="new"){
  deletionState.subjects=deletionState.subjects.filter(v=>qbNorm(v)!==qbNorm(bank.subject));
  deletionState.chapters=deletionState.chapters.filter(v=>qbNorm(v.subject)!==qbNorm(bank.subject));
 }else{
  const subjectKey=qbNorm(preview.target.name);
  deletionState.chapters=deletionState.chapters.filter(entry=>{
   if(!entry||qbNorm(entry.subject)!==subjectKey)return true;
   return !bank.chapters.some(ch=>entry.title&&qbNorm(entry.title)===qbNorm(ch.title));
  });
 }
 records.push(mode==="merge"?{mode:"merge",target_subject:preview.target.name,bank}:{mode:"new",bank});
 const updates={
  [QUESTION_BANK_STORAGE_KEY]:JSON.stringify(records),
  [QUESTION_BANK_DELETIONS_KEY]:JSON.stringify({subjects:Array.from(new Set(deletionState.subjects.map(qbNorm))),chapters:deletionState.chapters})
 };
 if(!qbCommitStorageUpdates(updates,"Import was not completed because browser storage is full or unavailable."))return;
 const msg=mode==="merge"
  ?`Saved ${preview.newCount} new question(s) and ${preview.chapters} new chapter(s) for ${preview.target.name}; ${preview.duplicates} exact duplicate(s) were skipped.`
  :`Saved ${preview.newCount} question(s) in ${bank.subject}; ${preview.chapters} chapter(s) included and ${preview.duplicates} exact duplicate(s) were skipped.`;
 qbSetManagerMessage(msg+" The app will reload to activate the updated question bank. Existing bookmarks and test history are kept.","success");
 $("qbImportBtn").disabled=true;setTimeout(()=>window.location.reload(),900);
}
function qbOpenManager(){
 stopTimer();timerPaused=false;solutionPanelOpen=false;clearSolutionHideTimer();
 closeSubmitModal();closePopovers();closePersModal();
 isHomeDashboard=true;setDisplayMode("normal");
 $("homeDashboard").hidden=true;$("bookmarkPracticePage").hidden=true;$("mockWorkspace").style.display="none";
 $("scorecardView").style.display="none";$("scorecardView").classList.remove("active");
 document.body.classList.add("qb-manager-open");
 $("questionBankManagerPage").hidden=false;
 qbRenderStatsAndBanks();
 window.scrollTo({top:0,behavior:"smooth"});
}
function qbReturnHome(){
 document.body.classList.remove("qb-manager-open");
 $("qbAddModal").hidden=true;$("qbDeleteModal").hidden=true;
 goHomeDashboard();
}
function qbReadDeletionStateFresh(){return qbReadDeletionState();}
function qbWriteDeletionState(stateObj){
 try{
  localStorage.setItem(QUESTION_BANK_DELETIONS_KEY,JSON.stringify({
   subjects:Array.from(new Set(stateObj.subjects||[])),
   chapters:stateObj.chapters||[]
  }));
  return true;
 }catch(_){
  qbSetManagerMessage("Could not save deletion settings. No item was deleted.","error");
  return false;
 }
}
function qbPersistNewBankRecords(records,message,deletionState){
 let stored;
 try{stored=qbReadStoredRecordsStrict();}
 catch(err){qbSetManagerMessage("Could not add items because Question Bank storage is invalid: "+err.message+". Existing data was not changed.","error");return false;}
 const nextRecords=stored.concat(records);
 const updates={[QUESTION_BANK_STORAGE_KEY]:JSON.stringify(nextRecords)};
 if(deletionState)updates[QUESTION_BANK_DELETIONS_KEY]=JSON.stringify({subjects:Array.from(new Set(deletionState.subjects||[])),chapters:deletionState.chapters||[]});
 if(!qbCommitStorageUpdates(updates,"Could not save the new Subject/Chapter because browser storage is full or unavailable."))return false;
 $("qbAddModal").hidden=true;qbSetManagerMessage(message+" Reloading the updated question bank…","success");
 setTimeout(()=>window.location.reload(),700);return true;
}
function qbOpenAddModal(){
 $("qbAddMessage").hidden=true;$("qbAddMessage").textContent="";qbRefreshTargetChoices();
 $("qbAddSubjectsPane").hidden=false;$("qbAddChaptersPane").hidden=true;
 document.querySelectorAll("[data-qb-add-tab]").forEach(b=>b.classList.toggle("active",b.dataset.qbAddTab==="subjects"));
 $("qbAddModal").hidden=false;
}
function qbCreateMultipleSubjects(){
 const lines=$("qbMultiSubjectsInput").value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 if(!lines.length){qbSetManagerMessage("Enter at least one subject and its chapter list.","error");return;}
 const existing=new Set(SUBJECT_BANKS.map(b=>qbNorm(b.name))),seen=new Set(),records=[],stamp=Date.now();
 for(let i=0;i<lines.length;i++){
  const parts=lines[i].split("|");
  if(parts.length<2){qbSetManagerMessage(`Line ${i+1}: use Subject Name | Chapter 1; Chapter 2.`,"error");return;}
  const name=parts.shift().trim(),chapterNames=parts.join("|").split(";").map(x=>x.trim()).filter(Boolean),key=qbNorm(name);
  if(!name||!chapterNames.length){qbSetManagerMessage(`Line ${i+1}: provide a subject name and at least one chapter.`,"error");return;}
  if(existing.has(key)||seen.has(key)){qbSetManagerMessage(`Subject already exists or is repeated: ${name}.`,"error");return;}
  const chapterSeen=new Set();
  for(const title of chapterNames){const t=qbNorm(title);if(chapterSeen.has(t)){qbSetManagerMessage(`Duplicate chapter in ${name}: ${title}.`,"error");return;}chapterSeen.add(t);}
  seen.add(key);const slug=qbSafeSlug(name);
  const chapters=chapterNames.map((title,ci)=>({id:`${slug}_ch${String(ci+1).padStart(2,"0")}`,chapter_no:ci+1,title,subheadings:[],question_count:0,questions:[]}));
  records.push({mode:"new",bank:{format_version:"2.0",bank_id:`${slug}_${stamp}_${i+1}`,subject:name,bank_title:name+" Question Bank",language:"English",created_date:new Date().toISOString().slice(0,10),total_questions:0,total_chapters:chapters.length,chapters}});
 }
 let deletionState;
 try{deletionState=qbReadDeletionStateStrict();}catch(err){qbSetManagerMessage("Cannot safely add subjects because deletion settings are invalid: "+err.message,"error");return;}
 const names=new Set(records.map(r=>qbNorm(r.bank.subject)));
 deletionState.subjects=deletionState.subjects.filter(x=>!names.has(qbNorm(x)));
 deletionState.chapters=deletionState.chapters.filter(x=>!x||!names.has(qbNorm(x.subject)));
 qbPersistNewBankRecords(records,`Added ${records.length} subject(s) with ${records.reduce((n,r)=>n+r.bank.chapters.length,0)} chapter(s).`,deletionState);
}
function qbCreateMultipleChapters(){
 const target=SUBJECT_BANKS[Number($("qbNewChapterSubject").value)];
 const names=$("qbMultiChaptersInput").value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
 if(!target){qbSetManagerMessage("Select a subject.","error");return;}
 if(SUBJECT_BANKS.filter(b=>qbNorm(b.name)===qbNorm(target.name)).length>1){qbSetManagerMessage(`More than one Subject Bank is named "${target.name}". Adding chapters is stopped because the saved merge could resolve to the wrong bank. Resolve the duplicate subject names first.`,"error");return;}
 if(!names.length){qbSetManagerMessage("Enter at least one chapter name.","error");return;}
 const existing=new Set(target.chapters.map(ch=>qbNorm(ch.title))),seen=new Set();
 for(const title of names){const key=qbNorm(title);if(existing.has(key)||seen.has(key)){qbSetManagerMessage(`Chapter already exists or is repeated: ${title}.`,"error");return;}seen.add(key);}
 const nextNo=target.chapters.reduce((m,ch)=>Math.max(m,Number(ch.chapter_no)||0),0)+1;
 const slug=qbSafeSlug(target.name),stamp=Date.now();
 const usedIds=new Set(target.chapters.map(ch=>String(ch.id||"")));
 const chapters=names.map((title,idx)=>{
  const wanted=`${slug}_ch${String(nextNo+idx).padStart(2,"0")}_${String(stamp).slice(-5)}`;
  const id=qbUniqueId(wanted,usedIds);usedIds.add(id);
  return {id,chapter_no:nextNo+idx,title,subheadings:[],question_count:0,questions:[]};
 });
 let deletionState;try{deletionState=qbReadDeletionStateStrict();}catch(err){qbSetManagerMessage("Cannot safely add chapters because deletion settings are invalid: "+err.message,"error");return;}
 const subjectKey=qbNorm(target.name);
 deletionState.chapters=deletionState.chapters.filter(entry=>!entry||qbNorm(entry.subject)!==subjectKey||!chapters.some(ch=>entry.title&&qbNorm(entry.title)===qbNorm(ch.title)));
 const bank={format_version:"2.0",bank_id:`${slug}_chapters_${stamp}`,subject:target.name,bank_title:target.name+" Question Bank",language:"English",created_date:new Date().toISOString().slice(0,10),total_questions:0,total_chapters:chapters.length,chapters};
 qbPersistNewBankRecords([{mode:"merge",target_subject:target.name,bank}],`Added ${chapters.length} chapter(s) to ${target.name}.`,deletionState);
}
const QB_LOCKS_KEY="mockStudio.questionBankLocks.v1";
function qbReadLocksStrict(){
 const stored=localStorage.getItem(QB_LOCKS_KEY);
 if(stored===null)return {subjects:[],chapters:[]};
 const raw=JSON.parse(stored);
 if(!raw||typeof raw!=="object"||Array.isArray(raw)||
    (raw.subjects!==undefined&&!Array.isArray(raw.subjects))||
    (raw.chapters!==undefined&&!Array.isArray(raw.chapters)))throw new Error("Question Bank lock settings are invalid.");
 return {subjects:Array.isArray(raw.subjects)?Array.from(new Set(raw.subjects.map(String))):[],chapters:Array.isArray(raw.chapters)?Array.from(new Set(raw.chapters.map(String))):[]};
}
function qbReadLocks(){try{return qbReadLocksStrict();}catch(_){return {subjects:[],chapters:[]};}}
function qbWriteLocks(v){
 try{
  if(!v||!Array.isArray(v.subjects)||!Array.isArray(v.chapters))throw new Error("Invalid lock data");
  localStorage.setItem(QB_LOCKS_KEY,JSON.stringify({subjects:[...new Set(v.subjects.map(String))],chapters:[...new Set(v.chapters.map(String))]}));return true;
 }catch(_){qbSetManagerMessage("Could not save lock settings. Existing settings were left unchanged.","error");return false;}
}
function qbSubjectLockKey(name){return qbNorm(name);}
function qbChapterLockKey(subject,ch){return qbNorm(subject)+"::"+String(ch.id||qbNorm(ch.title));}
function qbIsSubjectLocked(name,locks=qbReadLocks()){return locks.subjects.includes(qbSubjectLockKey(name));}
function qbIsChapterLocked(subject,ch,locks=qbReadLocks()){return locks.chapters.includes(qbChapterLockKey(subject,ch));}
function qbRenderLockChoices(){
 const host=$("qbLockSelectionList");let locks;
 try{locks=qbReadLocksStrict();}catch(err){host.innerHTML=`<p class="qb-help">${esc(err.message)} Lock changes are disabled until the saved lock data is repaired.</p>`;$("qbLockSelectedBtn").disabled=true;$("qbUnlockSelectedBtn").disabled=true;return;}
 $("qbLockSelectedBtn").disabled=false;$("qbUnlockSelectedBtn").disabled=false;
 host.innerHTML=SUBJECT_BANKS.map((bank,bi)=>{
  const sl=qbIsSubjectLocked(bank.name,locks);
  const subj=`<label class="qbm-delete-subject-label"><input type="checkbox" class="qb-lock-subject" data-lock-subject="${bi}"><span>${esc(bank.name)}</span><small>${sl?"Deletion Protected":"Not Protected"}</small></label>`;
  const chapters=bank.chapters.map((ch,ci)=>{const cl=qbIsChapterLocked(bank.name,ch,locks);return `<label class="qbm-delete-chapter-label"><input type="checkbox" class="qb-lock-chapter" data-bank-idx="${bi}" data-chapter-idx="${ci}"><span>${esc(ch.title)}</span><small>${cl?"Deletion Protected":"Not Protected"}</small></label>`;}).join("");
  return `<div class="qbm-delete-subject">${subj}<div class="qbm-delete-chapters">${chapters}</div></div>`;
 }).join("");
}
function qbApplyLocks(locked){
 let locks;try{locks=qbReadLocksStrict();}catch(err){const m=$("qbLockMessage");m.hidden=false;m.textContent=err.message+" No lock settings were changed.";return;}let count=0;
 document.querySelectorAll(".qb-lock-subject:checked").forEach(cb=>{const b=SUBJECT_BANKS[Number(cb.dataset.lockSubject)];if(!b)return;const k=qbSubjectLockKey(b.name);locks.subjects=locks.subjects.filter(x=>x!==k);if(locked)locks.subjects.push(k);count++;});
 document.querySelectorAll(".qb-lock-chapter:checked").forEach(cb=>{const b=SUBJECT_BANKS[Number(cb.dataset.bankIdx)],ch=b&&b.chapters[Number(cb.dataset.chapterIdx)];if(!b||!ch)return;const k=qbChapterLockKey(b.name,ch);locks.chapters=locks.chapters.filter(x=>x!==k);if(locked)locks.chapters.push(k);count++;});
 if(!count){$("qbLockMessage").hidden=false;$("qbLockMessage").textContent="Select at least one subject or chapter.";return;}
 if(qbWriteLocks(locks)){qbRenderLockChoices();qbRenderDeleteChoices();const m=$("qbLockMessage");m.hidden=false;m.textContent=`${count} item(s) ${locked?"protected from deletion":"unlocked for deletion"}.`+(locked?" Locked items remain available for tests and import; deletion is blocked.":"");}
}
function qbOpenLockModal(){$("qbLockMessage").hidden=true;qbRenderLockChoices();$("qbLockModal").hidden=false;}
function qbRenderDeleteChoices(){
 const host=$("qbDeleteSelectionList");let locks;
 try{locks=qbReadLocksStrict();}catch(err){host.innerHTML=`<p class="qb-help">${esc(err.message)} Deletion is disabled until the saved lock data is repaired.</p>`;return;}
 host.innerHTML=SUBJECT_BANKS.map((bank,bi)=>{
  const hasLockedChapter=bank.chapters.some(ch=>qbIsChapterLocked(bank.name,ch,locks));
  const canDeleteSubject=!bank.primary&&!qbIsSubjectLocked(bank.name,locks)&&!hasLockedChapter;
  const subjectProtectedLabel=canDeleteSubject?"":`<small class="qbm-protected">${bank.primary?"Original bank":(qbIsSubjectLocked(bank.name,locks)?"Deletion Protected":"Contains a protected chapter")}</small>`;
  const subjectChoice=`<label class="qbm-delete-subject-label"><input type="checkbox" class="qb-del-subject" data-qb-del-subject="${bi}" ${canDeleteSubject?"":"disabled"}><span>${esc(bank.name)}</span>${subjectProtectedLabel}</label>`;
  const chapters=bank.chapters.map((ch,ci)=>{
   const protectedChapter=(bank.primary&&QB_BUILTIN_CHAPTER_IDS.has(String(ch.id)))||qbIsSubjectLocked(bank.name,locks)||qbIsChapterLocked(bank.name,ch,locks);
   return `<label class="qbm-delete-chapter-label"><input type="checkbox" class="qb-del-chapter" data-bank-idx="${bi}" data-chapter-idx="${ci}" data-protected="${protectedChapter?"true":"false"}" ${protectedChapter?"disabled":""}><span>${esc(ch.title)}</span>${protectedChapter?`<small class=\"qbm-protected\">${bank.primary&&QB_BUILTIN_CHAPTER_IDS.has(String(ch.id))?"Original":"Locked"}</small>`:""}</label>`;
  }).join("");
  return `<div class="qbm-delete-subject">${subjectChoice}<div class="qbm-delete-chapters">${chapters||'<span class="qbm-protected">No chapters</span>'}</div></div>`;
 }).join("");
 host.querySelectorAll(".qb-del-subject").forEach(cb=>cb.addEventListener("change",()=>{
  const card=cb.closest(".qbm-delete-subject");
  card.querySelectorAll(".qb-del-chapter").forEach(ch=>{
   if(cb.checked)ch.checked=false;
   ch.disabled=cb.checked||ch.dataset.protected==="true";
  });
 }));
}
function qbGetPendingDeletion(){
 const subjects=[],chapters=[];let locks;
 try{locks=qbReadLocksStrict();}catch(err){qbSetManagerMessage(err.message+" Deletion was stopped to protect locked items.","error");return {subjects,chapters};}
 document.querySelectorAll(".qb-del-subject:checked").forEach(cb=>{
  const b=SUBJECT_BANKS[Number(cb.dataset.qbDelSubject)];
  if(b&&!b.primary&&!qbIsSubjectLocked(b.name,locks)&&!b.chapters.some(ch=>qbIsChapterLocked(b.name,ch,locks)))subjects.push({name:b.name,index:Number(cb.dataset.qbDelSubject)});
 });
 document.querySelectorAll(".qb-del-chapter:checked").forEach(cb=>{
  const bi=Number(cb.dataset.bankIdx),ci=Number(cb.dataset.chapterIdx);
  const b=SUBJECT_BANKS[bi],ch=b&&b.chapters[ci];
  if(b&&ch&&!subjects.some(x=>x.index===bi)&&!qbIsSubjectLocked(b.name,locks)&&!qbIsChapterLocked(b.name,ch,locks))chapters.push({subject:b.name,chapter:ch});
 });
 return {subjects,chapters};
}
function qbOpenDeleteModal(){
 $("qbDeleteMessage").hidden=true;$("qbDeleteMessage").textContent="";
 qbRenderDeleteChoices();
 $("qbDeleteSelectStage").hidden=false;$("qbDeleteConfirmStage").hidden=true;
 $("qbDeleteModal").hidden=false;
}
function qbDeleteContinue(){
 const pending=qbGetPendingDeletion();
 if(!pending.subjects.length&&!pending.chapters.length){
  qbSetManagerMessage("Select at least one subject or chapter to delete.","error");return;
 }
 const lines=[
  ...pending.subjects.map(x=>`Subject: ${x.name} (including all its chapters)`),
  ...pending.chapters.map(x=>`Chapter: ${x.subject} — ${x.chapter.title}`)
 ];
 $("qbDeleteConfirmSummary").innerHTML=
  `${lines.map(x=>`<div>${esc(x)}</div>`).join("")}<p><strong>${pending.subjects.length} subject(s) and ${pending.chapters.length} chapter(s) selected.</strong></p>`;
 $("qbDeleteSelectStage").hidden=true;$("qbDeleteConfirmStage").hidden=false;
}
let qbDeleteCountdownTimer=null;
function qbCancelDeleteCountdown(){if(qbDeleteCountdownTimer){clearInterval(qbDeleteCountdownTimer);qbDeleteCountdownTimer=null;}$("qbDeleteCountdownRow").hidden=true;$("qbDeletePermanentlyBtn").disabled=false;$("qbDeletePermanentlyBtn").textContent="Start 10-second deletion";}
function qbStartDeleteCountdown(){
 if(qbDeleteCountdownTimer)return;
 let remaining=10;const btn=$("qbDeletePermanentlyBtn");btn.disabled=true;$("qbDeleteCountdownRow").hidden=false;$("qbDeleteCountdown").textContent=`Permanent deletion in ${remaining} seconds`;
 qbDeleteCountdownTimer=setInterval(()=>{remaining--;$("qbDeleteCountdown").textContent=remaining>0?`Permanent deletion in ${remaining} seconds`:"Deleting…";if(remaining<=0){clearInterval(qbDeleteCountdownTimer);qbDeleteCountdownTimer=null;qbPerformConfirmedDelete();}},1000);
}
function qbPerformConfirmedDelete(){
 const pending=qbGetPendingDeletion();
 if(!pending.subjects.length&&!pending.chapters.length){qbCancelDeleteCountdown();qbSetManagerMessage("No deletable item remains selected. Nothing was deleted.","error");return;}
 let del,records,locks;
 try{del=qbReadDeletionStateStrict();records=qbReadStoredRecordsStrict();locks=(()=>{const raw=localStorage.getItem(QB_LOCKS_KEY);if(raw===null)return {subjects:[],chapters:[]};const parsed=JSON.parse(raw);if(!parsed||typeof parsed!=="object"||Array.isArray(parsed)||(parsed.subjects!==undefined&&!Array.isArray(parsed.subjects))||(parsed.chapters!==undefined&&!Array.isArray(parsed.chapters)))throw new Error("Question Bank lock settings are invalid.");return {subjects:Array.isArray(parsed.subjects)?parsed.subjects.slice():[],chapters:Array.isArray(parsed.chapters)?parsed.chapters.slice():[]};})();}
 catch(err){qbSetManagerMessage("Deletion stopped to protect existing data: "+err.message,"error");return;}
 pending.subjects.forEach(x=>{const key=qbNorm(x.name);if(!del.subjects.some(v=>qbNorm(v)===key))del.subjects.push(key);});
 pending.chapters.forEach(x=>{const key=qbNorm(x.subject),id=String(x.chapter.id||""),title=qbNorm(x.chapter.title);if(!del.chapters.some(v=>v&&qbNorm(v.subject)===key&&((id&&String(v.id||"")===id)||(!id&&qbNorm(v.title)===title))))del.chapters.push({subject:key,id,title});});
 const removedNames=new Set(pending.subjects.map(x=>qbNorm(x.name)));
 const keptRecords=records.filter(record=>{
  if(!record||typeof record!=="object"||!record.bank)return true;
  const bankName=qbNorm(record.bank.subject||record.bank.name||""),targetName=qbNorm(record.target_subject||"");
  return !removedNames.has(bankName)&&!removedNames.has(targetName);
 });
 locks.subjects=locks.subjects.filter(k=>!removedNames.has(qbNorm(k)));
 const deletedChapterKeys=new Set(pending.chapters.map(x=>qbNorm(x.subject)+"::"+String(x.chapter.id||qbNorm(x.chapter.title))));
 locks.chapters=locks.chapters.filter(k=>!deletedChapterKeys.has(String(k)));
 const updates={
  [QUESTION_BANK_DELETIONS_KEY]:JSON.stringify({subjects:Array.from(new Set(del.subjects.map(qbNorm))),chapters:del.chapters}),
  [QB_LOCKS_KEY]:JSON.stringify({subjects:Array.from(new Set(locks.subjects.map(String))),chapters:Array.from(new Set(locks.chapters.map(String)))})
 };
 if(keptRecords.length!==records.length)updates[QUESTION_BANK_STORAGE_KEY]=JSON.stringify(keptRecords);
 if(!qbCommitStorageUpdates(updates,"Deletion was not completed because browser storage is full or unavailable."))return;
 $("qbDeleteModal").hidden=true;
 qbSetManagerMessage(`Deleted ${pending.subjects.length} subject(s) and ${pending.chapters.length} chapter(s). Reloading…`,"success");
 setTimeout(()=>window.location.reload(),700);
}
function qbSetSelectedJsonFile(file){
 const input=$("qbJsonFile");
 if(!file){
  if(input)input.value="";
  if($("qbFileName"))$("qbFileName").textContent="No file chosen";
  qbReadAndValidateFile(null);return;
 }
 // Do not reject by extension or MIME type: Android document providers often
 // report application/octet-stream or an empty type for valid .json files.
 if($("qbFileName"))$("qbFileName").textContent=file.name||"Selected JSON file";
 // Validate the dropped File directly; assigning a FileList is not reliable on mobile.
 qbReadAndValidateFile(file);
}
function qbInitDropZone(){
 const zone=$("qbDropZone"),input=$("qbJsonFile");if(!zone||!input)return;
 ["dragenter","dragover"].forEach(type=>zone.addEventListener(type,event=>{
  event.preventDefault();event.stopPropagation();if(event.dataTransfer)event.dataTransfer.dropEffect="copy";zone.classList.add("is-dragover");
 }));
 ["dragleave","dragend"].forEach(type=>zone.addEventListener(type,event=>{
  event.preventDefault();event.stopPropagation();if(type==="dragend"||!zone.contains(event.relatedTarget))zone.classList.remove("is-dragover");
 }));
 zone.addEventListener("drop",event=>{
  event.preventDefault();event.stopPropagation();zone.classList.remove("is-dragover");
  const files=event.dataTransfer&&event.dataTransfer.files;
  if(!files||!files.length){qbSetManagerMessage("No file was detected. Drop one JSON file into this area.","error");return;}
  if(files.length!==1){qbSetManagerMessage("Please drop one JSON file at a time.","error");return;}
  qbSetSelectedJsonFile(files[0]);
 });
}
function qbInitManager(){
 qbRefreshTargetChoices();qbRenderStatsAndBanks();qbInitDropZone();
 $("homeQuestionBankManagerBtn").addEventListener("click",qbOpenManager);
 $("qbBackHomeBtn").addEventListener("click",qbReturnHome);
 $("qbJsonFile").addEventListener("change",()=>{
  const file=$("qbJsonFile").files&&$("qbJsonFile").files[0];
  if($("qbFileName"))$("qbFileName").textContent=file?file.name:"No file chosen";
  qbReadAndValidateFile(file||null);
 });
 $("qbImportMode").addEventListener("change",()=>{qbRefreshTargetChoices();if(qbSelectedParsedBank)qbRenderPreview();});
 $("qbTargetSubject").addEventListener("change",()=>{if(qbSelectedParsedBank)qbRenderPreview();});
 $("qbPreviewBtn").addEventListener("click",()=>{if(!qbSelectedParsedBank)return;qbRenderPreview();});
 $("qbImportBtn").addEventListener("click",qbImportSelectedBank);
 $("qbExportSubjectSelect").addEventListener("change",qbUpdateExportSummary);
 $("qbExportSubjectBtn").addEventListener("click",()=>qbExportBank(Number($("qbExportSubjectSelect").value)));
 $("qbExportChapterBtn").addEventListener("click",()=>qbExportBank(Number($("qbExportSubjectSelect").value),Number($("qbExportChapterSelect").value)));
 $("qbOpenAddModalBtn").addEventListener("click",qbOpenAddModal);
 $("qbOpenDeleteModalBtn").addEventListener("click",qbOpenDeleteModal);
 $("qbOpenLockModalBtn").addEventListener("click",qbOpenLockModal);
 $("qbLockSelectedBtn").addEventListener("click",()=>qbApplyLocks(true));
 $("qbUnlockSelectedBtn").addEventListener("click",()=>qbApplyLocks(false));
 $("qbDeleteCancelCountdownBtn").addEventListener("click",qbCancelDeleteCountdown);
 $("qbCreateMultipleSubjectsBtn").addEventListener("click",qbCreateMultipleSubjects);
 $("qbCreateMultipleChaptersBtn").addEventListener("click",qbCreateMultipleChapters);
 $("qbDeleteContinueBtn").addEventListener("click",qbDeleteContinue);
 $("qbDeleteBackBtn").addEventListener("click",()=>{
  qbCancelDeleteCountdown();$("qbDeleteConfirmStage").hidden=true;$("qbDeleteSelectStage").hidden=false;
 });
 $("qbDeletePermanentlyBtn").addEventListener("click",qbStartDeleteCountdown);
 document.querySelectorAll("[data-qb-add-tab]").forEach(btn=>btn.addEventListener("click",()=>{
  const tab=btn.dataset.qbAddTab;
  $("qbAddSubjectsPane").hidden=tab!=="subjects";$("qbAddChaptersPane").hidden=tab!=="chapters";
  document.querySelectorAll("[data-qb-add-tab]").forEach(x=>x.classList.toggle("active",x===btn));
  qbRefreshTargetChoices();
 }));
 document.querySelectorAll("[data-qb-close-modal]").forEach(btn=>
  btn.addEventListener("click",()=>{if(btn.dataset.qbCloseModal==="qbDeleteModal")qbCancelDeleteCountdown();$(btn.dataset.qbCloseModal).hidden=true;})
 );
 document.querySelectorAll(".qbm-modal").forEach(modal=>
  modal.addEventListener("click",e=>{if(e.target===modal){if(modal.id==="qbDeleteModal")qbCancelDeleteCountdown();modal.hidden=true;}})
 );
}
populateChapters();
qbInitManager();

/* Consistent Question Bank Manager entry / Student Mode home-only behaviour. */
$("homeQuestionBankManagerBtn").addEventListener("click",e=>{
 e.preventDefault();e.stopImmediatePropagation();
 stopTimer();timerPaused=false;solutionPanelOpen=false;clearSolutionHideTimer();
 closeSubmitModal();closePopovers();closePersModal();
 isHomeDashboard=true;setDisplayMode("normal");
 $("homeDashboard").hidden=true;$("bookmarkPracticePage").hidden=true;$("mockWorkspace").style.display="none";
 $("scorecardView").style.display="none";$("scorecardView").classList.remove("active");
 document.body.classList.add("qb-manager-open");
 $("questionBankManagerPage").hidden=false;
 qbRenderStatsAndBanks();window.scrollTo({top:0,behavior:"smooth"});
},true);
$("studyModeBtn").addEventListener("click",e=>{
 e.preventDefault();e.stopImmediatePropagation();
 stopTimer();timerPaused=false;solutionPanelOpen=false;clearSolutionHideTimer();
 const alreadyActive=document.body.classList.contains("study-active");
 isHomeDashboard=true;state.customSession=null;
 $("mockWorkspace").style.display="none";$("scorecardView").style.display="none";$("scorecardView").classList.remove("active");
 $("bookmarkPracticePage").hidden=true;$("questionBankManagerPage").hidden=true;$("homeDashboard").hidden=false;
 document.body.classList.remove("submitted-scorecard-only","page-workspace-open","qb-manager-open");
 if(!alreadyActive) requestAppFullscreen();
 setDisplayMode(alreadyActive?"normal":"study");
 updateHomeChapterLabel();renderHomeRecentResults();renderHomeBookmarkedPreview();
 window.scrollTo({top:0,behavior:"smooth"});saveState();
},true);

/* Saved test review: one question at a time, with immediate answer/explanation. */
/* The review renderer above is the single-question version; navigation is delegated here. */

/* Re-render bookmarked preview as a count only: the Home page never displays question stems. */
renderHomeBookmarkedPreview();

initAppSelect("partSelect");
initAppSelect("chapterSelect");
refreshTimerLabels();
syncPopoverControls();
syncBookmarkBadge();
isHomeDashboard = true;
renderChapterView();
// Default landing state is Home; questions open only after a selected action.
setDisplayMode("normal");
if(state.exitedTestKey){
 isHomeDashboard=true;
 $("homeDashboard").hidden=false;
 $("mockWorkspace").style.display="none";
 $("scorecardView").style.display="none";
 $("scorecardView").classList.remove("active");
 renderExitedTestHomeState();
}
})();
